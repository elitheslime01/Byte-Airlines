using MySql.Data.MySqlClient;
using System.Runtime.InteropServices;

namespace ByteAirline
{
    public partial class Login : Form
    {
        static MySqlConnection conn = null;
        public Login()
        {
            InitializeComponent();
            Connection();
        }
        static void Connection()
        {
            string connStr = "server=127.0.0.1;user=root;database=dbbyte;password=";

            try
            {
                conn = new MySqlConnection(connStr);
                conn.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
            }
        }

        #region -> Drag
        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hWnd, int wMsg, int wParam, int lParam);
        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.Style = 0x20000;
                return cp;
            }
        }

        private void Login_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }
        #endregion

        private void btnSignin_Click(object sender, EventArgs e)
        {
            string email = tbEmail.Texts;
            string password = tbPassword.Texts;

            try
            {
                conn.Open();
                MySqlCommand mysqlcommand = new MySqlCommand("select * from tbluser", conn);
                MySqlDataReader reader = mysqlcommand.ExecuteReader();


                while (reader.Read())
                {
                    if (email == reader.GetString("email") && password == reader.GetString("password"))
                    {
                        MainForm mainform = new MainForm();
                        this.Hide();
                        mainform.Show();
                    }
                    else
                    {
                        DialogResult res = MessageBox.Show("Incorrect Email or Password", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                conn.Close();
            }
            finally
            {
                conn.Close();
            }
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void minimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
    }
}