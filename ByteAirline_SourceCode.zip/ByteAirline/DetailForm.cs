﻿using MySql.Data.MySqlClient;
using Org.BouncyCastle.Asn1.Ocsp;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Numerics;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static Org.BouncyCastle.Bcpg.Attr.ImageAttrib;
using static System.Windows.Forms.DataFormats;

namespace ByteAirline
{
    public partial class DetailForm : Form
    {
        private Airplane airplane;
        static MySqlConnection conn = null;
        private List<string> passengerNames;

        public DetailForm()
        {
            InitializeComponent();
            Connection();
        }
        static void Connection()
        {
            string connStr = "server=127.0.0.1;user=root;database=dbbyte;password=";

            try
            {
                conn = new MySqlConnection(connStr);
                conn.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
            }
        }
        private void exit1_Click(object sender, EventArgs e)
        {
            try
            {
                conn.Open();
                string query = "delete from tblplane where flight='current'";
                MySqlCommand mysqlcommand = new MySqlCommand(query, conn);

                mysqlcommand.CommandText = query;
                if (mysqlcommand.ExecuteNonQuery() == 1)
                {

                }
                else
                {
                    MessageBox.Show("DATA NOT INSERTED SUCCESSFULLY1");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                conn.Clone();
            }
            finally
            {
                conn.Close();
            }

            try
            {
                conn.Open();
                string query = "delete from tblsched where flight='current'";
                MySqlCommand mysqlcommand = new MySqlCommand(query, conn);

                mysqlcommand.CommandText = query;
                if (mysqlcommand.ExecuteNonQuery() == 1)
                {

                }
                else
                {
                    MessageBox.Show("DATA NOT DELETED SUCCESSFULLY 2");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                conn.Clone();
            }
            finally
            {
                conn.Close();
            }


            try
            {
                conn.Open();
                string query = "delete from tblnames";
                MySqlCommand mysqlcommand = new MySqlCommand(query, conn);

                mysqlcommand.CommandText = query;
                if (mysqlcommand.ExecuteNonQuery() == 1)
                {

                }
                else
                {

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                conn.Clone();
            }
            finally
            {
                conn.Close();
            }
            Environment.Exit(0);

        }

        #region -> Drag
        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hWnd, int wMsg, int wParam, int lParam);
        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.Style = 0x20000;
                return cp;
            }
        }
        #endregion
        private void minimize1_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void logOut1_Click(object sender, EventArgs e)
        {
            try
            {
                conn.Open();
                string query = "delete from tblplane where flight='current'";
                MySqlCommand mysqlcommand = new MySqlCommand(query, conn);

                mysqlcommand.CommandText = query;
                if (mysqlcommand.ExecuteNonQuery() == 1)
                {

                }
                else
                {
                    MessageBox.Show("DATA NOT DELETED SUCCESSFULLY");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                conn.Clone();
            }
            finally
            {
                conn.Close();
            }

            try
            {
                conn.Open();
                string query = "delete from tblsched where flight='current'";
                MySqlCommand mysqlcommand = new MySqlCommand(query, conn);

                mysqlcommand.CommandText = query;
                if (mysqlcommand.ExecuteNonQuery() == 1)
                {

                }
                else
                {
                    MessageBox.Show("DATA NOT DELETED SUCCESSFULLY");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                conn.Clone();
            }
            finally
            {
                conn.Close();
            }
            try
            {
                conn.Open();
                string query = "delete from tblnames";
                MySqlCommand mysqlcommand = new MySqlCommand(query, conn);

                mysqlcommand.CommandText = query;
                if (mysqlcommand.ExecuteNonQuery() == 1)
                {

                }
                else
                {

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                conn.Clone();
            }
            finally
            {
                conn.Close();
            }
            MainForm main = new MainForm();
            main.Show();
            this.Hide();
        }

        public void GetValuesFromDB()
        {
            airplane = new Airplane();

            try
            {
                conn.Open();
                string query = "select * from tblplane where flight='current'";
                MySqlCommand mysqlcommand = new MySqlCommand(query, conn);
                MySqlDataReader reader = mysqlcommand.ExecuteReader();

                if (reader.Read())
                {
                    airplane.FlightType = reader.GetValue(1).ToString();
                    airplane.FlightTrip = reader.GetValue(2).ToString();
                    airplane.Adult = int.Parse(reader.GetValue(3).ToString());
                    airplane.Child = int.Parse(reader.GetValue(4).ToString());
                    airplane.Senior = int.Parse(reader.GetValue(5).ToString());
                    airplane.FromLoc = reader.GetValue(6).ToString();
                    airplane.ToLoc = reader.GetValue(7).ToString();
                    airplane.DepartDate = reader.GetDateTime(8);
                    airplane.ReturnDate = reader.GetDateTime(9);
                    airplane.Insurance = Convert.ToBoolean(reader.GetBoolean(10).ToString());

                }
                else
                {
                    MessageBox.Show("NO DATA FOUND");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                conn.Clone();
            }
            finally
            {
                conn.Close();
            }
        }

        public void CalculationOverview()
        {
            airplane = new Airplane();

            GetValuesFromDB();

            lbAdultFare.Text = "PHP " + airplane.AdultFare().ToString() + ".00";
            lbChildFare.Text = "PHP " + airplane.ChildFare().ToString() + ".00";
            lbSeniorFare.Text = "PHP " + airplane.SeniorFare().ToString() + ".00";
            lbTravelInsurance.Text = "PHP " + airplane.TravelInsurance().ToString() + ".00";
            lbTravelTax.Text = "PHP " + airplane.TravelTax().ToString() + ".00";
            lbBaggageFee.Text = "PHP " + airplane.BaggageFee().ToString() + ".00";
            lbAdditionalCharges.Text = "PHP " + airplane.TransactionFee().ToString() + ".00";
            lbSeniorDiscount.Text = "PHP -" + airplane.seniorFareDiscounted().ToString() + ".00";
            totalFare.Text = "PHP " + airplane.TotalFee().ToString() + ".00";
        }

        private void menuPanel_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void DetailForm_Load(object sender, EventArgs e)
        {
            GetValuesFromDB();

            int numAdult = airplane.Adult;
            int numChildren = airplane.Child;
            int numSenior = airplane.Senior;

            for (int i = 1; i <= numAdult; i++) // Loop 5 times to create 5 tabpages
            {
                // Create a new tabpage and add it to the tabcontrol

                TabPage adultPage = new TabPage("Adults " + i.ToString());

                tabControl1.TabPages.Add(adultPage);

                // Create a textbox and a button and add them to the new tabpage
                Label lbName = new Label();
                lbName.Location = new Point(50, 50);
                lbName.Text = "Name";
                lbName.Font = new Font("Lato", 11.9999981F, FontStyle.Regular, GraphicsUnit.Point);
                lbName.ForeColor = Color.DimGray;
                adultPage.Controls.Add(lbName);

                TextBox tbName = new TextBox();
                tbName.Location = new Point(200, 50);
                tbName.Size = new Size(200, 50);
                tbName.Font = new Font("Lato", 11.9999981F, FontStyle.Regular, GraphicsUnit.Point);
                tbName.ForeColor = Color.DimGray;
                adultPage.Controls.Add(tbName);

                Label lbBirthDate = new Label();
                lbBirthDate.Location = new Point(50, 100);
                lbBirthDate.Text = "Date of Birth";
                lbBirthDate.Size = new Size(100, 50);
                lbBirthDate.Font = new Font("Lato", 11.9999981F, FontStyle.Regular, GraphicsUnit.Point);
                lbBirthDate.ForeColor = Color.DimGray;
                adultPage.Controls.Add(lbBirthDate);


                DateTimePicker dpBirthDate = new DateTimePicker();
                dpBirthDate.Format = DateTimePickerFormat.Short;
                dpBirthDate.Location = new Point(200, 100);
                dpBirthDate.Size = new Size(200, 50);
                dpBirthDate.Font = new Font("Lato", 11.9999981F, FontStyle.Regular, GraphicsUnit.Point);
                dpBirthDate.ForeColor = Color.DimGray;
                adultPage.Controls.Add(dpBirthDate);

                Label lbNationality = new Label();
                lbNationality.Location = new Point(50, 150);
                lbNationality.Text = "Nationality";
                lbNationality.Font = new Font("Lato", 11.9999981F, FontStyle.Regular, GraphicsUnit.Point);
                lbNationality.ForeColor = Color.DimGray;
                adultPage.Controls.Add(lbNationality);

                TextBox tbNationalty = new TextBox();
                tbNationalty.Location = new Point(200, 150);
                tbNationalty.Size = new Size(200, 50);
                tbNationalty.Font = new Font("Lato", 11.9999981F, FontStyle.Regular, GraphicsUnit.Point);
                tbNationalty.ForeColor = Color.DimGray;
                adultPage.Controls.Add(tbNationalty);

                Label lbContact = new Label();
                lbContact.Location = new Point(50, 200);
                lbContact.Text = "Contact no.";
                lbContact.Font = new Font("Lato", 11.9999981F, FontStyle.Regular, GraphicsUnit.Point);
                lbContact.ForeColor = Color.DimGray;
                adultPage.Controls.Add(lbContact);

                TextBox tbContact = new TextBox();
                tbContact.Location = new Point(200, 200);
                tbContact.Size = new Size(200, 50);
                tbContact.Font = new Font("Lato", 11.9999981F, FontStyle.Regular, GraphicsUnit.Point);
                tbContact.ForeColor = Color.DimGray;
                adultPage.Controls.Add(tbContact);
            }

            if (numChildren != 0)
            {
                for (int i = 1; i <= numChildren; i++) // Loop 5 times to create 5 tabpages
                {
                    // Create a new tabpage and add it to the tabcontrol
                    TabPage childPage = new TabPage("Child " + i.ToString());
                    tabControl1.TabPages.Add(childPage);

                    // Create a textbox and a button and add them to the new tabpage
                    Label lbName = new Label();
                    lbName.Location = new Point(50, 50);
                    lbName.Text = "Name";
                    lbName.Font = new Font("Lato", 11.9999981F, FontStyle.Regular, GraphicsUnit.Point);
                    lbName.ForeColor = Color.DimGray;
                    childPage.Controls.Add(lbName);

                    TextBox tbName = new TextBox();
                    tbName.Location = new Point(200, 50);
                    tbName.Size = new Size(200, 50);
                    tbName.Font = new Font("Lato", 11.9999981F, FontStyle.Regular, GraphicsUnit.Point);
                    tbName.ForeColor = Color.DimGray;
                    childPage.Controls.Add(tbName);

                    Label lbBirthDate = new Label();
                    lbBirthDate.Location = new Point(50, 100);
                    lbBirthDate.Text = "Date of Birth";
                    lbBirthDate.Size = new Size(100, 50);
                    lbBirthDate.Font = new Font("Lato", 11.9999981F, FontStyle.Regular, GraphicsUnit.Point);
                    lbBirthDate.ForeColor = Color.DimGray;
                    childPage.Controls.Add(lbBirthDate);


                    DateTimePicker dpBirthDate = new DateTimePicker();
                    dpBirthDate.Format = DateTimePickerFormat.Short;
                    dpBirthDate.Location = new Point(200, 100);
                    dpBirthDate.Size = new Size(200, 50);
                    dpBirthDate.Font = new Font("Lato", 11.9999981F, FontStyle.Regular, GraphicsUnit.Point);
                    dpBirthDate.ForeColor = Color.DimGray;
                    childPage.Controls.Add(dpBirthDate);

                    Label lbNationality = new Label();
                    lbNationality.Location = new Point(50, 150);
                    lbNationality.Text = "Nationality";
                    lbNationality.Font = new Font("Lato", 11.9999981F, FontStyle.Regular, GraphicsUnit.Point);
                    lbNationality.ForeColor = Color.DimGray;
                    childPage.Controls.Add(lbNationality);

                    TextBox tbNationalty = new TextBox();
                    tbNationalty.Location = new Point(200, 150);
                    tbNationalty.Size = new Size(200, 50);
                    tbNationalty.Font = new Font("Lato", 11.9999981F, FontStyle.Regular, GraphicsUnit.Point);
                    tbNationalty.ForeColor = Color.DimGray;
                    childPage.Controls.Add(tbNationalty);

                    Label lbContact = new Label();
                    lbContact.Location = new Point(50, 200);
                    lbContact.Text = "Contact no.";
                    lbContact.Font = new Font("Lato", 11.9999981F, FontStyle.Regular, GraphicsUnit.Point);
                    lbContact.ForeColor = Color.DimGray;
                    childPage.Controls.Add(lbContact);

                    TextBox tbContact = new TextBox();
                    tbContact.Location = new Point(200, 200);
                    tbContact.Size = new Size(200, 50);
                    tbContact.Font = new Font("Lato", 11.9999981F, FontStyle.Regular, GraphicsUnit.Point);
                    tbContact.ForeColor = Color.DimGray;
                    childPage.Controls.Add(tbContact);
                }
            }
            if (numSenior != 0)
            {
                for (int i = 1; i <= numSenior; i++) // Loop 5 times to create 5 tabpages
                {
                    // Create a new tabpage and add it to the tabcontrol
                    TabPage seniorPage = new TabPage("Senior " + i.ToString());
                    tabControl1.TabPages.Add(seniorPage);

                    // Create a textbox and a button and add them to the new tabpage
                    Label lbName = new Label();
                    lbName.Location = new Point(50, 50);
                    lbName.Text = "Name";
                    lbName.Font = new Font("Lato", 11.9999981F, FontStyle.Regular, GraphicsUnit.Point);
                    lbName.ForeColor = Color.DimGray;
                    seniorPage.Controls.Add(lbName);

                    TextBox tbName = new TextBox();
                    tbName.Location = new Point(200, 50);
                    tbName.Size = new Size(200, 50);
                    tbName.Font = new Font("Lato", 11.9999981F, FontStyle.Regular, GraphicsUnit.Point);
                    tbName.ForeColor = Color.DimGray;
                    seniorPage.Controls.Add(tbName);

                    Label lbBirthDate = new Label();
                    lbBirthDate.Location = new Point(50, 100);
                    lbBirthDate.Text = "Date of Birth";
                    lbBirthDate.Size = new Size(100, 50);
                    lbBirthDate.Font = new Font("Lato", 11.9999981F, FontStyle.Regular, GraphicsUnit.Point);
                    lbBirthDate.ForeColor = Color.DimGray;
                    seniorPage.Controls.Add(lbBirthDate);


                    DateTimePicker dpBirthDate = new DateTimePicker();
                    dpBirthDate.Format = DateTimePickerFormat.Short;
                    dpBirthDate.Location = new Point(200, 100);
                    dpBirthDate.Size = new Size(200, 50);
                    dpBirthDate.Font = new Font("Lato", 11.9999981F, FontStyle.Regular, GraphicsUnit.Point);
                    dpBirthDate.ForeColor = Color.DimGray;
                    seniorPage.Controls.Add(dpBirthDate);

                    Label lbNationality = new Label();
                    lbNationality.Location = new Point(50, 150);
                    lbNationality.Text = "Nationality";
                    lbNationality.Font = new Font("Lato", 11.9999981F, FontStyle.Regular, GraphicsUnit.Point);
                    lbNationality.ForeColor = Color.DimGray;
                    seniorPage.Controls.Add(lbNationality);

                    TextBox tbNationalty = new TextBox();
                    tbNationalty.Location = new Point(200, 150);
                    tbNationalty.Size = new Size(200, 50);
                    tbNationalty.Font = new Font("Lato", 11.9999981F, FontStyle.Regular, GraphicsUnit.Point);
                    tbNationalty.ForeColor = Color.DimGray;
                    seniorPage.Controls.Add(tbNationalty);

                    Label lbContact = new Label();
                    lbContact.Location = new Point(50, 200);
                    lbContact.Text = "Contact no.";
                    lbContact.Font = new Font("Lato", 11.9999981F, FontStyle.Regular, GraphicsUnit.Point);
                    lbContact.ForeColor = Color.DimGray;
                    seniorPage.Controls.Add(lbContact);

                    TextBox tbContact = new TextBox();
                    tbContact.Location = new Point(200, 200);
                    tbContact.Size = new Size(200, 50);
                    tbContact.Font = new Font("Lato", 11.9999981F, FontStyle.Regular, GraphicsUnit.Point);
                    tbContact.ForeColor = Color.DimGray;
                    seniorPage.Controls.Add(tbContact);
                }
            }

        }
        private void insertInfo()
        {
            CalculationOverview();

            try
            {
                conn.Open();
                string query2 = "select * from tblsched where flight='current'";
                MySqlCommand mysqlcommand2 = new MySqlCommand(query2, conn);
                MySqlDataReader reader2 = mysqlcommand2.ExecuteReader();

                if (reader2.Read())
                {
                    flightCode1.Text = "FLIGHT " + reader2.GetValue(1).ToString();
                    flightCode2.Text = "FLIGHT " + reader2.GetValue(1).ToString();
                    flightDepart.Text = reader2.GetDateTime(2).ToShortDateString();
                    flightReturn.Text = reader2.GetDateTime(3).ToShortDateString();
                    departTime1.Text = reader2.GetValue(4).ToString();
                    departTime2.Text = reader2.GetValue(5).ToString();
                    arriveTime1.Text = reader2.GetValue(5).ToString();
                    arriveTime2.Text = reader2.GetValue(4).ToString();
                    departLoc1.Text = reader2.GetValue(6).ToString();
                    departLoc2.Text = reader2.GetValue(6).ToString();
                    arriveLoc1.Text = reader2.GetValue(7).ToString();
                    arriveLoc2.Text = reader2.GetValue(7).ToString();
                    flightType1.Text = reader2.GetValue(8).ToString().ToUpper();
                    flightType2.Text = reader2.GetValue(8).ToString().ToUpper();

                    if (airplane.FlightTrip == "Round-trip")
                    {
                        checkOutPanel.Visible = true;
                        returnPanel.Visible = true;
                    }
                    checkOutPanel.Visible = true;
                }
                else
                {
                    MessageBox.Show("NO DATA FOUND");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                conn.Clone();
            }
            finally
            {
                conn.Close();
            }

            try
            {
                conn.Open();
                int num = 1;

                foreach (TabPage tabPage in tabControl1.TabPages)
                {
                    // Get the TabPage name
                    string tabName = tabPage.Text;

                    // Get the TextBox value
                    TextBox tbName = tabPage.Controls.OfType<TextBox>().FirstOrDefault();
                    string nameValue = tbName.Text;

                    // Insert values into the database
                    string query = "INSERT INTO tblnames (id, name, type) VALUES (@Id, @Name, @Type)";
                    MySqlCommand mysqlcommand = new MySqlCommand(query, conn);
                    mysqlcommand.Parameters.AddWithValue("@Id", num++);
                    mysqlcommand.Parameters.AddWithValue("@Name", nameValue);
                    mysqlcommand.Parameters.AddWithValue("@Type", tabName);
                    mysqlcommand.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                conn.Clone();
            }
            finally
            {
                conn.Close();
            }
        }
        private void btnConfirm_Click(object sender, EventArgs e)
        {
            bool hasEmptyTextboxes = false;

            foreach (TabPage tabPage in tabControl1.TabPages)
            {
                foreach (Control control in tabPage.Controls)
                {
                    if (control is TextBox textBox && string.IsNullOrEmpty(textBox.Text))
                    {
                        hasEmptyTextboxes = true;
                        break;
                    }
                }
            }

            if (hasEmptyTextboxes)
            {
                MessageBox.Show("Please fill in all the required fields.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                insertInfo();
            }

        }

        private void btnPay_Click(object sender, EventArgs e)
        {
            Receipt receipt = new Receipt();
            receipt.ShowDialog();


        }
    }
}
