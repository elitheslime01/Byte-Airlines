﻿using MySql.Data.MySqlClient;
using Org.BouncyCastle.Asn1.Pkcs;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace ByteAirline
{
    public partial class MainForm : Form
    {
        static MySqlConnection conn = null;
        private Airplane airplane;

        public MainForm()
        {
            InitializeComponent();
            DefaultValues();
            Connection();
        }

        static void Connection()
        {
            string connStr = "server=127.0.0.1;user=root;database=dbbyte;password=";

            try
            {
                conn = new MySqlConnection(connStr);
                conn.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
            }
        }

        private void DefaultValues()
        {
            cbFtype.SelectedIndex = 0;
            cbFtrip.SelectedIndex = 0;
            cbAdult.SelectedIndex = 1;
            cbChild.SelectedIndex = 0;
            cbSenior.SelectedIndex = 0;
            dpReturn.Value = DateTime.Today.AddDays(+1);
            cbOption.SelectedIndex = -1;
            cbFromLoc.SelectedIndex = -1;
            cbToLoc.SelectedIndex = -1;
        }

        #region -> Drag Form
        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hWnd, int wMsg, int wParam, int lParam);
        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.Style = 0x20000;
                return cp;
            }
        }
        #endregion
        private void MainForm_Load(object sender, EventArgs e)
        {
            mainPanel.BackColor = Color.FromArgb(190, Color.WhiteSmoke);
            flightsPanel.BackColor = Color.FromArgb(90, Color.WhiteSmoke);

        }

        #region -> Buttons
        private void exit_Click_1(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void minimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void menuPanel_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }
        #endregion

        #region -> Hover&Leave

        private void btnBackMain_MouseHover(object sender, EventArgs e)
        {
            btnBackMain.ForeColor = Color.SteelBlue;
        }

        private void btnBackMain_MouseLeave(object sender, EventArgs e)
        {
            btnBackMain.ForeColor = Color.DimGray;
        }
        #endregion
        public void GetValuesFromDB()
        {
            airplane = new Airplane();

            try
            {
                conn.Open();
                string query = "select * from tblplane where flight='current'";
                MySqlCommand mysqlcommand = new MySqlCommand(query, conn);
                MySqlDataReader reader = mysqlcommand.ExecuteReader();

                if (reader.Read())
                {
                    airplane.FlightType = reader.GetValue(1).ToString();
                    airplane.FlightTrip = reader.GetValue(2).ToString();
                    airplane.Adult = int.Parse(reader.GetValue(3).ToString());
                    airplane.Child = int.Parse(reader.GetValue(4).ToString());
                    airplane.Senior = int.Parse(reader.GetValue(5).ToString());
                    airplane.FromLoc = reader.GetValue(6).ToString();
                    airplane.ToLoc = reader.GetValue(7).ToString();
                    airplane.DepartDate = reader.GetDateTime(8);
                    airplane.ReturnDate = reader.GetDateTime(9);
                    airplane.Insurance = Convert.ToBoolean(reader.GetBoolean(10).ToString());

                }
                else
                {
                    MessageBox.Show("NO DATA FOUND");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                conn.Clone();
            }
            finally
            {
                conn.Close();
            }
        }
        private (string, string, string, string, string, string) GetFlightSched()
        {
            GetValuesFromDB();
            string traveltime = "";
            string from = "";
            string to = "";
            string arrivetime1 = "";
            string arrivetime2 = "";
            string arrivetime3 = "";

            if (airplane.FromLoc == "Manila" && airplane.ToLoc == "Batanes")
            {
                traveltime = "1h 50m";
                from = "Depart - MNL";
                to = "Arrive - BSO";
                arrivetime1 = "9:50 AM";
                arrivetime2 = "2:50 PM";
                arrivetime3 = "7:50 PM";
            }
            if (airplane.FromLoc == "Batanes" && airplane.ToLoc == "Manila")
            {
                traveltime = "1h 50m";
                from = "Depart - BSO";
                to = "Arrive - MNL";
                arrivetime1 = "9:50 AM";
                arrivetime2 = "2:50 PM";
                arrivetime3 = "7:50 PM";
            }
            if (airplane.FromLoc == "Manila" && airplane.ToLoc == "Palawan")
            {
                traveltime = "1h 30m";
                from = "Depart - MNL";
                to = "Arrive - PPS";
                arrivetime1 = "9:30 AM";
                arrivetime2 = "2:30 PM";
                arrivetime3 = "7:30 PM";
            }
            if (airplane.FromLoc == "Palawan" && airplane.ToLoc == "Manila")
            {
                traveltime = "1h 35m";
                from = "Depart - PPS";
                to = "Arrive - MNL";
                arrivetime1 = "9:35 AM";
                arrivetime2 = "2:35 PM";
                arrivetime3 = "7:35 PM";
            }
            if (airplane.FromLoc == "Palawan" && airplane.ToLoc == "Manila")
            {
                traveltime = "1h 35m";
                from = "Depart - PPS";
                to = "Arrive - MNL";
                arrivetime1 = "9:35 AM";
                arrivetime2 = "2:35 PM";
                arrivetime3 = "7:35 PM";
            }
            if (airplane.FromLoc == "Manila" && airplane.ToLoc == "South Korea")
            {
                traveltime = "4h 20m";
                from = "Depart - MNL";
                to = "Arrive - ICN";
                arrivetime1 = "12:20 AM";
                arrivetime2 = "5:20 PM";
                arrivetime3 = "10:20 PM";
            }
            if (airplane.FromLoc == "South Korea" && airplane.ToLoc == "Manila")
            {
                traveltime = "4h 20m";
                from = "Depart - ICN";
                to = "Arrive - MNL";
                arrivetime1 = "12:20 AM";
                arrivetime2 = "5:20 PM";
                arrivetime3 = "10:20 PM";
            }
            if (airplane.FromLoc == "Manila" && airplane.ToLoc == "Japan")
            {
                traveltime = "4h 50m";
                from = "Depart - MNL";
                to = "Arrive - NRT";
                arrivetime1 = "12:50 AM";
                arrivetime2 = "5:50 PM";
                arrivetime3 = "10:50 PM";
            }
            if (airplane.FromLoc == "Japan" && airplane.ToLoc == "Manila")
            {
                traveltime = "4h 50m";
                from = "Depart - NRT";
                to = "Arrive - MNL";
                arrivetime1 = "12:50 AM";
                arrivetime2 = "5:50 PM";
                arrivetime3 = "10:50 PM";
            }
            if (airplane.FromLoc == "Manila" && airplane.ToLoc == "Vietnam")
            {
                traveltime = "3h 25m";
                from = "Depart - MNL";
                to = "Arrive - HNN";
                arrivetime1 = "11:25 AM";
                arrivetime2 = "4:25 PM";
                arrivetime3 = "9:25 PM";
            }
            if (airplane.FromLoc == "Vietnam" && airplane.ToLoc == "Manila")
            {
                traveltime = "3h 25m";
                from = "Depart - HNN";
                to = "Arrive - MNL";
                arrivetime1 = "11:25 AM";
                arrivetime2 = "4:25 PM";
                arrivetime3 = "9:25 PM";
            }

            return (traveltime, from, to, arrivetime1, arrivetime2, arrivetime3);
        }
        
        private void InsertInfo()
        {
            DialogResult res = MessageBox.Show("Do you want to avail travel Insurance?", "Travel Insurance", MessageBoxButtons.YesNo, MessageBoxIcon.Question);


            airplane = new Airplane();

            string flight = "current";
            string airplanetype = cbFtype.SelectedItem.ToString();
            string airplanetrip = cbFtrip.SelectedItem.ToString();
            string adult = cbAdult.SelectedItem.ToString();
            string child = cbChild.SelectedItem.ToString();
            string senior = cbSenior.SelectedItem.ToString();
            string departdate = dpDepart.Value.ToString("yyyy-MM-dd");
            string returndate = dpReturn.Value.ToString("yyyy-MM-dd");
            string fromloc = null;
            if (cbFromLoc.SelectedItem != null)
            {
                fromloc = cbFromLoc.SelectedItem.ToString();
            }
            string toloc = null;
            if (cbToLoc.SelectedItem != null)
            {
                toloc = cbToLoc.SelectedItem.ToString();
            }

            int insurance;

            if (res == DialogResult.Yes)
            {
                insurance = 1;
            }
            else
            {
                insurance = 0;
            }

            try
            {
                conn.Open();
                string query = "insert into tblplane(flight,airplanetype,airplanetrip,adult,child,senior,fromloc,toloc,departdate,returndate,insurance) " +
                               "values('" + flight + "','" + airplanetype + "','" + airplanetrip + "','" + int.Parse(adult) + "','" + int.Parse(child) + "','" + int.Parse(senior) + "','" + fromloc + "','" + toloc + "','" + departdate + "','" + returndate + "','" + Convert.ToInt16(insurance) + "')";
                MySqlCommand mysqlcommand = new MySqlCommand(query, conn);

                mysqlcommand.CommandText = query;
                if (mysqlcommand.ExecuteNonQuery() == 1)
                {
                    Selectflight1();
                    Selectflight2();
                    Selectflight3();
                    flightsPanel.Visible = true;
                }
                else
                {
                    MessageBox.Show("DATA NOT INSERTED SUCCESSFULLY");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                conn.Close();
            }
            finally
            {
                conn.Close();
            }
        }
        private void ClearInfo()
        {
            try
            {
                conn.Open();
                string query = "delete from tblplane where flight='current'";
                MySqlCommand mysqlcommand = new MySqlCommand(query, conn);

                mysqlcommand.CommandText = query;
                if (mysqlcommand.ExecuteNonQuery() == 1)
                {
                    MainForm main = new MainForm();
                    main.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("DATA NOT DELETED SUCCESSFULLY");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                conn.Clone();
            }
            finally
            {
                conn.Close();
            }
        }
        private void cbFtrip_OnSelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbFtrip.SelectedIndex == 0)
            {
                dpReturn.Visible = false;
                lblReturn.Visible = false;
                dpDepart.Size = new Size(406, 54);
            }
            else
            {
                dpReturn.Visible = true;
                lblReturn.Visible = true;
                dpDepart.Size = new Size(200, 54);
            }
        }

        private void cbOption_OnSelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbOption.SelectedIndex == 0)
            {
                cbFromLoc.SelectedItem = "Manila";
                cbToLoc.SelectedItem = "Batanes";
            }

            if (cbOption.SelectedIndex == 1)
            {
                cbFromLoc.SelectedItem = "Batanes";
                cbToLoc.SelectedItem = "Manila";
            }

            if (cbOption.SelectedIndex == 2)
            {
                cbFromLoc.SelectedItem = "Manila";
                cbToLoc.SelectedItem = "Palawan";
            }

            if (cbOption.SelectedIndex == 3)
            {
                cbFromLoc.SelectedItem = "Palawan";
                cbToLoc.SelectedItem = "Manila";
            }

            if (cbOption.SelectedIndex == 4)
            {
                cbFromLoc.SelectedItem = "Manila";
                cbToLoc.SelectedItem = "South Korea";
            }

            if (cbOption.SelectedIndex == 5)
            {
                cbFromLoc.SelectedItem = "South Korea";
                cbToLoc.SelectedItem = "Manila";
            }

            if (cbOption.SelectedIndex == 6)
            {
                cbFromLoc.SelectedItem = "Manila";
                cbToLoc.SelectedItem = "Japan";
            }

            if (cbOption.SelectedIndex == 7)
            {
                cbFromLoc.SelectedItem = "Japan";
                cbToLoc.SelectedItem = "Manila";
            }

            if (cbOption.SelectedIndex == 8)
            {
                cbFromLoc.SelectedItem = "Manila";
                cbToLoc.SelectedItem = "Vietnam";
            }

            if (cbOption.SelectedIndex == 9)
            {
                cbFromLoc.SelectedItem = "Vietnam";
                cbToLoc.SelectedItem = "Manila";
            }

        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            DialogResult res;
            int numAdult = Convert.ToInt16(cbAdult.GetItemText(cbAdult.SelectedItem));
            int numChildren = Convert.ToInt16(cbChild.GetItemText(cbChild.SelectedItem));
            int numSenior = Convert.ToInt16(cbSenior.GetItemText(cbSenior.SelectedItem));
            int totalPassenger = numAdult + numChildren;

            if (cbFtype.SelectedIndex == 0)
            {
                if (cbFromLoc.SelectedIndex == -1 && cbFromLoc.SelectedIndex == -1)
                {
                    res = MessageBox.Show("No travel destination inputted", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    if (totalPassenger > 11)
                    {
                        res = MessageBox.Show("Sorry! You have exceed the number of passenger reservation", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        flightsPanel.Visible = false;
                    }
                    else if (totalPassenger == 0)
                    {
                        res = MessageBox.Show("Please select number of passenger reservation", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        flightsPanel.Visible = false;
                    }
                    else if (numAdult == 0 && numSenior == 0 && numChildren > 0)
                    {
                        res = MessageBox.Show("Cannot travel alone and must be accompanied by at least one (1) Adult and/or Senior Citizen", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        flightsPanel.Visible = false;
                    }
                    else
                    {
                        InsertInfo();
                    }
                }
            }
            if (cbFtype.SelectedIndex == 1)
            {
                if (cbFromLoc.SelectedIndex == -1 && cbFromLoc.SelectedIndex == -1)
                {
                    res = MessageBox.Show("No travel destination inputted", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    if (totalPassenger > 9)
                    {
                        res = MessageBox.Show("Sorry! You have exceed the number of passenger reservation", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        flightsPanel.Visible = false;
                    }
                    else if (totalPassenger == 0)
                    {
                        res = MessageBox.Show("Please select number of passenger reservation", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        flightsPanel.Visible = false;
                    }
                    else if (numAdult == 0 && numSenior == 0 && numChildren > 0)
                    {
                        res = MessageBox.Show("Cannot travel alone and must be accompanied by at least one (1) Adult and/or Senior Citizen", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        flightsPanel.Visible = false;
                    }
                    else
                    {
                        InsertInfo();
                    }
                }
            }
            if (cbFtype.SelectedIndex == 2)
            {
                if (cbFromLoc.SelectedIndex == -1 && cbFromLoc.SelectedIndex == -1)
                {
                    res = MessageBox.Show("No travel destination inputted", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    if (totalPassenger > 8)
                    {
                        res = MessageBox.Show("Sorry! You have exceed the number of passenger reservation", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        flightsPanel.Visible = false;
                    }
                    else if (totalPassenger == 0)
                    {
                        res = MessageBox.Show("Please select number of passenger reservation", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        flightsPanel.Visible = false;
                    }
                    else if (numAdult == 0 && numSenior == 0 && numChildren > 0)
                    {
                        res = MessageBox.Show("Cannot travel alone and must be accompanied by at least one (1) Adult and/or Senior Citizen", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        flightsPanel.Visible = false;
                    }
                    else
                    {
                        InsertInfo();
                    }
                }
            }


            /**MessageBox.Show("Flight Type: " + cbFtype.Texts +
                          "\nFlight Trip: " + cbFtrip.Texts +
                          "\nAdult: " + adult +
                          "\nChild: " + child +
                          "\nSenior Citizen: " + senior +
                          "\nFrom: " + cbFromLoc.Texts +
                          "\nTo: " + cbToLoc.Texts
                          );**/

            /**MessageBox.Show("Flight Type: " + airplane.FlightType +
                            "\nFlight Trip: " + airplane.FlightTrip +
                            "\nAdult: " + airplane.Adult +
                            "\nChild: " + airplane.Child +
                            "\nSenior Citizen: " + airplane.Senior +
                            "\nFrom: " + airplane.FromLoc +
                            "\nTo: " + airplane.ToLoc +
                            "\nAdult Fare: " + airplane.AdultFare() +
                            "\nChild Fare: " + airplane.ChildFare() +
                            "\nSenior Fare: " + airplane.SeniorFare() +
                            "\nTravel Insurance: " + airplane.TravelInsurance() +
                            "\nTravel Tax: " + airplane.TravelTax() +
                            "\nBaggage Fee: " + airplane.BaggageFee() +
                            "\nAdditional Charges: " + airplane.TransactionFee() +
                            "\nSenior Fare Discount: -" + airplane.seniorFareDiscounted() +
                            "\nTotal: " + airplane.TotalFee()
                            );**/

        }

        private void button1_Click(object sender, EventArgs e)
        {
            ClearInfo();
            flightsPanel.Visible = false;
        }

        private void logOut_Click(object sender, EventArgs e)
        {
            try
            {
                conn.Open();
                string query = "delete from tblplane where flight='current'";
                MySqlCommand mysqlcommand = new MySqlCommand(query, conn);

                mysqlcommand.CommandText = query;
                if (mysqlcommand.ExecuteNonQuery() == 1)
                {
                    Login login = new Login();
                    login.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("DATA NOT DELETED SUCCESSFULLY");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                conn.Clone();
            }
            finally
            {
                conn.Close();
            }
        }

        private void Selectflight1()
        {
            GetValuesFromDB();
            (string traveltime, string from, string to, string arrivetime1, _, _) = GetFlightSched();
            (double regularClass, double bussinessClass, double privateClass, _) = airplane.GetTravelDestination();

            arriveTime1.Text = arrivetime1;
            departLoc1.Text = from;
            arriveLoc1.Text = to;
            flightTime1.Text = traveltime;
            if (airplane.FlightType == "Regular")
            {
                flightFare1.Text = "PHP " + regularClass.ToString() + ".00";
            }
            if (airplane.FlightType == "Bussiness")
            {
                flightFare1.Text = "PHP " + bussinessClass.ToString() + ".00";
            }
            if (airplane.FlightType == "Private")
            {
                flightFare1.Text = "PHP " + privateClass.ToString() + ".00";
            }
        }

        private void Selectflight2()
        {
            GetValuesFromDB();
            (string traveltime, string from, string to, _, string arrivetime2, _) = GetFlightSched();
            (double regularClass, double bussinessClass, double privateClass, _) = airplane.GetTravelDestination();

            arriveTime2.Text = arrivetime2;
            departLoc2.Text = from;
            arriveLoc2.Text = to;
            flightTime2.Text = traveltime;
            if (airplane.FlightType == "Regular")
            {
                flightFare2.Text = "PHP " + regularClass.ToString() + ".00";
            }
            if (airplane.FlightType == "Bussiness")
            {
                flightFare2.Text = "PHP " + bussinessClass.ToString() + ".00";
            }
            if (airplane.FlightType == "Private")
            {
                flightFare2.Text = "PHP " + privateClass.ToString() + ".00";
            }
        }

        private void Selectflight3()
        {
            GetValuesFromDB();
            (string traveltime, string from, string to, _, _, string arrivetime3) = GetFlightSched();
            (double regularClass, double bussinessClass, double privateClass, _) = airplane.GetTravelDestination();

            arriveTime3.Text = arrivetime3;
            departLoc3.Text = from;
            arriveLoc3.Text = to;
            flightTime3.Text = traveltime;
            if (airplane.FlightType == "Regular")
            {
                flightFare3.Text = "PHP " + regularClass.ToString() + ".00";
            }
            if (airplane.FlightType == "Bussiness")
            {
                flightFare3.Text = "PHP " + bussinessClass.ToString() + ".00";
            }
            if (airplane.FlightType == "Private")
            {
                flightFare3.Text = "PHP " + privateClass.ToString() + ".00";
            }
        }

        private void btnSelectFlight1_Click(object sender, EventArgs e)
        {
            string flight = "current";
            string flightcode = flightCode1.Text;
            string departdate = dpDepart.Value.ToString("yyyy-MM-dd");
            string returndate = dpReturn.Value.ToString("yyyy-MM-dd");
            string time1 = departTime1.Text;
            string time2 = arriveTime1.Text;
            string loc1 = departLoc1.Text;
            string loc2 = arriveLoc1.Text;
            string airplanetype = cbFtype.SelectedItem.ToString();

            try
            {
                conn.Open();
                string query = "insert into tblsched(flight,flightcode,departdate,returndate,time1,time2,loc1,loc2,airplanetype) " +
                               "values('" + flight + "','" + flightcode + "','" + departdate + "','" + returndate + "','" + time1 + "','" + time2 + "','" + loc1 + "','" + loc2 + "','" + airplanetype + "')";
                MySqlCommand mysqlcommand = new MySqlCommand(query, conn);

                mysqlcommand.CommandText = query;
                if (mysqlcommand.ExecuteNonQuery() == 1)
                {
                    DetailForm detail = new DetailForm();
                    detail.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("DATA NOT INSERTED SUCCESSFULLY");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                conn.Close();
            }
            finally
            {
                conn.Close();
            }
        }

        private void btnSelectFlight2_Click(object sender, EventArgs e)
        {
            string flight = "current";
            string flightcode = flightCode2.Text;
            string departdate = dpDepart.Value.ToString("yyyy-MM-dd");
            string returndate = dpReturn.Value.ToString("yyyy-MM-dd");
            string time1 = departTime2.Text;
            string time2 = arriveTime2.Text;
            string loc1 = departLoc2.Text;
            string loc2 = arriveLoc2.Text;
            string airplanetype = cbFtype.SelectedItem.ToString();

            try
            {
                conn.Open();
                string query = "insert into tblsched(flight,flightcode,departdate,returndate,time1,time2,loc1,loc2,airplanetype) " +
                               "values('" + flight + "','" + flightcode + "','" + departdate + "','" + returndate + "','" + time1 + "','" + time2 + "','" + loc1 + "','" + loc2 + "','" + airplanetype + "')";
                MySqlCommand mysqlcommand = new MySqlCommand(query, conn);

                mysqlcommand.CommandText = query;
                if (mysqlcommand.ExecuteNonQuery() == 1)
                {
                    DetailForm detail = new DetailForm();
                    detail.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("DATA NOT INSERTED SUCCESSFULLY");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                conn.Close();
            }
            finally
            {
                conn.Close();
            }
        }

        private void btnSelectFlight3_Click(object sender, EventArgs e)
        {
            string flight = "current";
            string flightcode = flightCode3.Text;
            string departdate = dpDepart.Value.ToString("yyyy-MM-dd");
            string returndate = dpReturn.Value.ToString("yyyy-MM-dd");
            string time1 = departTime3.Text;
            string time2 = arriveTime3.Text;
            string loc1 = departLoc3.Text;
            string loc2 = arriveLoc3.Text;
            string airplanetype = cbFtype.SelectedItem.ToString();

            try
            {
                conn.Open();
                string query = "insert into tblsched(flight,flightcode,departdate,returndate,time1,time2,loc1,loc2,airplanetype) " +
                               "values('" + flight + "','" + flightcode + "','" + departdate + "','" + returndate + "','" + time1 + "','" + time2 + "','" + loc1 + "','" + loc2 + "','" + airplanetype + "')";
                MySqlCommand mysqlcommand = new MySqlCommand(query, conn);

                mysqlcommand.CommandText = query;
                if (mysqlcommand.ExecuteNonQuery() == 1)
                {
                    DetailForm detail = new DetailForm();
                    detail.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("DATA NOT INSERTED SUCCESSFULLY");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                conn.Close();
            }
            finally
            {
                conn.Close();
            }
        }
    }
}
