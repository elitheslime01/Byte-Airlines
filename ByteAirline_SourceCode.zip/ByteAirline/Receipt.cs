﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ByteAirline
{
    public partial class Receipt : Form
    {
        private Airplane airplane;
        static MySqlConnection conn = null;
        static int generatedNum = GenerateRandomNo();
        public Receipt()
        {
            InitializeComponent();
            Connection();
        }
        static void Connection()
        {
            string connStr = "server=127.0.0.1;user=root;database=dbbyte;password=";

            try
            {
                conn = new MySqlConnection(connStr);
                conn.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
            }
        }

        #region -> Drag
        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hWnd, int wMsg, int wParam, int lParam);
        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.Style = 0x20000;
                return cp;
            }
        }
        #endregion
        public void GetValuesFromDB()
        {
            airplane = new Airplane();

            try
            {
                conn.Open();
                string query = "select * from tblplane where flight='current'";
                MySqlCommand mysqlcommand = new MySqlCommand(query, conn);
                MySqlDataReader reader = mysqlcommand.ExecuteReader();

                if (reader.Read())
                {
                    airplane.FlightType = reader.GetValue(1).ToString();
                    airplane.FlightTrip = reader.GetValue(2).ToString();
                    airplane.Adult = int.Parse(reader.GetValue(3).ToString());
                    airplane.Child = int.Parse(reader.GetValue(4).ToString());
                    airplane.Senior = int.Parse(reader.GetValue(5).ToString());
                    airplane.FromLoc = reader.GetValue(6).ToString();
                    airplane.ToLoc = reader.GetValue(7).ToString();
                    airplane.DepartDate = reader.GetDateTime(8);
                    airplane.ReturnDate = reader.GetDateTime(9);
                    airplane.Insurance = Convert.ToBoolean(reader.GetBoolean(10).ToString());

                }
                else
                {
                    MessageBox.Show("NO DATA FOUND");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                conn.Clone();
            }
            finally
            {
                conn.Close();
            }

            try
            {
                conn.Open();
                string query = "select * from tblsched where flight='current'";
                MySqlCommand mysqlcommand = new MySqlCommand(query, conn);
                MySqlDataReader reader = mysqlcommand.ExecuteReader();

                if (reader.Read())
                {
                    airplane.FlightCode = reader.GetValue(1).ToString();
                    airplane.Time1 = reader.GetValue(4).ToString();
                    airplane.Time2 = reader.GetValue(5).ToString();

                }
                else
                {
                    MessageBox.Show("NO DATA FOUND");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                conn.Clone();
            }
            finally
            {
                conn.Close();
            }
        }

        public static int GenerateRandomNo()
        {
            int _min = 1000;
            int _max = 9999;
            Random _rdm = new Random();
            return _rdm.Next(_min, _max);
        }

        private void DisplayNames()
        {
            try
            {
                conn.Open();

                string query = "SELECT id, name, type FROM tblnames";
                MySqlCommand mysqlcommand = new MySqlCommand(query, conn);
                MySqlDataReader reader = mysqlcommand.ExecuteReader();

                int nameCounter = 1;
                int labelCounter = 1;
                Label currentLabel = null;

                while (reader.Read())
                {
                    int idValue = reader.GetInt32("id");
                    string nameValue = reader.GetString("name");
                    string typeValue = reader.GetString("type");

                    if (nameCounter % 6 == 1)
                    {
                        // Switch to the next label
                        if (currentLabel != null)
                        {
                            labelCounter++;
                        }

                        // Retrieve the next label by its name
                        currentLabel = this.Controls.Find("label" + labelCounter.ToString(), true).FirstOrDefault() as Label;
                    }

                    // Set the values in the current label
                    currentLabel.Text += idValue.ToString() + ". " + nameValue + " (" + typeValue + ") " + "\n";

                    nameCounter++;
                }

                reader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                conn.Close();
            }
            finally
            {
                conn.Close();
            }
        }

        private void Receipt_Load(object sender, EventArgs e)
        {
            GetValuesFromDB();
            DisplayNames();
            (double regularClass, double bussinessClass, double privateClass, _) = airplane.GetTravelDestination();

            if (airplane.FlightType == "Regular")
            {
                if (airplane.FlightTrip == "One-way")
                {
                    tbTravelDestination.Text = "PHP " + regularClass.ToString() + ".00";
                }
                else if (airplane.FlightTrip == "Round-trip")
                {
                    tbTravelDestination.Text = "PHP " + (regularClass * 2).ToString() + ".00";
                }
            }

            if (airplane.FlightType == "Bussiness")
            {
                if (airplane.FlightTrip == "One-way")
                {
                    tbTravelDestination.Text = "PHP " + bussinessClass.ToString() + ".00";
                }
                else if (airplane.FlightTrip == "Round-trip")
                {
                    tbTravelDestination.Text = "PHP " + (bussinessClass * 2).ToString() + ".00";
                }
            }

            if (airplane.FlightType == "Private")
            {
                if (airplane.FlightTrip == "One-way")
                {
                    tbTravelDestination.Text = "PHP " + privateClass.ToString() + ".00";
                }
                else if (airplane.FlightTrip == "Round-trip")
                {
                    tbTravelDestination.Text = "PHP " + (privateClass * 2).ToString() + ".00";
                }
            }

            if (airplane.FlightTrip == "One-way")
            {
                roundTripPanel.Visible = false;
            }
            else
            {
                roundTripPanel.Visible = true;
            }

            DateTime date = DateTime.Now;
            tbTransNum.Text = "BA" + GenerateRandomNo();
            tbBookDate.Text = date.ToLongDateString().ToString();
            tbFlightType.Text = airplane.FlightType + " Class";
            tbFlightTrip.Text = airplane.FlightTrip;
            tbDepartLoc.Text = airplane.FromLoc + " To";
            tbArriveLoc.Text = airplane.ToLoc;
            tbDepartLoc2.Text = airplane.ToLoc + " To";
            tbArriveLoc2.Text = airplane.FromLoc;
            tbFlightCode.Text = airplane.FlightCode;
            tbFlightCode2.Text = airplane.FlightCode;
            tbDepartDate.Text = airplane.DepartDate.ToShortDateString().ToString();
            tbArrivalDate.Text = airplane.ReturnDate.ToShortDateString().ToString();
            tbDepartDate2.Text = airplane.ReturnDate.ToShortDateString().ToString();
            tbArrivalDate2.Text = airplane.ReturnDate.ToShortDateString().ToString();
            tbDepartTIme.Text = airplane.Time1;
            tbArrivalTime.Text = airplane.Time2;
            tbDepartTime2.Text = airplane.Time2;
            tbArrivalTime2.Text = airplane.Time1;
            tbAdultNum.Text = airplane.Adult.ToString();
            tbChildNum.Text = airplane.Child.ToString();
            tbSeniorNum.Text = airplane.Senior.ToString();
            tbAdultFare.Text = "PHP " + airplane.AdultFare().ToString() + ".00";
            tbChildFare.Text = "PHP " + airplane.ChildFare().ToString() + ".00";
            tbSeniorFare.Text = "PHP " + airplane.SeniorFare().ToString() + ".00";
            tbTravelInsurance.Text = "PHP " + airplane.TravelInsurance().ToString() + ".00";
            tbTravelTax.Text = "PHP " + airplane.TravelTax().ToString() + ".00";
            tbBaggageFee.Text = "PHP " + airplane.BaggageFee().ToString() + ".00";
            tbTransactionFee.Text = "PHP " + airplane.TransactionFee().ToString() + ".00";
            tbSeniorDiscount.Text = "PHP -" + airplane.seniorFareDiscounted().ToString() + ".00";
            tbTotal.Text = "PHP " + airplane.TotalFee().ToString() + ".00";
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void Receipt_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }
    }
}
