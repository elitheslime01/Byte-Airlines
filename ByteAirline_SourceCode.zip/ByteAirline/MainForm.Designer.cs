﻿namespace ByteAirline
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            menuPanel = new Panel();
            logOut = new Button();
            pictureBox1 = new PictureBox();
            minimize = new PictureBox();
            pictureBox2 = new PictureBox();
            label2 = new Label();
            btnBook = new Button();
            btnManage = new Button();
            btnTravelInfo = new Button();
            btnExplore = new Button();
            btnAbout = new Button();
            exit = new PictureBox();
            mainPanel = new Panel();
            flightsPanel = new Panel();
            flightFare3 = new Label();
            flightCode3 = new Label();
            pictureBox10 = new PictureBox();
            flightTime3 = new Label();
            pictureBox11 = new PictureBox();
            arriveLoc3 = new Label();
            departLoc3 = new Label();
            pictureBox12 = new PictureBox();
            arriveTime3 = new Label();
            departTime3 = new Label();
            pictureBox13 = new PictureBox();
            flightFare2 = new Label();
            flightCode2 = new Label();
            pictureBox7 = new PictureBox();
            flightTime2 = new Label();
            pictureBox8 = new PictureBox();
            arriveLoc2 = new Label();
            departLoc2 = new Label();
            pictureBox9 = new PictureBox();
            arriveTime2 = new Label();
            departTime2 = new Label();
            flightFare1 = new Label();
            flightCode1 = new Label();
            pictureBox6 = new PictureBox();
            flightTime1 = new Label();
            pictureBox5 = new PictureBox();
            arriveLoc1 = new Label();
            departLoc1 = new Label();
            pictureBox4 = new PictureBox();
            pictureBox3 = new PictureBox();
            arriveTime1 = new Label();
            departTime1 = new Label();
            btnSelectFlight3 = new ePOSOne.btnProduct.Button_WOC();
            btnSelectFlight2 = new ePOSOne.btnProduct.Button_WOC();
            btnSelectFlight1 = new ePOSOne.btnProduct.Button_WOC();
            panel7 = new Panel();
            panel8 = new Panel();
            panel5 = new Panel();
            panel6 = new Panel();
            panel3 = new Panel();
            panel4 = new Panel();
            panel1 = new Panel();
            panel2 = new Panel();
            btnBackMain = new Button();
            btnSearch = new ePOSOne.btnProduct.Button_WOC();
            lblReturn = new Label();
            dpReturn = new RJDatePicker();
            label6 = new Label();
            dpDepart = new RJDatePicker();
            cbToLoc = new RJComboBox();
            cbFromLoc = new RJComboBox();
            cbFtrip = new RJComboBox();
            cbFtype = new RJComboBox();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            lblFrom = new Label();
            lblSenior = new Label();
            lblChild = new Label();
            lblAdult = new Label();
            cbOption = new RJComboBox();
            cbAdult = new ComboBox();
            cbChild = new ComboBox();
            cbSenior = new ComboBox();
            marginLeft = new Panel();
            marginRight = new Panel();
            marginBottom = new Panel();
            marginTop = new Panel();
            label1 = new Label();
            eclipeControl3 = new EclipeControl();
            eclipeControl4 = new EclipeControl();
            eclipeControl5 = new EclipeControl();
            menuPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)minimize).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)exit).BeginInit();
            mainPanel.SuspendLayout();
            flightsPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox12).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox13).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            panel7.SuspendLayout();
            panel5.SuspendLayout();
            panel3.SuspendLayout();
            panel1.SuspendLayout();
            marginTop.SuspendLayout();
            SuspendLayout();
            // 
            // menuPanel
            // 
            menuPanel.BackColor = Color.Transparent;
            menuPanel.Controls.Add(logOut);
            menuPanel.Controls.Add(pictureBox1);
            menuPanel.Controls.Add(minimize);
            menuPanel.Controls.Add(pictureBox2);
            menuPanel.Controls.Add(label2);
            menuPanel.Controls.Add(btnBook);
            menuPanel.Controls.Add(btnManage);
            menuPanel.Controls.Add(btnTravelInfo);
            menuPanel.Controls.Add(btnExplore);
            menuPanel.Controls.Add(btnAbout);
            menuPanel.Controls.Add(exit);
            menuPanel.Dock = DockStyle.Top;
            menuPanel.Location = new Point(0, 0);
            menuPanel.Name = "menuPanel";
            menuPanel.Size = new Size(1300, 70);
            menuPanel.TabIndex = 0;
            menuPanel.MouseDown += menuPanel_MouseDown;
            // 
            // logOut
            // 
            logOut.BackColor = Color.Transparent;
            logOut.Cursor = Cursors.Hand;
            logOut.FlatAppearance.BorderSize = 0;
            logOut.FlatAppearance.MouseDownBackColor = Color.Transparent;
            logOut.FlatAppearance.MouseOverBackColor = Color.Transparent;
            logOut.FlatStyle = FlatStyle.Flat;
            logOut.Font = new Font("Microsoft Sans Serif", 20.2499981F, FontStyle.Bold, GraphicsUnit.Point);
            logOut.ForeColor = Color.DimGray;
            logOut.Location = new Point(12, 14);
            logOut.Name = "logOut";
            logOut.Size = new Size(34, 50);
            logOut.TabIndex = 40;
            logOut.Text = "<";
            logOut.UseVisualStyleBackColor = false;
            logOut.Click += logOut_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            pictureBox1.Cursor = Cursors.Hand;
            pictureBox1.Image = Properties.Resources.icon_user;
            pictureBox1.Location = new Point(52, 24);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(30, 30);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 9;
            pictureBox1.TabStop = false;
            // 
            // minimize
            // 
            minimize.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            minimize.Cursor = Cursors.Hand;
            minimize.Image = Properties.Resources.minimize_light;
            minimize.Location = new Point(1227, 22);
            minimize.Name = "minimize";
            minimize.Size = new Size(20, 20);
            minimize.SizeMode = PictureBoxSizeMode.StretchImage;
            minimize.TabIndex = 8;
            minimize.TabStop = false;
            minimize.Click += minimize_Click;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.logo__2_;
            pictureBox2.Location = new Point(113, 11);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(50, 50);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 6;
            pictureBox2.TabStop = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Microsoft Sans Serif", 15.7499981F, FontStyle.Bold, GraphicsUnit.Point);
            label2.ForeColor = Color.White;
            label2.Location = new Point(166, 23);
            label2.Name = "label2";
            label2.Size = new Size(181, 25);
            label2.TabIndex = 7;
            label2.Text = "BYTE AIRLINES";
            // 
            // btnBook
            // 
            btnBook.Cursor = Cursors.Hand;
            btnBook.FlatAppearance.BorderSize = 0;
            btnBook.FlatAppearance.MouseDownBackColor = Color.Transparent;
            btnBook.FlatAppearance.MouseOverBackColor = Color.Transparent;
            btnBook.FlatStyle = FlatStyle.Flat;
            btnBook.Font = new Font("Microsoft Sans Serif", 11.9999981F, FontStyle.Bold, GraphicsUnit.Point);
            btnBook.ForeColor = Color.White;
            btnBook.Location = new Point(558, 13);
            btnBook.Name = "btnBook";
            btnBook.Size = new Size(100, 41);
            btnBook.TabIndex = 6;
            btnBook.Text = "Book";
            btnBook.UseVisualStyleBackColor = true;
            // 
            // btnManage
            // 
            btnManage.Cursor = Cursors.Hand;
            btnManage.FlatAppearance.BorderSize = 0;
            btnManage.FlatAppearance.MouseDownBackColor = Color.Transparent;
            btnManage.FlatAppearance.MouseOverBackColor = Color.Transparent;
            btnManage.FlatStyle = FlatStyle.Flat;
            btnManage.Font = new Font("Microsoft Sans Serif", 11.9999981F, FontStyle.Bold, GraphicsUnit.Point);
            btnManage.ForeColor = Color.White;
            btnManage.Location = new Point(664, 13);
            btnManage.Name = "btnManage";
            btnManage.Size = new Size(100, 41);
            btnManage.TabIndex = 5;
            btnManage.Text = "Manage";
            btnManage.UseVisualStyleBackColor = true;
            // 
            // btnTravelInfo
            // 
            btnTravelInfo.Cursor = Cursors.Hand;
            btnTravelInfo.FlatAppearance.BorderSize = 0;
            btnTravelInfo.FlatAppearance.MouseDownBackColor = Color.Transparent;
            btnTravelInfo.FlatAppearance.MouseOverBackColor = Color.Transparent;
            btnTravelInfo.FlatStyle = FlatStyle.Flat;
            btnTravelInfo.Font = new Font("Microsoft Sans Serif", 11.9999981F, FontStyle.Bold, GraphicsUnit.Point);
            btnTravelInfo.ForeColor = Color.White;
            btnTravelInfo.Location = new Point(770, 13);
            btnTravelInfo.Name = "btnTravelInfo";
            btnTravelInfo.Size = new Size(145, 41);
            btnTravelInfo.TabIndex = 4;
            btnTravelInfo.Text = "Travel Info";
            btnTravelInfo.UseVisualStyleBackColor = true;
            // 
            // btnExplore
            // 
            btnExplore.Cursor = Cursors.Hand;
            btnExplore.FlatAppearance.BorderSize = 0;
            btnExplore.FlatAppearance.MouseDownBackColor = Color.Transparent;
            btnExplore.FlatAppearance.MouseOverBackColor = Color.Transparent;
            btnExplore.FlatStyle = FlatStyle.Flat;
            btnExplore.Font = new Font("Microsoft Sans Serif", 11.9999981F, FontStyle.Bold, GraphicsUnit.Point);
            btnExplore.ForeColor = Color.White;
            btnExplore.Location = new Point(921, 13);
            btnExplore.Name = "btnExplore";
            btnExplore.Size = new Size(100, 41);
            btnExplore.TabIndex = 3;
            btnExplore.Text = "Explore";
            btnExplore.UseVisualStyleBackColor = true;
            // 
            // btnAbout
            // 
            btnAbout.Cursor = Cursors.Hand;
            btnAbout.FlatAppearance.BorderSize = 0;
            btnAbout.FlatAppearance.MouseDownBackColor = Color.Transparent;
            btnAbout.FlatAppearance.MouseOverBackColor = Color.Transparent;
            btnAbout.FlatStyle = FlatStyle.Flat;
            btnAbout.Font = new Font("Microsoft Sans Serif", 11.9999981F, FontStyle.Bold, GraphicsUnit.Point);
            btnAbout.ForeColor = Color.White;
            btnAbout.Location = new Point(1027, 13);
            btnAbout.Name = "btnAbout";
            btnAbout.Size = new Size(100, 41);
            btnAbout.TabIndex = 2;
            btnAbout.Text = "About Us";
            btnAbout.UseVisualStyleBackColor = true;
            // 
            // exit
            // 
            exit.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            exit.Cursor = Cursors.Hand;
            exit.Image = Properties.Resources.exit_light;
            exit.Location = new Point(1255, 22);
            exit.Name = "exit";
            exit.Size = new Size(20, 20);
            exit.SizeMode = PictureBoxSizeMode.StretchImage;
            exit.TabIndex = 1;
            exit.TabStop = false;
            exit.Click += exit_Click_1;
            // 
            // mainPanel
            // 
            mainPanel.Controls.Add(flightsPanel);
            mainPanel.Controls.Add(btnSearch);
            mainPanel.Controls.Add(lblReturn);
            mainPanel.Controls.Add(dpReturn);
            mainPanel.Controls.Add(label6);
            mainPanel.Controls.Add(dpDepart);
            mainPanel.Controls.Add(cbToLoc);
            mainPanel.Controls.Add(cbFromLoc);
            mainPanel.Controls.Add(cbFtrip);
            mainPanel.Controls.Add(cbFtype);
            mainPanel.Controls.Add(label5);
            mainPanel.Controls.Add(label4);
            mainPanel.Controls.Add(label3);
            mainPanel.Controls.Add(lblFrom);
            mainPanel.Controls.Add(lblSenior);
            mainPanel.Controls.Add(lblChild);
            mainPanel.Controls.Add(lblAdult);
            mainPanel.Controls.Add(cbOption);
            mainPanel.Controls.Add(cbAdult);
            mainPanel.Controls.Add(cbChild);
            mainPanel.Controls.Add(cbSenior);
            mainPanel.Dock = DockStyle.Fill;
            mainPanel.Location = new Point(100, 170);
            mainPanel.Name = "mainPanel";
            mainPanel.Size = new Size(1100, 431);
            mainPanel.TabIndex = 5;
            // 
            // flightsPanel
            // 
            flightsPanel.BackColor = Color.WhiteSmoke;
            flightsPanel.Controls.Add(flightFare3);
            flightsPanel.Controls.Add(flightCode3);
            flightsPanel.Controls.Add(pictureBox10);
            flightsPanel.Controls.Add(flightTime3);
            flightsPanel.Controls.Add(pictureBox11);
            flightsPanel.Controls.Add(arriveLoc3);
            flightsPanel.Controls.Add(departLoc3);
            flightsPanel.Controls.Add(pictureBox12);
            flightsPanel.Controls.Add(arriveTime3);
            flightsPanel.Controls.Add(departTime3);
            flightsPanel.Controls.Add(pictureBox13);
            flightsPanel.Controls.Add(flightFare2);
            flightsPanel.Controls.Add(flightCode2);
            flightsPanel.Controls.Add(pictureBox7);
            flightsPanel.Controls.Add(flightTime2);
            flightsPanel.Controls.Add(pictureBox8);
            flightsPanel.Controls.Add(arriveLoc2);
            flightsPanel.Controls.Add(departLoc2);
            flightsPanel.Controls.Add(pictureBox9);
            flightsPanel.Controls.Add(arriveTime2);
            flightsPanel.Controls.Add(departTime2);
            flightsPanel.Controls.Add(flightFare1);
            flightsPanel.Controls.Add(flightCode1);
            flightsPanel.Controls.Add(pictureBox6);
            flightsPanel.Controls.Add(flightTime1);
            flightsPanel.Controls.Add(pictureBox5);
            flightsPanel.Controls.Add(arriveLoc1);
            flightsPanel.Controls.Add(departLoc1);
            flightsPanel.Controls.Add(pictureBox4);
            flightsPanel.Controls.Add(pictureBox3);
            flightsPanel.Controls.Add(arriveTime1);
            flightsPanel.Controls.Add(departTime1);
            flightsPanel.Controls.Add(btnSelectFlight3);
            flightsPanel.Controls.Add(btnSelectFlight2);
            flightsPanel.Controls.Add(btnSelectFlight1);
            flightsPanel.Controls.Add(panel7);
            flightsPanel.Controls.Add(panel5);
            flightsPanel.Controls.Add(panel3);
            flightsPanel.Controls.Add(panel1);
            flightsPanel.Controls.Add(btnBackMain);
            flightsPanel.Dock = DockStyle.Fill;
            flightsPanel.Location = new Point(0, 0);
            flightsPanel.Name = "flightsPanel";
            flightsPanel.Size = new Size(1100, 431);
            flightsPanel.TabIndex = 37;
            flightsPanel.Visible = false;
            // 
            // flightFare3
            // 
            flightFare3.AutoSize = true;
            flightFare3.BackColor = Color.Transparent;
            flightFare3.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Bold, GraphicsUnit.Point);
            flightFare3.ForeColor = Color.SteelBlue;
            flightFare3.Location = new Point(777, 260);
            flightFare3.Name = "flightFare3";
            flightFare3.Size = new Size(191, 29);
            flightFare3.TabIndex = 39;
            flightFare3.Text = "PHP  00,000.00";
            flightFare3.TextAlign = ContentAlignment.TopRight;
            // 
            // flightCode3
            // 
            flightCode3.AutoSize = true;
            flightCode3.BackColor = Color.Transparent;
            flightCode3.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            flightCode3.ForeColor = Color.DimGray;
            flightCode3.Location = new Point(840, 202);
            flightCode3.Name = "flightCode3";
            flightCode3.Size = new Size(74, 24);
            flightCode3.TabIndex = 38;
            flightCode3.Text = "4A 099";
            // 
            // pictureBox10
            // 
            pictureBox10.BackColor = Color.Transparent;
            pictureBox10.Image = Properties.Resources.plane_gray;
            pictureBox10.Location = new Point(817, 204);
            pictureBox10.Name = "pictureBox10";
            pictureBox10.Size = new Size(20, 20);
            pictureBox10.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox10.TabIndex = 37;
            pictureBox10.TabStop = false;
            // 
            // flightTime3
            // 
            flightTime3.AutoSize = true;
            flightTime3.BackColor = Color.Transparent;
            flightTime3.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            flightTime3.ForeColor = Color.DimGray;
            flightTime3.Location = new Point(840, 165);
            flightTime3.Name = "flightTime3";
            flightTime3.Size = new Size(78, 24);
            flightTime3.TabIndex = 36;
            flightTime3.Text = "0h 00m";
            // 
            // pictureBox11
            // 
            pictureBox11.BackColor = Color.Transparent;
            pictureBox11.Image = Properties.Resources.time;
            pictureBox11.Location = new Point(817, 167);
            pictureBox11.Name = "pictureBox11";
            pictureBox11.Size = new Size(20, 20);
            pictureBox11.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox11.TabIndex = 35;
            pictureBox11.TabStop = false;
            // 
            // arriveLoc3
            // 
            arriveLoc3.AutoSize = true;
            arriveLoc3.BackColor = Color.Transparent;
            arriveLoc3.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Regular, GraphicsUnit.Point);
            arriveLoc3.ForeColor = Color.DimGray;
            arriveLoc3.Location = new Point(904, 110);
            arriveLoc3.Name = "arriveLoc3";
            arriveLoc3.Size = new Size(68, 15);
            arriveLoc3.TabIndex = 34;
            arriveLoc3.Text = "Arrive - AAA";
            // 
            // departLoc3
            // 
            departLoc3.AutoSize = true;
            departLoc3.BackColor = Color.Transparent;
            departLoc3.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Regular, GraphicsUnit.Point);
            departLoc3.ForeColor = Color.DimGray;
            departLoc3.Location = new Point(762, 110);
            departLoc3.Name = "departLoc3";
            departLoc3.Size = new Size(75, 15);
            departLoc3.TabIndex = 33;
            departLoc3.Text = "Depart - AAA";
            // 
            // pictureBox12
            // 
            pictureBox12.BackColor = Color.Transparent;
            pictureBox12.Image = Properties.Resources.plane_blue;
            pictureBox12.Location = new Point(857, 88);
            pictureBox12.Name = "pictureBox12";
            pictureBox12.Size = new Size(30, 30);
            pictureBox12.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox12.TabIndex = 32;
            pictureBox12.TabStop = false;
            // 
            // arriveTime3
            // 
            arriveTime3.AutoSize = true;
            arriveTime3.BackColor = Color.Transparent;
            arriveTime3.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            arriveTime3.ForeColor = Color.DimGray;
            arriveTime3.Location = new Point(901, 77);
            arriveTime3.Name = "arriveTime3";
            arriveTime3.Size = new Size(85, 24);
            arriveTime3.TabIndex = 31;
            arriveTime3.Text = "0:00 PM";
            // 
            // departTime3
            // 
            departTime3.AutoSize = true;
            departTime3.BackColor = Color.Transparent;
            departTime3.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            departTime3.ForeColor = Color.DimGray;
            departTime3.Location = new Point(760, 77);
            departTime3.Name = "departTime3";
            departTime3.Size = new Size(85, 24);
            departTime3.TabIndex = 30;
            departTime3.Text = "6:00 PM";
            // 
            // pictureBox13
            // 
            pictureBox13.Image = Properties.Resources.logo__2_;
            pictureBox13.Location = new Point(831, 190);
            pictureBox13.Name = "pictureBox13";
            pictureBox13.Size = new Size(0, 0);
            pictureBox13.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox13.TabIndex = 29;
            pictureBox13.TabStop = false;
            // 
            // flightFare2
            // 
            flightFare2.AutoSize = true;
            flightFare2.BackColor = Color.Transparent;
            flightFare2.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Bold, GraphicsUnit.Point);
            flightFare2.ForeColor = Color.SteelBlue;
            flightFare2.Location = new Point(471, 260);
            flightFare2.Name = "flightFare2";
            flightFare2.Size = new Size(191, 29);
            flightFare2.TabIndex = 28;
            flightFare2.Text = "PHP  00,000.00";
            // 
            // flightCode2
            // 
            flightCode2.AutoSize = true;
            flightCode2.BackColor = Color.Transparent;
            flightCode2.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            flightCode2.ForeColor = Color.DimGray;
            flightCode2.Location = new Point(534, 202);
            flightCode2.Name = "flightCode2";
            flightCode2.Size = new Size(74, 24);
            flightCode2.TabIndex = 27;
            flightCode2.Text = "4A 095";
            // 
            // pictureBox7
            // 
            pictureBox7.BackColor = Color.Transparent;
            pictureBox7.Image = Properties.Resources.plane_gray;
            pictureBox7.Location = new Point(511, 204);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(20, 20);
            pictureBox7.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox7.TabIndex = 26;
            pictureBox7.TabStop = false;
            // 
            // flightTime2
            // 
            flightTime2.AutoSize = true;
            flightTime2.BackColor = Color.Transparent;
            flightTime2.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            flightTime2.ForeColor = Color.DimGray;
            flightTime2.Location = new Point(534, 165);
            flightTime2.Name = "flightTime2";
            flightTime2.Size = new Size(78, 24);
            flightTime2.TabIndex = 25;
            flightTime2.Text = "0h 00m";
            // 
            // pictureBox8
            // 
            pictureBox8.BackColor = Color.Transparent;
            pictureBox8.Image = Properties.Resources.time;
            pictureBox8.Location = new Point(511, 167);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new Size(20, 20);
            pictureBox8.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox8.TabIndex = 24;
            pictureBox8.TabStop = false;
            // 
            // arriveLoc2
            // 
            arriveLoc2.AutoSize = true;
            arriveLoc2.BackColor = Color.Transparent;
            arriveLoc2.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Regular, GraphicsUnit.Point);
            arriveLoc2.ForeColor = Color.DimGray;
            arriveLoc2.Location = new Point(598, 110);
            arriveLoc2.Name = "arriveLoc2";
            arriveLoc2.Size = new Size(68, 15);
            arriveLoc2.TabIndex = 23;
            arriveLoc2.Text = "Arrive - AAA";
            // 
            // departLoc2
            // 
            departLoc2.AutoSize = true;
            departLoc2.BackColor = Color.Transparent;
            departLoc2.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Regular, GraphicsUnit.Point);
            departLoc2.ForeColor = Color.DimGray;
            departLoc2.Location = new Point(456, 110);
            departLoc2.Name = "departLoc2";
            departLoc2.Size = new Size(75, 15);
            departLoc2.TabIndex = 22;
            departLoc2.Text = "Depart - AAA";
            // 
            // pictureBox9
            // 
            pictureBox9.BackColor = Color.Transparent;
            pictureBox9.Image = Properties.Resources.plane_blue;
            pictureBox9.Location = new Point(551, 88);
            pictureBox9.Name = "pictureBox9";
            pictureBox9.Size = new Size(30, 30);
            pictureBox9.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox9.TabIndex = 21;
            pictureBox9.TabStop = false;
            // 
            // arriveTime2
            // 
            arriveTime2.AutoSize = true;
            arriveTime2.BackColor = Color.Transparent;
            arriveTime2.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            arriveTime2.ForeColor = Color.DimGray;
            arriveTime2.Location = new Point(595, 77);
            arriveTime2.Name = "arriveTime2";
            arriveTime2.Size = new Size(85, 24);
            arriveTime2.TabIndex = 20;
            arriveTime2.Text = "0:00 PM";
            // 
            // departTime2
            // 
            departTime2.AutoSize = true;
            departTime2.BackColor = Color.Transparent;
            departTime2.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            departTime2.ForeColor = Color.DimGray;
            departTime2.Location = new Point(454, 77);
            departTime2.Name = "departTime2";
            departTime2.Size = new Size(85, 24);
            departTime2.TabIndex = 19;
            departTime2.Text = "1:00 PM";
            // 
            // flightFare1
            // 
            flightFare1.AutoSize = true;
            flightFare1.BackColor = Color.Transparent;
            flightFare1.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Bold, GraphicsUnit.Point);
            flightFare1.ForeColor = Color.SteelBlue;
            flightFare1.Location = new Point(150, 259);
            flightFare1.Name = "flightFare1";
            flightFare1.Size = new Size(191, 29);
            flightFare1.TabIndex = 18;
            flightFare1.Text = "PHP  00,000.00";
            flightFare1.TextAlign = ContentAlignment.MiddleRight;
            // 
            // flightCode1
            // 
            flightCode1.AutoSize = true;
            flightCode1.BackColor = Color.Transparent;
            flightCode1.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            flightCode1.ForeColor = Color.DimGray;
            flightCode1.Location = new Point(213, 201);
            flightCode1.Name = "flightCode1";
            flightCode1.Size = new Size(74, 24);
            flightCode1.TabIndex = 17;
            flightCode1.Text = "4A 091";
            // 
            // pictureBox6
            // 
            pictureBox6.BackColor = Color.Transparent;
            pictureBox6.Image = Properties.Resources.plane_gray;
            pictureBox6.Location = new Point(190, 203);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(20, 20);
            pictureBox6.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox6.TabIndex = 16;
            pictureBox6.TabStop = false;
            // 
            // flightTime1
            // 
            flightTime1.AutoSize = true;
            flightTime1.BackColor = Color.Transparent;
            flightTime1.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            flightTime1.ForeColor = Color.DimGray;
            flightTime1.Location = new Point(213, 164);
            flightTime1.Name = "flightTime1";
            flightTime1.Size = new Size(78, 24);
            flightTime1.TabIndex = 15;
            flightTime1.Text = "0h 00m";
            // 
            // pictureBox5
            // 
            pictureBox5.BackColor = Color.Transparent;
            pictureBox5.Image = Properties.Resources.time;
            pictureBox5.Location = new Point(190, 166);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(20, 20);
            pictureBox5.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox5.TabIndex = 14;
            pictureBox5.TabStop = false;
            // 
            // arriveLoc1
            // 
            arriveLoc1.AutoSize = true;
            arriveLoc1.BackColor = Color.Transparent;
            arriveLoc1.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Regular, GraphicsUnit.Point);
            arriveLoc1.ForeColor = Color.DimGray;
            arriveLoc1.Location = new Point(277, 109);
            arriveLoc1.Name = "arriveLoc1";
            arriveLoc1.Size = new Size(68, 15);
            arriveLoc1.TabIndex = 13;
            arriveLoc1.Text = "Arrive - AAA";
            // 
            // departLoc1
            // 
            departLoc1.AutoSize = true;
            departLoc1.BackColor = Color.Transparent;
            departLoc1.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Regular, GraphicsUnit.Point);
            departLoc1.ForeColor = Color.DimGray;
            departLoc1.Location = new Point(135, 109);
            departLoc1.Name = "departLoc1";
            departLoc1.Size = new Size(75, 15);
            departLoc1.TabIndex = 12;
            departLoc1.Text = "Depart - AAA";
            // 
            // pictureBox4
            // 
            pictureBox4.Image = Properties.Resources.logo__2_;
            pictureBox4.Location = new Point(525, 190);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(0, 0);
            pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox4.TabIndex = 11;
            pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.BackColor = Color.Transparent;
            pictureBox3.Image = Properties.Resources.plane_blue;
            pictureBox3.Location = new Point(230, 87);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(30, 30);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 10;
            pictureBox3.TabStop = false;
            // 
            // arriveTime1
            // 
            arriveTime1.AutoSize = true;
            arriveTime1.BackColor = Color.Transparent;
            arriveTime1.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            arriveTime1.ForeColor = Color.DimGray;
            arriveTime1.Location = new Point(274, 76);
            arriveTime1.Name = "arriveTime1";
            arriveTime1.Size = new Size(86, 24);
            arriveTime1.TabIndex = 9;
            arriveTime1.Text = "0:00 AM";
            // 
            // departTime1
            // 
            departTime1.AutoSize = true;
            departTime1.BackColor = Color.Transparent;
            departTime1.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            departTime1.ForeColor = Color.DimGray;
            departTime1.Location = new Point(133, 76);
            departTime1.Name = "departTime1";
            departTime1.Size = new Size(86, 24);
            departTime1.TabIndex = 8;
            departTime1.Text = "8:00 AM";
            // 
            // btnSelectFlight3
            // 
            btnSelectFlight3.BackColor = Color.Transparent;
            btnSelectFlight3.BorderColor = Color.Transparent;
            btnSelectFlight3.ButtonColor = Color.SteelBlue;
            btnSelectFlight3.Cursor = Cursors.Hand;
            btnSelectFlight3.FlatAppearance.BorderSize = 0;
            btnSelectFlight3.FlatAppearance.MouseDownBackColor = Color.Transparent;
            btnSelectFlight3.FlatAppearance.MouseOverBackColor = Color.Transparent;
            btnSelectFlight3.FlatStyle = FlatStyle.Flat;
            btnSelectFlight3.Font = new Font("Microsoft Sans Serif", 11.9999981F, FontStyle.Regular, GraphicsUnit.Point);
            btnSelectFlight3.Location = new Point(749, 317);
            btnSelectFlight3.Name = "btnSelectFlight3";
            btnSelectFlight3.OnHoverBorderColor = Color.Transparent;
            btnSelectFlight3.OnHoverButtonColor = Color.CornflowerBlue;
            btnSelectFlight3.OnHoverTextColor = Color.White;
            btnSelectFlight3.Size = new Size(235, 49);
            btnSelectFlight3.TabIndex = 7;
            btnSelectFlight3.Text = "Select Flight";
            btnSelectFlight3.TextColor = Color.White;
            btnSelectFlight3.UseVisualStyleBackColor = false;
            btnSelectFlight3.Click += btnSelectFlight3_Click;
            // 
            // btnSelectFlight2
            // 
            btnSelectFlight2.BackColor = Color.Transparent;
            btnSelectFlight2.BorderColor = Color.Transparent;
            btnSelectFlight2.ButtonColor = Color.SteelBlue;
            btnSelectFlight2.Cursor = Cursors.Hand;
            btnSelectFlight2.FlatAppearance.BorderSize = 0;
            btnSelectFlight2.FlatAppearance.MouseDownBackColor = Color.Transparent;
            btnSelectFlight2.FlatAppearance.MouseOverBackColor = Color.Transparent;
            btnSelectFlight2.FlatStyle = FlatStyle.Flat;
            btnSelectFlight2.Font = new Font("Microsoft Sans Serif", 11.9999981F, FontStyle.Regular, GraphicsUnit.Point);
            btnSelectFlight2.Location = new Point(446, 317);
            btnSelectFlight2.Name = "btnSelectFlight2";
            btnSelectFlight2.OnHoverBorderColor = Color.Transparent;
            btnSelectFlight2.OnHoverButtonColor = Color.CornflowerBlue;
            btnSelectFlight2.OnHoverTextColor = Color.White;
            btnSelectFlight2.Size = new Size(232, 49);
            btnSelectFlight2.TabIndex = 6;
            btnSelectFlight2.Text = "Select Flight";
            btnSelectFlight2.TextColor = Color.White;
            btnSelectFlight2.UseVisualStyleBackColor = false;
            btnSelectFlight2.Click += btnSelectFlight2_Click;
            // 
            // btnSelectFlight1
            // 
            btnSelectFlight1.BackColor = Color.Transparent;
            btnSelectFlight1.BorderColor = Color.Transparent;
            btnSelectFlight1.ButtonColor = Color.SteelBlue;
            btnSelectFlight1.Cursor = Cursors.Hand;
            btnSelectFlight1.FlatAppearance.BorderSize = 0;
            btnSelectFlight1.FlatAppearance.MouseDownBackColor = Color.Transparent;
            btnSelectFlight1.FlatAppearance.MouseOverBackColor = Color.Transparent;
            btnSelectFlight1.FlatStyle = FlatStyle.Flat;
            btnSelectFlight1.Font = new Font("Microsoft Sans Serif", 11.9999981F, FontStyle.Regular, GraphicsUnit.Point);
            btnSelectFlight1.Location = new Point(122, 317);
            btnSelectFlight1.Name = "btnSelectFlight1";
            btnSelectFlight1.OnHoverBorderColor = Color.Transparent;
            btnSelectFlight1.OnHoverButtonColor = Color.CornflowerBlue;
            btnSelectFlight1.OnHoverTextColor = Color.White;
            btnSelectFlight1.Size = new Size(235, 49);
            btnSelectFlight1.TabIndex = 5;
            btnSelectFlight1.Text = "Select Flight";
            btnSelectFlight1.TextColor = Color.White;
            btnSelectFlight1.UseVisualStyleBackColor = false;
            btnSelectFlight1.Click += btnSelectFlight1_Click;
            // 
            // panel7
            // 
            panel7.BackColor = Color.DarkGray;
            panel7.Controls.Add(panel8);
            panel7.Location = new Point(717, 41);
            panel7.Name = "panel7";
            panel7.Size = new Size(3, 350);
            panel7.TabIndex = 4;
            // 
            // panel8
            // 
            panel8.BackColor = Color.Gray;
            panel8.Location = new Point(32, 0);
            panel8.Name = "panel8";
            panel8.Size = new Size(5, 350);
            panel8.TabIndex = 2;
            // 
            // panel5
            // 
            panel5.BackColor = Color.DarkGray;
            panel5.Controls.Add(panel6);
            panel5.Location = new Point(399, 41);
            panel5.Name = "panel5";
            panel5.Size = new Size(3, 350);
            panel5.TabIndex = 3;
            // 
            // panel6
            // 
            panel6.BackColor = Color.Gray;
            panel6.Location = new Point(32, 0);
            panel6.Name = "panel6";
            panel6.Size = new Size(5, 350);
            panel6.TabIndex = 2;
            // 
            // panel3
            // 
            panel3.BackColor = Color.DarkGray;
            panel3.Controls.Add(panel4);
            panel3.Location = new Point(1013, 41);
            panel3.Name = "panel3";
            panel3.Size = new Size(3, 350);
            panel3.TabIndex = 3;
            // 
            // panel4
            // 
            panel4.BackColor = Color.Gray;
            panel4.Location = new Point(32, 0);
            panel4.Name = "panel4";
            panel4.Size = new Size(5, 350);
            panel4.TabIndex = 2;
            // 
            // panel1
            // 
            panel1.BackColor = Color.DarkGray;
            panel1.Controls.Add(panel2);
            panel1.Location = new Point(90, 41);
            panel1.Name = "panel1";
            panel1.Size = new Size(3, 350);
            panel1.TabIndex = 1;
            // 
            // panel2
            // 
            panel2.BackColor = Color.Gray;
            panel2.Location = new Point(32, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(5, 350);
            panel2.TabIndex = 2;
            // 
            // btnBackMain
            // 
            btnBackMain.BackColor = Color.Transparent;
            btnBackMain.Cursor = Cursors.Hand;
            btnBackMain.FlatAppearance.BorderSize = 0;
            btnBackMain.FlatAppearance.MouseDownBackColor = Color.Transparent;
            btnBackMain.FlatAppearance.MouseOverBackColor = Color.Transparent;
            btnBackMain.FlatStyle = FlatStyle.Flat;
            btnBackMain.Font = new Font("Microsoft Sans Serif", 20.2499981F, FontStyle.Bold, GraphicsUnit.Point);
            btnBackMain.ForeColor = Color.DimGray;
            btnBackMain.Location = new Point(6, 6);
            btnBackMain.Name = "btnBackMain";
            btnBackMain.Size = new Size(50, 50);
            btnBackMain.TabIndex = 0;
            btnBackMain.Text = "<";
            btnBackMain.UseVisualStyleBackColor = false;
            btnBackMain.Click += button1_Click;
            btnBackMain.MouseLeave += btnBackMain_MouseLeave;
            btnBackMain.MouseHover += btnBackMain_MouseHover;
            // 
            // btnSearch
            // 
            btnSearch.BackColor = Color.Transparent;
            btnSearch.BorderColor = Color.Transparent;
            btnSearch.ButtonColor = Color.SteelBlue;
            btnSearch.Cursor = Cursors.Hand;
            btnSearch.FlatAppearance.BorderSize = 0;
            btnSearch.FlatAppearance.MouseDownBackColor = Color.Transparent;
            btnSearch.FlatAppearance.MouseOverBackColor = Color.Transparent;
            btnSearch.FlatStyle = FlatStyle.Flat;
            btnSearch.Font = new Font("Microsoft Sans Serif", 11.9999981F, FontStyle.Regular, GraphicsUnit.Point);
            btnSearch.Location = new Point(786, 302);
            btnSearch.Name = "btnSearch";
            btnSearch.OnHoverBorderColor = Color.Transparent;
            btnSearch.OnHoverButtonColor = Color.CornflowerBlue;
            btnSearch.OnHoverTextColor = Color.White;
            btnSearch.Size = new Size(200, 69);
            btnSearch.TabIndex = 35;
            btnSearch.Text = "Search Flights";
            btnSearch.TextColor = Color.White;
            btnSearch.UseVisualStyleBackColor = false;
            btnSearch.Click += btnSearch_Click;
            // 
            // lblReturn
            // 
            lblReturn.AutoSize = true;
            lblReturn.BackColor = Color.Transparent;
            lblReturn.FlatStyle = FlatStyle.Flat;
            lblReturn.Font = new Font("Microsoft Sans Serif", 11.9999981F, FontStyle.Bold, GraphicsUnit.Point);
            lblReturn.ForeColor = Color.DimGray;
            lblReturn.Location = new Point(786, 161);
            lblReturn.Name = "lblReturn";
            lblReturn.Size = new Size(64, 20);
            lblReturn.TabIndex = 34;
            lblReturn.Text = "Return";
            // 
            // dpReturn
            // 
            dpReturn.BorderColor = Color.SteelBlue;
            dpReturn.BorderSize = 1;
            dpReturn.CalendarFont = new Font("Microsoft Sans Serif", 11.9999981F, FontStyle.Regular, GraphicsUnit.Point);
            dpReturn.DropDownAlign = LeftRightAlignment.Right;
            dpReturn.Font = new Font("Microsoft Sans Serif", 11.9999981F, FontStyle.Regular, GraphicsUnit.Point);
            dpReturn.Format = DateTimePickerFormat.Short;
            dpReturn.Location = new Point(786, 183);
            dpReturn.MinimumSize = new Size(0, 54);
            dpReturn.Name = "dpReturn";
            dpReturn.Size = new Size(200, 54);
            dpReturn.SkinColor = Color.WhiteSmoke;
            dpReturn.TabIndex = 33;
            dpReturn.TextColor = Color.DimGray;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.Transparent;
            label6.FlatStyle = FlatStyle.Flat;
            label6.Font = new Font("Microsoft Sans Serif", 11.9999981F, FontStyle.Bold, GraphicsUnit.Point);
            label6.ForeColor = Color.DimGray;
            label6.Location = new Point(583, 161);
            label6.Name = "label6";
            label6.Size = new Size(64, 20);
            label6.TabIndex = 32;
            label6.Text = "Depart";
            // 
            // dpDepart
            // 
            dpDepart.BorderColor = Color.SteelBlue;
            dpDepart.BorderSize = 1;
            dpDepart.CalendarFont = new Font("Microsoft Sans Serif", 11.9999981F, FontStyle.Regular, GraphicsUnit.Point);
            dpDepart.DropDownAlign = LeftRightAlignment.Right;
            dpDepart.Font = new Font("Microsoft Sans Serif", 11.9999981F, FontStyle.Regular, GraphicsUnit.Point);
            dpDepart.Format = DateTimePickerFormat.Short;
            dpDepart.Location = new Point(580, 183);
            dpDepart.MinimumSize = new Size(0, 54);
            dpDepart.Name = "dpDepart";
            dpDepart.Size = new Size(200, 54);
            dpDepart.SkinColor = Color.WhiteSmoke;
            dpDepart.TabIndex = 31;
            dpDepart.TextColor = Color.DimGray;
            // 
            // cbToLoc
            // 
            cbToLoc.AutoCompleteMode = AutoCompleteMode.Suggest;
            cbToLoc.AutoCompleteSource = AutoCompleteSource.ListItems;
            cbToLoc.BackColor = Color.WhiteSmoke;
            cbToLoc.BorderColor = Color.SteelBlue;
            cbToLoc.BorderSize = 1;
            cbToLoc.DropDownStyle = ComboBoxStyle.DropDown;
            cbToLoc.Font = new Font("Microsoft Sans Serif", 11.9999981F, FontStyle.Regular, GraphicsUnit.Point);
            cbToLoc.ForeColor = Color.DimGray;
            cbToLoc.IconColor = Color.SteelBlue;
            cbToLoc.Items.AddRange(new object[] { "Batanes", "Manila", "Palawan", "South Korea", "Japan", "Vietnam" });
            cbToLoc.ListBackColor = Color.WhiteSmoke;
            cbToLoc.ListTextColor = Color.DimGray;
            cbToLoc.Location = new Point(312, 183);
            cbToLoc.MinimumSize = new Size(150, 30);
            cbToLoc.Name = "cbToLoc";
            cbToLoc.Padding = new Padding(1);
            cbToLoc.Size = new Size(208, 54);
            cbToLoc.TabIndex = 30;
            cbToLoc.Texts = "";
            // 
            // cbFromLoc
            // 
            cbFromLoc.AutoCompleteMode = AutoCompleteMode.Suggest;
            cbFromLoc.AutoCompleteSource = AutoCompleteSource.ListItems;
            cbFromLoc.BackColor = Color.WhiteSmoke;
            cbFromLoc.BorderColor = Color.SteelBlue;
            cbFromLoc.BorderSize = 1;
            cbFromLoc.DropDownStyle = ComboBoxStyle.DropDown;
            cbFromLoc.Font = new Font("Microsoft Sans Serif", 11.9999981F, FontStyle.Regular, GraphicsUnit.Point);
            cbFromLoc.ForeColor = Color.DimGray;
            cbFromLoc.IconColor = Color.SteelBlue;
            cbFromLoc.Items.AddRange(new object[] { "Manila", "Batanes", "Palawan", "South Korea", "Japan", "Vietnam" });
            cbFromLoc.ListBackColor = Color.WhiteSmoke;
            cbFromLoc.ListTextColor = Color.DimGray;
            cbFromLoc.Location = new Point(98, 183);
            cbFromLoc.MinimumSize = new Size(150, 30);
            cbFromLoc.Name = "cbFromLoc";
            cbFromLoc.Padding = new Padding(1);
            cbFromLoc.Size = new Size(208, 54);
            cbFromLoc.TabIndex = 29;
            cbFromLoc.Texts = "";
            // 
            // cbFtrip
            // 
            cbFtrip.AutoCompleteMode = AutoCompleteMode.Suggest;
            cbFtrip.AutoCompleteSource = AutoCompleteSource.ListItems;
            cbFtrip.BackColor = Color.WhiteSmoke;
            cbFtrip.BorderColor = Color.SteelBlue;
            cbFtrip.BorderSize = 1;
            cbFtrip.DropDownStyle = ComboBoxStyle.DropDownList;
            cbFtrip.Font = new Font("Microsoft Sans Serif", 11.9999981F, FontStyle.Regular, GraphicsUnit.Point);
            cbFtrip.ForeColor = Color.DimGray;
            cbFtrip.IconColor = Color.SteelBlue;
            cbFtrip.Items.AddRange(new object[] { "One-way", "Round-trip" });
            cbFtrip.ListBackColor = Color.WhiteSmoke;
            cbFtrip.ListTextColor = Color.DimGray;
            cbFtrip.Location = new Point(270, 77);
            cbFtrip.MinimumSize = new Size(150, 30);
            cbFtrip.Name = "cbFtrip";
            cbFtrip.Padding = new Padding(1);
            cbFtrip.Size = new Size(150, 32);
            cbFtrip.TabIndex = 28;
            cbFtrip.Texts = "";
            cbFtrip.OnSelectedIndexChanged += cbFtrip_OnSelectedIndexChanged;
            // 
            // cbFtype
            // 
            cbFtype.AutoCompleteMode = AutoCompleteMode.Suggest;
            cbFtype.AutoCompleteSource = AutoCompleteSource.ListItems;
            cbFtype.BackColor = Color.WhiteSmoke;
            cbFtype.BorderColor = Color.SteelBlue;
            cbFtype.BorderSize = 1;
            cbFtype.DropDownStyle = ComboBoxStyle.DropDownList;
            cbFtype.Font = new Font("Microsoft Sans Serif", 11.9999981F, FontStyle.Regular, GraphicsUnit.Point);
            cbFtype.ForeColor = Color.DimGray;
            cbFtype.IconColor = Color.SteelBlue;
            cbFtype.Items.AddRange(new object[] { "Regular", "Bussiness", "Private" });
            cbFtype.ListBackColor = Color.WhiteSmoke;
            cbFtype.ListTextColor = Color.DimGray;
            cbFtype.Location = new Point(98, 77);
            cbFtype.MinimumSize = new Size(150, 30);
            cbFtype.Name = "cbFtype";
            cbFtype.Padding = new Padding(1);
            cbFtype.Size = new Size(150, 32);
            cbFtype.TabIndex = 27;
            cbFtype.Texts = "";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Transparent;
            label5.FlatStyle = FlatStyle.Flat;
            label5.Font = new Font("Microsoft Sans Serif", 11.9999981F, FontStyle.Bold, GraphicsUnit.Point);
            label5.ForeColor = Color.DimGray;
            label5.Location = new Point(270, 55);
            label5.Name = "label5";
            label5.Size = new Size(39, 20);
            label5.TabIndex = 26;
            label5.Text = "Trip";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Transparent;
            label4.FlatStyle = FlatStyle.Flat;
            label4.Font = new Font("Microsoft Sans Serif", 11.9999981F, FontStyle.Bold, GraphicsUnit.Point);
            label4.ForeColor = Color.DimGray;
            label4.Location = new Point(98, 55);
            label4.Name = "label4";
            label4.Size = new Size(47, 20);
            label4.TabIndex = 25;
            label4.Text = "Type";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.FlatStyle = FlatStyle.Flat;
            label3.Font = new Font("Microsoft Sans Serif", 11.9999981F, FontStyle.Bold, GraphicsUnit.Point);
            label3.ForeColor = Color.DimGray;
            label3.Location = new Point(312, 161);
            label3.Name = "label3";
            label3.Size = new Size(29, 20);
            label3.TabIndex = 24;
            label3.Text = "To";
            // 
            // lblFrom
            // 
            lblFrom.AutoSize = true;
            lblFrom.BackColor = Color.Transparent;
            lblFrom.FlatStyle = FlatStyle.Flat;
            lblFrom.Font = new Font("Microsoft Sans Serif", 11.9999981F, FontStyle.Bold, GraphicsUnit.Point);
            lblFrom.ForeColor = Color.DimGray;
            lblFrom.Location = new Point(98, 161);
            lblFrom.Name = "lblFrom";
            lblFrom.Size = new Size(50, 20);
            lblFrom.TabIndex = 23;
            lblFrom.Text = "From";
            // 
            // lblSenior
            // 
            lblSenior.AutoSize = true;
            lblSenior.BackColor = Color.Transparent;
            lblSenior.FlatStyle = FlatStyle.Flat;
            lblSenior.Font = new Font("Microsoft Sans Serif", 11.9999981F, FontStyle.Bold, GraphicsUnit.Point);
            lblSenior.ForeColor = Color.DimGray;
            lblSenior.Location = new Point(697, 81);
            lblSenior.Name = "lblSenior";
            lblSenior.Size = new Size(83, 20);
            lblSenior.TabIndex = 17;
            lblSenior.Text = "Senior C.";
            // 
            // lblChild
            // 
            lblChild.AutoSize = true;
            lblChild.BackColor = Color.Transparent;
            lblChild.FlatStyle = FlatStyle.Flat;
            lblChild.Font = new Font("Microsoft Sans Serif", 11.9999981F, FontStyle.Bold, GraphicsUnit.Point);
            lblChild.ForeColor = Color.DimGray;
            lblChild.Location = new Point(579, 81);
            lblChild.Name = "lblChild";
            lblChild.Size = new Size(49, 20);
            lblChild.TabIndex = 13;
            lblChild.Text = "Child";
            // 
            // lblAdult
            // 
            lblAdult.AutoSize = true;
            lblAdult.BackColor = Color.Transparent;
            lblAdult.FlatStyle = FlatStyle.Flat;
            lblAdult.Font = new Font("Microsoft Sans Serif", 11.9999981F, FontStyle.Bold, GraphicsUnit.Point);
            lblAdult.ForeColor = Color.DimGray;
            lblAdult.Location = new Point(459, 81);
            lblAdult.Name = "lblAdult";
            lblAdult.Size = new Size(51, 20);
            lblAdult.TabIndex = 2;
            lblAdult.Text = "Adult";
            // 
            // cbOption
            // 
            cbOption.BackColor = Color.Transparent;
            cbOption.BorderColor = Color.Transparent;
            cbOption.BorderSize = 1;
            cbOption.DropDownStyle = ComboBoxStyle.DropDownList;
            cbOption.Font = new Font("Microsoft Sans Serif", 11.9999981F, FontStyle.Bold, GraphicsUnit.Point);
            cbOption.ForeColor = Color.DimGray;
            cbOption.IconColor = Color.DimGray;
            cbOption.Items.AddRange(new object[] { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J" });
            cbOption.ListBackColor = Color.WhiteSmoke;
            cbOption.ListTextColor = Color.DimGray;
            cbOption.Location = new Point(461, 157);
            cbOption.MinimumSize = new Size(60, 19);
            cbOption.Name = "cbOption";
            cbOption.Padding = new Padding(1);
            cbOption.Size = new Size(60, 29);
            cbOption.TabIndex = 36;
            cbOption.Texts = "";
            cbOption.OnSelectedIndexChanged += cbOption_OnSelectedIndexChanged;
            // 
            // cbAdult
            // 
            cbAdult.BackColor = Color.White;
            cbAdult.CausesValidation = false;
            cbAdult.DropDownStyle = ComboBoxStyle.DropDownList;
            cbAdult.FlatStyle = FlatStyle.Flat;
            cbAdult.Font = new Font("Microsoft Sans Serif", 11.9999981F, FontStyle.Regular, GraphicsUnit.Point);
            cbAdult.ForeColor = Color.DimGray;
            cbAdult.FormattingEnabled = true;
            cbAdult.Items.AddRange(new object[] { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10" });
            cbAdult.Location = new Point(512, 77);
            cbAdult.Name = "cbAdult";
            cbAdult.Size = new Size(61, 28);
            cbAdult.TabIndex = 41;
            // 
            // cbChild
            // 
            cbChild.BackColor = Color.White;
            cbChild.CausesValidation = false;
            cbChild.DropDownStyle = ComboBoxStyle.DropDownList;
            cbChild.FlatStyle = FlatStyle.Flat;
            cbChild.Font = new Font("Microsoft Sans Serif", 11.9999981F, FontStyle.Regular, GraphicsUnit.Point);
            cbChild.ForeColor = Color.DimGray;
            cbChild.FormattingEnabled = true;
            cbChild.Items.AddRange(new object[] { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10" });
            cbChild.Location = new Point(631, 78);
            cbChild.Name = "cbChild";
            cbChild.Size = new Size(61, 28);
            cbChild.TabIndex = 42;
            // 
            // cbSenior
            // 
            cbSenior.BackColor = Color.White;
            cbSenior.CausesValidation = false;
            cbSenior.DropDownStyle = ComboBoxStyle.DropDownList;
            cbSenior.FlatStyle = FlatStyle.Flat;
            cbSenior.Font = new Font("Microsoft Sans Serif", 11.9999981F, FontStyle.Regular, GraphicsUnit.Point);
            cbSenior.ForeColor = Color.DimGray;
            cbSenior.FormattingEnabled = true;
            cbSenior.Items.AddRange(new object[] { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10" });
            cbSenior.Location = new Point(781, 78);
            cbSenior.Name = "cbSenior";
            cbSenior.Size = new Size(61, 28);
            cbSenior.TabIndex = 43;
            // 
            // marginLeft
            // 
            marginLeft.BackColor = Color.Transparent;
            marginLeft.Dock = DockStyle.Left;
            marginLeft.Location = new Point(0, 70);
            marginLeft.Name = "marginLeft";
            marginLeft.Size = new Size(100, 650);
            marginLeft.TabIndex = 1;
            // 
            // marginRight
            // 
            marginRight.BackColor = Color.Transparent;
            marginRight.Dock = DockStyle.Right;
            marginRight.Location = new Point(1200, 70);
            marginRight.Name = "marginRight";
            marginRight.Size = new Size(100, 650);
            marginRight.TabIndex = 2;
            // 
            // marginBottom
            // 
            marginBottom.BackColor = Color.Transparent;
            marginBottom.Dock = DockStyle.Bottom;
            marginBottom.Location = new Point(100, 601);
            marginBottom.Name = "marginBottom";
            marginBottom.Size = new Size(1100, 119);
            marginBottom.TabIndex = 3;
            // 
            // marginTop
            // 
            marginTop.BackColor = Color.Transparent;
            marginTop.Controls.Add(label1);
            marginTop.Dock = DockStyle.Top;
            marginTop.Location = new Point(100, 70);
            marginTop.Name = "marginTop";
            marginTop.Size = new Size(1100, 100);
            marginTop.TabIndex = 4;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft Sans Serif", 27.7499962F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.White;
            label1.Location = new Point(339, 27);
            label1.Name = "label1";
            label1.Size = new Size(456, 42);
            label1.TabIndex = 0;
            label1.Text = "Your flight is safe with us";
            // 
            // eclipeControl3
            // 
            eclipeControl3.CornerRadius = 40;
            eclipeControl3.TargetControl = this;
            // 
            // eclipeControl4
            // 
            eclipeControl4.CornerRadius = 40;
            eclipeControl4.TargetControl = mainPanel;
            // 
            // eclipeControl5
            // 
            eclipeControl5.CornerRadius = 50;
            eclipeControl5.TargetControl = flightsPanel;
            // 
            // MainForm
            // 
            AutoScaleMode = AutoScaleMode.None;
            BackColor = Color.WhiteSmoke;
            BackgroundImage = Properties.Resources.bg_mainform;
            ClientSize = new Size(1300, 720);
            Controls.Add(mainPanel);
            Controls.Add(marginTop);
            Controls.Add(marginBottom);
            Controls.Add(marginRight);
            Controls.Add(marginLeft);
            Controls.Add(menuPanel);
            FormBorderStyle = FormBorderStyle.None;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "MainForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "MainForm";
            Load += MainForm_Load;
            menuPanel.ResumeLayout(false);
            menuPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)minimize).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)exit).EndInit();
            mainPanel.ResumeLayout(false);
            mainPanel.PerformLayout();
            flightsPanel.ResumeLayout(false);
            flightsPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox12).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox13).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            panel7.ResumeLayout(false);
            panel5.ResumeLayout(false);
            panel3.ResumeLayout(false);
            panel1.ResumeLayout(false);
            marginTop.ResumeLayout(false);
            marginTop.PerformLayout();
            ResumeLayout(false);
        }

        #endregion
        private Panel menuPanel;
        private PictureBox exit;
        private Panel mainPanel;
        private Panel marginTop;
        private Panel marginBottom;
        private Panel marginRight;
        private Panel marginLeft;
        private RJComboBox cbFlightTrip;
        private Label label1;
        private Button btnTravelInfo;
        private Button btnExplore;
        private Button btnAbout;
        private Button btnBook;
        private Button btnManage;
        private Label label2;
        private PictureBox pictureBox2;
        private PictureBox minimize;
        private PictureBox pictureBox1;
        private RJComboBox cbFlightType;
        private Label lblAdult;
        private Label lblChild;
        private Label lblSenior;
        private Label lblFrom;
        private RJComboBox cbTo;
        private RJComboBox cbFrom;
        private Label label3;
        private Label label5;
        private Label label4;
        private ePOSOne.btnProduct.Button_WOC btnSearchFlight;
        private EclipeControl eclipeControl3;
        private EclipeControl eclipeControl4;
        private Label lblReturn;
        private Label label6;
        private ePOSOne.btnProduct.Button_WOC btnSearch;
        private RJComboBox cbOption;
        private EclipeControl eclipeControl5;
        private Button logOut;
        public ComboBox cbAdult;
        public ComboBox cbSenior;
        public ComboBox cbChild;
        private Panel flightsPanel;
        private Label flightFare3;
        private Label flightCode3;
        private PictureBox pictureBox10;
        private Label flightTime3;
        private PictureBox pictureBox11;
        private Label arriveLoc3;
        private Label departLoc3;
        private PictureBox pictureBox12;
        private Label arriveTime3;
        private Label departTime3;
        private PictureBox pictureBox13;
        private Label flightFare2;
        private Label flightCode2;
        private PictureBox pictureBox7;
        private Label flightTime2;
        private PictureBox pictureBox8;
        private Label arriveLoc2;
        private Label departLoc2;
        private PictureBox pictureBox9;
        private Label arriveTime2;
        private Label departTime2;
        private Label flightFare1;
        private Label flightCode1;
        private PictureBox pictureBox6;
        private Label flightTime1;
        private PictureBox pictureBox5;
        private Label arriveLoc1;
        private Label departLoc1;
        private PictureBox pictureBox4;
        private PictureBox pictureBox3;
        private Label arriveTime1;
        private Label departTime1;
        private ePOSOne.btnProduct.Button_WOC btnSelectFlight3;
        private ePOSOne.btnProduct.Button_WOC btnSelectFlight2;
        private ePOSOne.btnProduct.Button_WOC btnSelectFlight1;
        private Panel panel7;
        private Panel panel8;
        private Panel panel5;
        private Panel panel6;
        private Panel panel3;
        private Panel panel4;
        private Panel panel1;
        private Panel panel2;
        private Button btnBackMain;
        public RJDatePicker dpDepart;
        public RJDatePicker dpReturn;
        internal RJComboBox cbFtype;
        internal RJComboBox cbFtrip;
        internal RJComboBox cbToLoc;
        internal RJComboBox cbFromLoc;
    }
}