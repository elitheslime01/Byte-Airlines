﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ByteAirline
{
    internal class Airplane
    {
        MainForm mainform = new MainForm();
        private string flightType;

        public string FlightType
        {
            get { return flightType; }
            set
            {

                flightType = value;
                mainform.cbFtype.SelectedItem = value;
            }
        }

        private string flightTrip;
        public string FlightTrip
        {
            get { return flightTrip; }
            set
            {
                flightTrip = value;
                mainform.cbFtrip.SelectedItem = value;
            }
        }
        private int adult;
        public int Adult
        {
            get { return adult; }
            set
            {
                adult = value;
                mainform.cbAdult.SelectedItem = value.ToString();
            }
        }

        private int child;
        public int Child
        {
            get { return child; }
            set
            {
                child = value;
                mainform.cbChild.SelectedItem = value.ToString();
            }
        }
        private int senior;
        public int Senior
        {
            get { return senior; }
            set
            {
                senior = value;
                mainform.cbSenior.SelectedItem = value.ToString();
            }
        }

        private string fromLoc;
        public string FromLoc
        {
            get { return fromLoc; }
            set
            {
                fromLoc = value;
                mainform.cbFromLoc.SelectedItem = value;
            }
        }

        private string toLoc;
        public string ToLoc
        {
            get { return toLoc; }
            set
            {
                toLoc = value;
                mainform.cbToLoc.SelectedItem = value;
            }
        }

        private DateTime departDate;

        public DateTime DepartDate
        {
            get { return departDate; }
            set
            {
                departDate = value;
                mainform.dpDepart.Value = value;
            }
        }

        private DateTime returnDate;
        public DateTime ReturnDate
        {
            get { return returnDate; }
            set
            {
                returnDate = value;
                mainform.dpReturn.Value = value;
            }
        }

        private bool insurance;
        public bool Insurance
        {
            get { return insurance; }
            set
            {
                insurance = value;
            }
        }

        private string time1;
        public string Time1
        {
            get { return time1; }
            set
            {
                time1 = value;
            }
        }
        private string time2;
        public string Time2
        {
            get { return time2; }
            set
            {
                time2 = value;
            }
        }

        private string flightCode;
        public string FlightCode
        {
            get { return flightCode; }
            set
            {
                flightCode = value;
            }
        }

        public (double, double, double, string) GetTravelDestination()
        {
            double regularClass = 0.0;
            double bussinessClass = 0.0;
            double privateClass = 0.0;
            string? travelType = "";

            if (FromLoc == "Manila" && ToLoc == "Batanes")
            {
                regularClass = 3500.00;
                bussinessClass = 12500.00;
                privateClass = 8000.00;
                travelType = "LOCAL Flight";
            }
            if (FromLoc == "Batanes" && ToLoc == "Manila")
            {
                regularClass = 3900.00;
                bussinessClass = 12950.00;
                privateClass = 9800.00;
                travelType = "LOCAL Flight";
            }
            if (FromLoc == "Manila" && ToLoc == "Palawan")
            {
                regularClass = 3200.00;
                bussinessClass = 10500.00;
                privateClass = 9100.00;
                travelType = "LOCAL Flight";
            }
            if (FromLoc == "Palawan" && ToLoc == "Manila")
            {
                regularClass = 3575.00;
                bussinessClass = 10975.00;
                privateClass = 9850.00;
                travelType = "LOCAL Flight";
            }
            if (FromLoc == "Manila" && ToLoc == "South Korea")
            {
                regularClass = 12055.00;
                bussinessClass = 37390.00;
                privateClass = 27450.00;
                travelType = "INTERNATIONAL Flight";
            }
            if (FromLoc == "South Korea" && ToLoc == "Manila")
            {
                regularClass = 13100.00;
                bussinessClass = 39650.00;
                privateClass = 30890.00;
                travelType = "INTERNATIONAL Flight";
            }
            if (FromLoc == "Manila" && ToLoc == "Japan")
            {
                regularClass = 27800.00;
                bussinessClass = 45355.00;
                privateClass = 40450.00;
                travelType = "INTERNATIONAL Flight";
            }
            if (FromLoc == "Japan" && ToLoc == "Manila")
            {
                regularClass = 29400.00;
                bussinessClass = 49780.00;
                privateClass = 43855.00;
                travelType = "INTERNATIONAL Flight";
            }
            if (FromLoc == "Manila" && ToLoc == "Vietnam")
            {
                regularClass = 3200.00;
                bussinessClass = 12345.00;
                privateClass = 8505.00;
                travelType = "INTERNATIONAL Flight";
            }
            if (FromLoc == "Vietnam" && ToLoc == "Manila")
            {
                regularClass = 4600.00;
                bussinessClass = 16320.00;
                privateClass = 14300.00;
                travelType = "INTERNATIONAL Flight";
            }

            return (regularClass, bussinessClass, privateClass, travelType);
        }
        public double AdultFare()
        {
            double adultFare = 0.0;
            (double regularClass, double bussinessClass, double privateClass, _) = GetTravelDestination();

            if (FlightType == "Regular")
            {
                if (FlightTrip == "One-way")
                {
                    adultFare = Adult * regularClass;
                }
                else if (FlightTrip == "Round-trip")
                {
                    adultFare = (Adult * regularClass) * 2;
                }
            }

            if (FlightType == "Bussiness")
            {
                if (FlightTrip == "One-way")
                {
                    adultFare = Adult * bussinessClass;
                }
                else if (FlightTrip == "Round-trip")
                {
                    adultFare = (Adult * bussinessClass) * 2;
                }
            }

            if (FlightType == "Private")
            {
                if (FlightTrip == "One-way")
                {
                    adultFare = Adult * privateClass;
                }
                else if (FlightTrip == "Round-trip")
                {
                    adultFare = (Adult * privateClass) * 2;
                }
            }

            return adultFare;
        }

        public double ChildFare()
        {
            double childFare = 0.0;
            (double regularClass, double bussinessClass, double privateClass, _) = GetTravelDestination();

            if (FlightType == "Regular")
            {
                if (FlightTrip == "One-way")
                {
                    childFare = Child * regularClass;
                }
                else if (FlightTrip == "Round-trip")
                {
                    childFare = (Child * regularClass) * 2;
                }
            }

            if (FlightType == "Bussiness")
            {
                if (FlightTrip == "One-way")
                {
                    childFare = Child * bussinessClass;
                }
                else if (FlightTrip == "Round-trip")
                {
                    childFare = (Child * bussinessClass) * 2;
                }
            }

            if (FlightType == "Private")
            {
                if (FlightTrip == "One-way")
                {
                    childFare = Child * privateClass;
                }
                else if (FlightTrip == "Round-trip")
                {
                    childFare = (Child * privateClass) * 2;
                }
            }

            return childFare;
        }
        public double SeniorFare()
        {
            double seniorFare = 0.0;
            (double regularClass, double bussinessClass, double privateClass, _) = GetTravelDestination();

            if (FlightType == "Regular")
            {
                if (FlightTrip == "One-way")
                {
                    seniorFare = (Senior * regularClass);
                }
                else if (FlightTrip == "Round-trip")
                {
                    seniorFare = (Senior * regularClass) * 2;
                }
            }

            if (FlightType == "Bussiness")
            {
                if (FlightTrip == "One-way")
                {
                    seniorFare = Senior * bussinessClass;
                }
                else if (FlightTrip == "Round-trip")
                {
                    seniorFare = (Senior * bussinessClass) * 2;
                }
            }

            if (FlightType == "Private")
            {
                if (FlightTrip == "One-way")
                {
                    seniorFare = Senior * privateClass;
                }
                else if (FlightTrip == "Round-trip")
                {
                    seniorFare = (Senior * privateClass) * 2;
                }
            }

            return seniorFare;
        }

        public double seniorFareDiscounted()
        {
            return SeniorFare() - (SeniorFare() * 0.8);
        }

        public double TravelInsurance()
        {
            double travelInsurance = 0.0;

            if (Insurance == true)
            {
                if (FlightType == "Regular")
                {
                    travelInsurance = (Adult + Child + Senior) * 950.00;
                }
                if (FlightType == "Bussiness")
                {
                    travelInsurance = (Adult + Child + Senior) * 6500.00;
                }
                if (FlightType == "Private")
                {
                    travelInsurance = (Adult + Child + Senior) * 4500.00;
                }
            }
            else
            {
                travelInsurance = 0.0;
            }
            return travelInsurance;
        }
        public double TravelTax()
        {
            double travelTax = 0.0;

            if (FlightType == "Regular")
            {
                travelTax = (Adult + Child) * 2500.00;
            }
            if (FlightType == "Bussiness")
            {
                travelTax = (Adult + Child) * 5700.00;
            }
            if (FlightType == "Private")
            {
                travelTax = (Adult + Child) * 4260.00;
            }

            return travelTax;
        }
        public double BaggageFee()
        {
            double baggageFee = 0.0;

            if (FlightType == "Regular")
            {
                baggageFee = (Adult + Child + Senior) * 950.00;
            }
            if (FlightType == "Bussiness")
            {
                baggageFee = (Adult + Child + Senior) * 2850.00;
            }
            if (FlightType == "Private")
            {
                baggageFee = (Adult + Child + Senior) * 1250.00;
            }

            return baggageFee;
        }

        public double TransactionFee()
        {
            double transFee = 0.0;

            if (FlightType == "Regular")
            {
                transFee = (Adult + Child + Senior) * 255.00;
            }
            if (FlightType == "Bussiness")
            {
                transFee = (Adult + Child + Senior) * 550.00;
            }
            if (FlightType == "Private")
            {
                transFee = (Adult + Child + Senior) * 550.00;
            }
            
            return transFee;
        }

        public double TotalFee()
        {
            return AdultFare() + ChildFare() + (SeniorFare() - seniorFareDiscounted()) +
                   TravelInsurance() + TravelTax() + BaggageFee() + TransactionFee(); 
        }

    }
}
