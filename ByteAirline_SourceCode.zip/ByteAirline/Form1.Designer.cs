﻿namespace ByteAirline
{
    partial class Login
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Login));
            pictureBox1 = new PictureBox();
            tbEmail = new CustButtons();
            tbPassword = new CustButtons();
            btnSignin = new ePOSOne.btnProduct.Button_WOC();
            btnRegister = new Button();
            pictureBox2 = new PictureBox();
            eclipeControl1 = new EclipeControl();
            exit = new PictureBox();
            minimize = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)exit).BeginInit();
            ((System.ComponentModel.ISupportInitialize)minimize).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Dock = DockStyle.Left;
            pictureBox1.Image = Properties.Resources.bg_login;
            pictureBox1.Location = new Point(0, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(400, 650);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // tbEmail
            // 
            tbEmail.BackColor = SystemColors.Window;
            tbEmail.BorderColor = Color.LightSlateGray;
            tbEmail.BorderFocusColor = Color.SteelBlue;
            tbEmail.BorderRadius = 0;
            tbEmail.BorderSize = 3;
            tbEmail.Font = new Font("Lato", 11.9999981F, FontStyle.Regular, GraphicsUnit.Point);
            tbEmail.ForeColor = Color.DimGray;
            tbEmail.Location = new Point(530, 247);
            tbEmail.Multiline = true;
            tbEmail.Name = "tbEmail";
            tbEmail.Padding = new Padding(10, 7, 10, 7);
            tbEmail.PasswordChar = false;
            tbEmail.PlaceholderColor = Color.DarkGray;
            tbEmail.PlaceholderText = "Email";
            tbEmail.Size = new Size(343, 34);
            tbEmail.TabIndex = 1;
            tbEmail.Texts = "";
            tbEmail.UnderlinedStyle = true;
            // 
            // tbPassword
            // 
            tbPassword.BackColor = SystemColors.Window;
            tbPassword.BorderColor = Color.LightSlateGray;
            tbPassword.BorderFocusColor = Color.SteelBlue;
            tbPassword.BorderRadius = 0;
            tbPassword.BorderSize = 3;
            tbPassword.Font = new Font("Lato", 11.9999981F, FontStyle.Regular, GraphicsUnit.Point);
            tbPassword.ForeColor = Color.DimGray;
            tbPassword.Location = new Point(530, 340);
            tbPassword.Multiline = false;
            tbPassword.Name = "tbPassword";
            tbPassword.Padding = new Padding(10, 7, 10, 7);
            tbPassword.PasswordChar = true;
            tbPassword.PlaceholderColor = Color.DarkGray;
            tbPassword.PlaceholderText = "Password";
            tbPassword.Size = new Size(343, 34);
            tbPassword.TabIndex = 2;
            tbPassword.Texts = "";
            tbPassword.UnderlinedStyle = true;
            // 
            // btnSignin
            // 
            btnSignin.BackColor = Color.Transparent;
            btnSignin.BorderColor = Color.Transparent;
            btnSignin.ButtonColor = Color.SteelBlue;
            btnSignin.Cursor = Cursors.Hand;
            btnSignin.FlatAppearance.BorderSize = 0;
            btnSignin.FlatAppearance.MouseDownBackColor = Color.Transparent;
            btnSignin.FlatAppearance.MouseOverBackColor = Color.Transparent;
            btnSignin.FlatStyle = FlatStyle.Flat;
            btnSignin.Font = new Font("Lato", 11.9999981F, FontStyle.Regular, GraphicsUnit.Point);
            btnSignin.Location = new Point(741, 422);
            btnSignin.Name = "btnSignin";
            btnSignin.OnHoverBorderColor = Color.Transparent;
            btnSignin.OnHoverButtonColor = Color.CornflowerBlue;
            btnSignin.OnHoverTextColor = Color.White;
            btnSignin.Size = new Size(132, 49);
            btnSignin.TabIndex = 3;
            btnSignin.Text = "Sign In";
            btnSignin.TextColor = Color.White;
            btnSignin.UseVisualStyleBackColor = false;
            btnSignin.Click += btnSignin_Click;
            // 
            // btnRegister
            // 
            btnRegister.BackColor = Color.Transparent;
            btnRegister.Cursor = Cursors.Hand;
            btnRegister.FlatAppearance.BorderSize = 0;
            btnRegister.FlatAppearance.MouseDownBackColor = Color.Transparent;
            btnRegister.FlatAppearance.MouseOverBackColor = Color.Transparent;
            btnRegister.FlatStyle = FlatStyle.Flat;
            btnRegister.Font = new Font("Lato", 11.9999981F, FontStyle.Regular, GraphicsUnit.Point);
            btnRegister.ForeColor = Color.Gray;
            btnRegister.Location = new Point(522, 430);
            btnRegister.Name = "btnRegister";
            btnRegister.Size = new Size(152, 33);
            btnRegister.TabIndex = 4;
            btnRegister.Text = "Need an account?";
            btnRegister.TextAlign = ContentAlignment.MiddleLeft;
            btnRegister.UseVisualStyleBackColor = false;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.logo__2_;
            pictureBox2.Location = new Point(669, 148);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(65, 65);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 5;
            pictureBox2.TabStop = false;
            // 
            // eclipeControl1
            // 
            eclipeControl1.CornerRadius = 40;
            eclipeControl1.TargetControl = this;
            // 
            // exit
            // 
            exit.Cursor = Cursors.Hand;
            exit.Image = Properties.Resources.exit;
            exit.Location = new Point(955, 21);
            exit.Name = "exit";
            exit.Size = new Size(20, 20);
            exit.SizeMode = PictureBoxSizeMode.StretchImage;
            exit.TabIndex = 6;
            exit.TabStop = false;
            exit.Click += pictureBox3_Click;
            // 
            // minimize
            // 
            minimize.Cursor = Cursors.Hand;
            minimize.Image = Properties.Resources.minimize;
            minimize.Location = new Point(929, 21);
            minimize.Name = "minimize";
            minimize.Size = new Size(20, 20);
            minimize.SizeMode = PictureBoxSizeMode.StretchImage;
            minimize.TabIndex = 7;
            minimize.TabStop = false;
            minimize.Click += minimize_Click;
            // 
            // Login
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.WhiteSmoke;
            ClientSize = new Size(1000, 650);
            Controls.Add(minimize);
            Controls.Add(exit);
            Controls.Add(pictureBox2);
            Controls.Add(btnRegister);
            Controls.Add(btnSignin);
            Controls.Add(tbPassword);
            Controls.Add(tbEmail);
            Controls.Add(pictureBox1);
            FormBorderStyle = FormBorderStyle.None;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Login";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form1";
            MouseDown += Login_MouseDown;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)exit).EndInit();
            ((System.ComponentModel.ISupportInitialize)minimize).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private PictureBox pictureBox1;
        private CustButtons tbEmail;
        private CustButtons tbPassword;
        private ePOSOne.btnProduct.Button_WOC btnSignin;
        private Button btnRegister;
        private PictureBox pictureBox2;
        private EclipeControl eclipeControl1;
        private PictureBox exit;
        private PictureBox minimize;
    }
}