﻿namespace ByteAirline
{
    partial class DetailForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DetailForm));
            menuPanel = new Panel();
            minimize1 = new PictureBox();
            logOut1 = new Button();
            exit1 = new PictureBox();
            pictureBox1 = new PictureBox();
            minimize = new PictureBox();
            pictureBox2 = new PictureBox();
            label2 = new Label();
            btnBook = new Button();
            btnManage = new Button();
            btnTravelInfo = new Button();
            btnExplore = new Button();
            btnAbout = new Button();
            exit = new PictureBox();
            eclipeControl1 = new EclipeControl();
            marginLeft = new Panel();
            marginRight = new Panel();
            marginBottom = new Panel();
            marginTop = new Panel();
            label1 = new Label();
            detailPanel = new Panel();
            checkOutPanel = new Panel();
            custButtons4 = new CustButtons();
            label21 = new Label();
            label20 = new Label();
            label19 = new Label();
            label18 = new Label();
            label17 = new Label();
            label15 = new Label();
            label12 = new Label();
            custButtons3 = new CustButtons();
            custButtons2 = new CustButtons();
            custButtons1 = new CustButtons();
            tbEmail = new CustButtons();
            lbSeniorFare = new Label();
            lbChildFare = new Label();
            label8 = new Label();
            label6 = new Label();
            label4 = new Label();
            totalFare = new Label();
            panel1 = new Panel();
            panel4 = new Panel();
            label16 = new Label();
            btnPay = new ePOSOne.btnProduct.Button_WOC();
            lbSeniorDiscount = new Label();
            label14 = new Label();
            lbAdditionalCharges = new Label();
            label13 = new Label();
            lbBaggageFee = new Label();
            label11 = new Label();
            lbTravelTax = new Label();
            label7 = new Label();
            lbTravelInsurance = new Label();
            label5 = new Label();
            lbAdultFare = new Label();
            label3 = new Label();
            returnPanel = new Panel();
            flightReturn = new Label();
            flightType2 = new Label();
            flightCode2 = new Label();
            arriveLoc2 = new Label();
            departLoc2 = new Label();
            pictureBox4 = new PictureBox();
            arriveTime2 = new Label();
            departTime2 = new Label();
            flightDepart = new Label();
            flightType1 = new Label();
            flightCode1 = new Label();
            arriveLoc1 = new Label();
            departLoc1 = new Label();
            pictureBox3 = new PictureBox();
            arriveTime1 = new Label();
            departTime1 = new Label();
            lbCheckOut = new Label();
            panel2 = new Panel();
            panel3 = new Panel();
            panel5 = new Panel();
            panel6 = new Panel();
            tabControl1 = new TabControl();
            btnConfirm = new ePOSOne.btnProduct.Button_WOC();
            eclipeControl2 = new EclipeControl();
            menuPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)minimize1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)exit1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)minimize).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)exit).BeginInit();
            marginTop.SuspendLayout();
            detailPanel.SuspendLayout();
            checkOutPanel.SuspendLayout();
            panel1.SuspendLayout();
            returnPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            panel2.SuspendLayout();
            panel5.SuspendLayout();
            SuspendLayout();
            // 
            // menuPanel
            // 
            menuPanel.BackColor = Color.Transparent;
            menuPanel.Controls.Add(minimize1);
            menuPanel.Controls.Add(logOut1);
            menuPanel.Controls.Add(exit1);
            menuPanel.Controls.Add(pictureBox1);
            menuPanel.Controls.Add(minimize);
            menuPanel.Controls.Add(pictureBox2);
            menuPanel.Controls.Add(label2);
            menuPanel.Controls.Add(btnBook);
            menuPanel.Controls.Add(btnManage);
            menuPanel.Controls.Add(btnTravelInfo);
            menuPanel.Controls.Add(btnExplore);
            menuPanel.Controls.Add(btnAbout);
            menuPanel.Controls.Add(exit);
            menuPanel.Dock = DockStyle.Top;
            menuPanel.Location = new Point(0, 0);
            menuPanel.Name = "menuPanel";
            menuPanel.Size = new Size(1300, 70);
            menuPanel.TabIndex = 1;
            menuPanel.MouseDown += menuPanel_MouseDown;
            // 
            // minimize1
            // 
            minimize1.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            minimize1.Cursor = Cursors.Hand;
            minimize1.Image = Properties.Resources.minimize_light;
            minimize1.Location = new Point(1229, 23);
            minimize1.Name = "minimize1";
            minimize1.Size = new Size(20, 20);
            minimize1.SizeMode = PictureBoxSizeMode.StretchImage;
            minimize1.TabIndex = 10;
            minimize1.TabStop = false;
            minimize1.Click += minimize1_Click;
            // 
            // logOut1
            // 
            logOut1.BackColor = Color.Transparent;
            logOut1.Cursor = Cursors.Hand;
            logOut1.FlatAppearance.BorderSize = 0;
            logOut1.FlatAppearance.MouseDownBackColor = Color.Transparent;
            logOut1.FlatAppearance.MouseOverBackColor = Color.Transparent;
            logOut1.FlatStyle = FlatStyle.Flat;
            logOut1.Font = new Font("Microsoft Sans Serif", 20.2499981F, FontStyle.Bold, GraphicsUnit.Point);
            logOut1.ForeColor = Color.DimGray;
            logOut1.Location = new Point(12, 14);
            logOut1.Name = "logOut1";
            logOut1.Size = new Size(34, 50);
            logOut1.TabIndex = 40;
            logOut1.Text = "<";
            logOut1.UseVisualStyleBackColor = false;
            logOut1.Click += logOut1_Click;
            // 
            // exit1
            // 
            exit1.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            exit1.Cursor = Cursors.Hand;
            exit1.Image = Properties.Resources.exit_light;
            exit1.Location = new Point(1257, 23);
            exit1.Name = "exit1";
            exit1.Size = new Size(20, 20);
            exit1.SizeMode = PictureBoxSizeMode.StretchImage;
            exit1.TabIndex = 9;
            exit1.TabStop = false;
            exit1.Click += exit1_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            pictureBox1.Cursor = Cursors.Hand;
            pictureBox1.Image = Properties.Resources.icon_user;
            pictureBox1.Location = new Point(52, 23);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(30, 30);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 9;
            pictureBox1.TabStop = false;
            // 
            // minimize
            // 
            minimize.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            minimize.Cursor = Cursors.Hand;
            minimize.Image = Properties.Resources.minimize_light;
            minimize.Location = new Point(2327, 22);
            minimize.Name = "minimize";
            minimize.Size = new Size(20, 20);
            minimize.SizeMode = PictureBoxSizeMode.StretchImage;
            minimize.TabIndex = 8;
            minimize.TabStop = false;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.logo__2_;
            pictureBox2.Location = new Point(113, 11);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(50, 50);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 6;
            pictureBox2.TabStop = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Microsoft Sans Serif", 15.7499981F, FontStyle.Bold, GraphicsUnit.Point);
            label2.ForeColor = Color.White;
            label2.Location = new Point(166, 23);
            label2.Name = "label2";
            label2.Size = new Size(181, 25);
            label2.TabIndex = 7;
            label2.Text = "BYTE AIRLINES";
            // 
            // btnBook
            // 
            btnBook.Cursor = Cursors.Hand;
            btnBook.FlatAppearance.BorderSize = 0;
            btnBook.FlatAppearance.MouseDownBackColor = Color.Transparent;
            btnBook.FlatAppearance.MouseOverBackColor = Color.Transparent;
            btnBook.FlatStyle = FlatStyle.Flat;
            btnBook.Font = new Font("Microsoft Sans Serif", 11.9999981F, FontStyle.Bold, GraphicsUnit.Point);
            btnBook.ForeColor = Color.White;
            btnBook.Location = new Point(558, 13);
            btnBook.Name = "btnBook";
            btnBook.Size = new Size(100, 41);
            btnBook.TabIndex = 6;
            btnBook.Text = "Book";
            btnBook.UseVisualStyleBackColor = true;
            // 
            // btnManage
            // 
            btnManage.Cursor = Cursors.Hand;
            btnManage.FlatAppearance.BorderSize = 0;
            btnManage.FlatAppearance.MouseDownBackColor = Color.Transparent;
            btnManage.FlatAppearance.MouseOverBackColor = Color.Transparent;
            btnManage.FlatStyle = FlatStyle.Flat;
            btnManage.Font = new Font("Microsoft Sans Serif", 11.9999981F, FontStyle.Bold, GraphicsUnit.Point);
            btnManage.ForeColor = Color.White;
            btnManage.Location = new Point(664, 13);
            btnManage.Name = "btnManage";
            btnManage.Size = new Size(100, 41);
            btnManage.TabIndex = 5;
            btnManage.Text = "Manage";
            btnManage.UseVisualStyleBackColor = true;
            // 
            // btnTravelInfo
            // 
            btnTravelInfo.Cursor = Cursors.Hand;
            btnTravelInfo.FlatAppearance.BorderSize = 0;
            btnTravelInfo.FlatAppearance.MouseDownBackColor = Color.Transparent;
            btnTravelInfo.FlatAppearance.MouseOverBackColor = Color.Transparent;
            btnTravelInfo.FlatStyle = FlatStyle.Flat;
            btnTravelInfo.Font = new Font("Microsoft Sans Serif", 11.9999981F, FontStyle.Bold, GraphicsUnit.Point);
            btnTravelInfo.ForeColor = Color.White;
            btnTravelInfo.Location = new Point(770, 13);
            btnTravelInfo.Name = "btnTravelInfo";
            btnTravelInfo.Size = new Size(145, 41);
            btnTravelInfo.TabIndex = 4;
            btnTravelInfo.Text = "Travel Info";
            btnTravelInfo.UseVisualStyleBackColor = true;
            // 
            // btnExplore
            // 
            btnExplore.Cursor = Cursors.Hand;
            btnExplore.FlatAppearance.BorderSize = 0;
            btnExplore.FlatAppearance.MouseDownBackColor = Color.Transparent;
            btnExplore.FlatAppearance.MouseOverBackColor = Color.Transparent;
            btnExplore.FlatStyle = FlatStyle.Flat;
            btnExplore.Font = new Font("Microsoft Sans Serif", 11.9999981F, FontStyle.Bold, GraphicsUnit.Point);
            btnExplore.ForeColor = Color.White;
            btnExplore.Location = new Point(921, 13);
            btnExplore.Name = "btnExplore";
            btnExplore.Size = new Size(100, 41);
            btnExplore.TabIndex = 3;
            btnExplore.Text = "Explore";
            btnExplore.UseVisualStyleBackColor = true;
            // 
            // btnAbout
            // 
            btnAbout.Cursor = Cursors.Hand;
            btnAbout.FlatAppearance.BorderSize = 0;
            btnAbout.FlatAppearance.MouseDownBackColor = Color.Transparent;
            btnAbout.FlatAppearance.MouseOverBackColor = Color.Transparent;
            btnAbout.FlatStyle = FlatStyle.Flat;
            btnAbout.Font = new Font("Microsoft Sans Serif", 11.9999981F, FontStyle.Bold, GraphicsUnit.Point);
            btnAbout.ForeColor = Color.White;
            btnAbout.Location = new Point(1027, 13);
            btnAbout.Name = "btnAbout";
            btnAbout.Size = new Size(100, 41);
            btnAbout.TabIndex = 2;
            btnAbout.Text = "About Us";
            btnAbout.UseVisualStyleBackColor = true;
            // 
            // exit
            // 
            exit.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            exit.Cursor = Cursors.Hand;
            exit.Image = Properties.Resources.exit_light;
            exit.Location = new Point(2355, 22);
            exit.Name = "exit";
            exit.Size = new Size(20, 20);
            exit.SizeMode = PictureBoxSizeMode.StretchImage;
            exit.TabIndex = 1;
            exit.TabStop = false;
            // 
            // eclipeControl1
            // 
            eclipeControl1.CornerRadius = 40;
            eclipeControl1.TargetControl = this;
            // 
            // marginLeft
            // 
            marginLeft.BackColor = Color.Transparent;
            marginLeft.Dock = DockStyle.Left;
            marginLeft.Location = new Point(0, 70);
            marginLeft.Name = "marginLeft";
            marginLeft.Size = new Size(100, 650);
            marginLeft.TabIndex = 2;
            // 
            // marginRight
            // 
            marginRight.BackColor = Color.Transparent;
            marginRight.Dock = DockStyle.Right;
            marginRight.Location = new Point(1200, 70);
            marginRight.Name = "marginRight";
            marginRight.Size = new Size(100, 650);
            marginRight.TabIndex = 3;
            // 
            // marginBottom
            // 
            marginBottom.BackColor = Color.Transparent;
            marginBottom.Dock = DockStyle.Bottom;
            marginBottom.Location = new Point(100, 601);
            marginBottom.Name = "marginBottom";
            marginBottom.Size = new Size(1100, 119);
            marginBottom.TabIndex = 4;
            // 
            // marginTop
            // 
            marginTop.BackColor = Color.Transparent;
            marginTop.Controls.Add(label1);
            marginTop.Dock = DockStyle.Top;
            marginTop.Location = new Point(100, 70);
            marginTop.Name = "marginTop";
            marginTop.Size = new Size(1100, 100);
            marginTop.TabIndex = 5;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft Sans Serif", 27.7499962F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.White;
            label1.Location = new Point(339, 27);
            label1.Name = "label1";
            label1.Size = new Size(456, 42);
            label1.TabIndex = 0;
            label1.Text = "Your flight is safe with us";
            // 
            // detailPanel
            // 
            detailPanel.BackColor = Color.WhiteSmoke;
            detailPanel.Controls.Add(checkOutPanel);
            detailPanel.Controls.Add(tabControl1);
            detailPanel.Controls.Add(btnConfirm);
            detailPanel.Dock = DockStyle.Fill;
            detailPanel.Location = new Point(100, 170);
            detailPanel.Name = "detailPanel";
            detailPanel.Size = new Size(1100, 431);
            detailPanel.TabIndex = 6;
            // 
            // checkOutPanel
            // 
            checkOutPanel.BackColor = Color.WhiteSmoke;
            checkOutPanel.Controls.Add(custButtons4);
            checkOutPanel.Controls.Add(label21);
            checkOutPanel.Controls.Add(label20);
            checkOutPanel.Controls.Add(label19);
            checkOutPanel.Controls.Add(label18);
            checkOutPanel.Controls.Add(label17);
            checkOutPanel.Controls.Add(label15);
            checkOutPanel.Controls.Add(label12);
            checkOutPanel.Controls.Add(custButtons3);
            checkOutPanel.Controls.Add(custButtons2);
            checkOutPanel.Controls.Add(custButtons1);
            checkOutPanel.Controls.Add(tbEmail);
            checkOutPanel.Controls.Add(lbSeniorFare);
            checkOutPanel.Controls.Add(lbChildFare);
            checkOutPanel.Controls.Add(label8);
            checkOutPanel.Controls.Add(label6);
            checkOutPanel.Controls.Add(label4);
            checkOutPanel.Controls.Add(totalFare);
            checkOutPanel.Controls.Add(panel1);
            checkOutPanel.Controls.Add(label16);
            checkOutPanel.Controls.Add(btnPay);
            checkOutPanel.Controls.Add(lbSeniorDiscount);
            checkOutPanel.Controls.Add(label14);
            checkOutPanel.Controls.Add(lbAdditionalCharges);
            checkOutPanel.Controls.Add(label13);
            checkOutPanel.Controls.Add(lbBaggageFee);
            checkOutPanel.Controls.Add(label11);
            checkOutPanel.Controls.Add(lbTravelTax);
            checkOutPanel.Controls.Add(label7);
            checkOutPanel.Controls.Add(lbTravelInsurance);
            checkOutPanel.Controls.Add(label5);
            checkOutPanel.Controls.Add(lbAdultFare);
            checkOutPanel.Controls.Add(label3);
            checkOutPanel.Controls.Add(returnPanel);
            checkOutPanel.Controls.Add(flightDepart);
            checkOutPanel.Controls.Add(flightType1);
            checkOutPanel.Controls.Add(flightCode1);
            checkOutPanel.Controls.Add(arriveLoc1);
            checkOutPanel.Controls.Add(departLoc1);
            checkOutPanel.Controls.Add(pictureBox3);
            checkOutPanel.Controls.Add(arriveTime1);
            checkOutPanel.Controls.Add(departTime1);
            checkOutPanel.Controls.Add(lbCheckOut);
            checkOutPanel.Controls.Add(panel2);
            checkOutPanel.Controls.Add(panel5);
            checkOutPanel.Dock = DockStyle.Fill;
            checkOutPanel.Location = new Point(0, 0);
            checkOutPanel.Name = "checkOutPanel";
            checkOutPanel.Size = new Size(1100, 431);
            checkOutPanel.TabIndex = 7;
            checkOutPanel.Visible = false;
            // 
            // custButtons4
            // 
            custButtons4.BackColor = SystemColors.Window;
            custButtons4.BorderColor = Color.LightSlateGray;
            custButtons4.BorderFocusColor = Color.SteelBlue;
            custButtons4.BorderRadius = 0;
            custButtons4.BorderSize = 3;
            custButtons4.Font = new Font("Lato", 11.9999981F, FontStyle.Regular, GraphicsUnit.Point);
            custButtons4.ForeColor = Color.DimGray;
            custButtons4.Location = new Point(985, 275);
            custButtons4.Multiline = true;
            custButtons4.Name = "custButtons4";
            custButtons4.Padding = new Padding(10, 7, 10, 7);
            custButtons4.PasswordChar = false;
            custButtons4.PlaceholderColor = Color.DarkGray;
            custButtons4.PlaceholderText = "00";
            custButtons4.Size = new Size(52, 34);
            custButtons4.TabIndex = 60;
            custButtons4.Texts = "";
            custButtons4.UnderlinedStyle = true;
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.BackColor = Color.Transparent;
            label21.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Regular, GraphicsUnit.Point);
            label21.ForeColor = Color.DimGray;
            label21.Location = new Point(959, 277);
            label21.Name = "label21";
            label21.Size = new Size(20, 29);
            label21.TabIndex = 59;
            label21.Text = "/";
            label21.TextAlign = ContentAlignment.MiddleRight;
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.BackColor = Color.Transparent;
            label20.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label20.ForeColor = Color.SteelBlue;
            label20.Location = new Point(840, 394);
            label20.Name = "label20";
            label20.Size = new Size(145, 16);
            label20.TabIndex = 58;
            label20.Text = "OR PAY WITH GCASH";
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.BackColor = Color.Transparent;
            label19.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label19.ForeColor = Color.Gray;
            label19.Location = new Point(1038, 89);
            label19.Name = "label19";
            label19.Size = new Size(37, 16);
            label19.TabIndex = 57;
            label19.Text = "VISA";
            label19.TextAlign = ContentAlignment.MiddleRight;
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.BackColor = Color.Transparent;
            label18.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label18.ForeColor = Color.DimGray;
            label18.Location = new Point(901, 248);
            label18.Name = "label18";
            label18.Size = new Size(95, 16);
            label18.TabIndex = 56;
            label18.Text = "EXPIRY DATE";
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.BackColor = Color.Transparent;
            label17.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label17.ForeColor = Color.DimGray;
            label17.Location = new Point(752, 248);
            label17.Name = "label17";
            label17.Size = new Size(116, 16);
            label17.TabIndex = 55;
            label17.Text = "SECURITY CODE";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.BackColor = Color.Transparent;
            label15.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label15.ForeColor = Color.DimGray;
            label15.Location = new Point(752, 167);
            label15.Name = "label15";
            label15.Size = new Size(110, 16);
            label15.TabIndex = 54;
            label15.Text = "NAME ON CARD";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.BackColor = Color.Transparent;
            label12.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label12.ForeColor = Color.DimGray;
            label12.Location = new Point(752, 89);
            label12.Name = "label12";
            label12.Size = new Size(107, 16);
            label12.TabIndex = 53;
            label12.Text = "CARD NUMBER";
            // 
            // custButtons3
            // 
            custButtons3.BackColor = SystemColors.Window;
            custButtons3.BorderColor = Color.LightSlateGray;
            custButtons3.BorderFocusColor = Color.SteelBlue;
            custButtons3.BorderRadius = 0;
            custButtons3.BorderSize = 3;
            custButtons3.Font = new Font("Lato", 11.9999981F, FontStyle.Regular, GraphicsUnit.Point);
            custButtons3.ForeColor = Color.DimGray;
            custButtons3.Location = new Point(901, 275);
            custButtons3.Multiline = true;
            custButtons3.Name = "custButtons3";
            custButtons3.Padding = new Padding(10, 7, 10, 7);
            custButtons3.PasswordChar = false;
            custButtons3.PlaceholderColor = Color.DarkGray;
            custButtons3.PlaceholderText = "00";
            custButtons3.Size = new Size(52, 34);
            custButtons3.TabIndex = 52;
            custButtons3.Texts = "";
            custButtons3.UnderlinedStyle = true;
            // 
            // custButtons2
            // 
            custButtons2.BackColor = SystemColors.Window;
            custButtons2.BorderColor = Color.LightSlateGray;
            custButtons2.BorderFocusColor = Color.SteelBlue;
            custButtons2.BorderRadius = 0;
            custButtons2.BorderSize = 3;
            custButtons2.Font = new Font("Lato", 11.9999981F, FontStyle.Regular, GraphicsUnit.Point);
            custButtons2.ForeColor = Color.DimGray;
            custButtons2.Location = new Point(752, 275);
            custButtons2.Multiline = true;
            custButtons2.Name = "custButtons2";
            custButtons2.Padding = new Padding(10, 7, 10, 7);
            custButtons2.PasswordChar = false;
            custButtons2.PlaceholderColor = Color.DarkGray;
            custButtons2.PlaceholderText = "***";
            custButtons2.Size = new Size(58, 34);
            custButtons2.TabIndex = 51;
            custButtons2.Texts = "";
            custButtons2.UnderlinedStyle = true;
            // 
            // custButtons1
            // 
            custButtons1.BackColor = SystemColors.Window;
            custButtons1.BorderColor = Color.LightSlateGray;
            custButtons1.BorderFocusColor = Color.SteelBlue;
            custButtons1.BorderRadius = 0;
            custButtons1.BorderSize = 3;
            custButtons1.Font = new Font("Lato", 11.9999981F, FontStyle.Regular, GraphicsUnit.Point);
            custButtons1.ForeColor = Color.DimGray;
            custButtons1.Location = new Point(752, 195);
            custButtons1.Multiline = true;
            custButtons1.Name = "custButtons1";
            custButtons1.Padding = new Padding(10, 7, 10, 7);
            custButtons1.PasswordChar = false;
            custButtons1.PlaceholderColor = Color.DarkGray;
            custButtons1.PlaceholderText = "JUAN DELA CRUZ";
            custButtons1.Size = new Size(323, 34);
            custButtons1.TabIndex = 50;
            custButtons1.Texts = "";
            custButtons1.UnderlinedStyle = true;
            // 
            // tbEmail
            // 
            tbEmail.BackColor = SystemColors.Window;
            tbEmail.BorderColor = Color.LightSlateGray;
            tbEmail.BorderFocusColor = Color.SteelBlue;
            tbEmail.BorderRadius = 0;
            tbEmail.BorderSize = 3;
            tbEmail.Font = new Font("Lato", 11.9999981F, FontStyle.Regular, GraphicsUnit.Point);
            tbEmail.ForeColor = Color.DimGray;
            tbEmail.Location = new Point(752, 117);
            tbEmail.Multiline = true;
            tbEmail.Name = "tbEmail";
            tbEmail.Padding = new Padding(10, 7, 10, 7);
            tbEmail.PasswordChar = false;
            tbEmail.PlaceholderColor = Color.DarkGray;
            tbEmail.PlaceholderText = "1234 5678 9123 4567";
            tbEmail.Size = new Size(323, 34);
            tbEmail.TabIndex = 49;
            tbEmail.Texts = "";
            tbEmail.UnderlinedStyle = true;
            // 
            // lbSeniorFare
            // 
            lbSeniorFare.AutoSize = true;
            lbSeniorFare.BackColor = Color.Transparent;
            lbSeniorFare.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            lbSeniorFare.ForeColor = Color.DimGray;
            lbSeniorFare.Location = new Point(581, 167);
            lbSeniorFare.Name = "lbSeniorFare";
            lbSeniorFare.Size = new Size(106, 16);
            lbSeniorFare.TabIndex = 48;
            lbSeniorFare.Text = "PHP 00,000.00";
            lbSeniorFare.TextAlign = ContentAlignment.MiddleRight;
            // 
            // lbChildFare
            // 
            lbChildFare.AutoSize = true;
            lbChildFare.BackColor = Color.Transparent;
            lbChildFare.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            lbChildFare.ForeColor = Color.DimGray;
            lbChildFare.Location = new Point(581, 142);
            lbChildFare.Name = "lbChildFare";
            lbChildFare.Size = new Size(106, 16);
            lbChildFare.TabIndex = 47;
            lbChildFare.Text = "PHP 00,000.00";
            lbChildFare.TextAlign = ContentAlignment.MiddleRight;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = Color.Transparent;
            label8.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label8.ForeColor = Color.SteelBlue;
            label8.Location = new Point(407, 167);
            label8.Name = "label8";
            label8.Size = new Size(58, 16);
            label8.TabIndex = 46;
            label8.Text = "SENIOR";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.Transparent;
            label6.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label6.ForeColor = Color.SteelBlue;
            label6.Location = new Point(407, 142);
            label6.Name = "label6";
            label6.Size = new Size(46, 16);
            label6.TabIndex = 45;
            label6.Text = "CHILD";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Transparent;
            label4.Font = new Font("Microsoft Sans Serif", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            label4.ForeColor = Color.SteelBlue;
            label4.Location = new Point(802, 36);
            label4.Name = "label4";
            label4.Size = new Size(208, 25);
            label4.TabIndex = 44;
            label4.Text = "PAYMENT DETAILS";
            // 
            // totalFare
            // 
            totalFare.AutoSize = true;
            totalFare.BackColor = Color.Transparent;
            totalFare.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            totalFare.ForeColor = Color.DimGray;
            totalFare.Location = new Point(581, 391);
            totalFare.Name = "totalFare";
            totalFare.Size = new Size(106, 16);
            totalFare.TabIndex = 43;
            totalFare.Text = "PHP 00,000.00";
            totalFare.TextAlign = ContentAlignment.MiddleRight;
            // 
            // panel1
            // 
            panel1.BackColor = Color.DarkGray;
            panel1.Controls.Add(panel4);
            panel1.Location = new Point(411, 352);
            panel1.Name = "panel1";
            panel1.Size = new Size(270, 2);
            panel1.TabIndex = 6;
            // 
            // panel4
            // 
            panel4.BackColor = Color.Gray;
            panel4.Location = new Point(32, 0);
            panel4.Name = "panel4";
            panel4.Size = new Size(5, 350);
            panel4.TabIndex = 2;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.BackColor = Color.Transparent;
            label16.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label16.ForeColor = Color.SteelBlue;
            label16.Location = new Point(407, 387);
            label16.Name = "label16";
            label16.Size = new Size(59, 20);
            label16.TabIndex = 42;
            label16.Text = "TOTAL";
            label16.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // btnPay
            // 
            btnPay.BackColor = Color.Transparent;
            btnPay.BorderColor = Color.Transparent;
            btnPay.ButtonColor = Color.SteelBlue;
            btnPay.Cursor = Cursors.Hand;
            btnPay.FlatAppearance.BorderSize = 0;
            btnPay.FlatAppearance.MouseDownBackColor = Color.Transparent;
            btnPay.FlatAppearance.MouseOverBackColor = Color.Transparent;
            btnPay.FlatStyle = FlatStyle.Flat;
            btnPay.Font = new Font("Microsoft Sans Serif", 11.9999981F, FontStyle.Regular, GraphicsUnit.Point);
            btnPay.Location = new Point(752, 336);
            btnPay.Name = "btnPay";
            btnPay.OnHoverBorderColor = Color.Transparent;
            btnPay.OnHoverButtonColor = Color.CornflowerBlue;
            btnPay.OnHoverTextColor = Color.White;
            btnPay.Size = new Size(323, 49);
            btnPay.TabIndex = 41;
            btnPay.Text = "PAY";
            btnPay.TextColor = Color.White;
            btnPay.UseVisualStyleBackColor = false;
            btnPay.Click += btnPay_Click;
            // 
            // lbSeniorDiscount
            // 
            lbSeniorDiscount.AutoSize = true;
            lbSeniorDiscount.BackColor = Color.Transparent;
            lbSeniorDiscount.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            lbSeniorDiscount.ForeColor = Color.DimGray;
            lbSeniorDiscount.Location = new Point(581, 300);
            lbSeniorDiscount.Name = "lbSeniorDiscount";
            lbSeniorDiscount.Size = new Size(106, 16);
            lbSeniorDiscount.TabIndex = 40;
            lbSeniorDiscount.Text = "PHP 00,000.00";
            lbSeniorDiscount.TextAlign = ContentAlignment.MiddleRight;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.BackColor = Color.Transparent;
            label14.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label14.ForeColor = Color.SteelBlue;
            label14.Location = new Point(407, 300);
            label14.Name = "label14";
            label14.Size = new Size(131, 16);
            label14.TabIndex = 39;
            label14.Text = "SENIOR DISCOUNT";
            label14.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // lbAdditionalCharges
            // 
            lbAdditionalCharges.AutoSize = true;
            lbAdditionalCharges.BackColor = Color.Transparent;
            lbAdditionalCharges.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            lbAdditionalCharges.ForeColor = Color.DimGray;
            lbAdditionalCharges.Location = new Point(581, 275);
            lbAdditionalCharges.Name = "lbAdditionalCharges";
            lbAdditionalCharges.Size = new Size(106, 16);
            lbAdditionalCharges.TabIndex = 38;
            lbAdditionalCharges.Text = "PHP 00,000.00";
            lbAdditionalCharges.TextAlign = ContentAlignment.MiddleRight;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.BackColor = Color.Transparent;
            label13.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label13.ForeColor = Color.SteelBlue;
            label13.Location = new Point(407, 275);
            label13.Name = "label13";
            label13.Size = new Size(133, 16);
            label13.TabIndex = 37;
            label13.Text = "TRANSACTION FEE";
            label13.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // lbBaggageFee
            // 
            lbBaggageFee.AutoSize = true;
            lbBaggageFee.BackColor = Color.Transparent;
            lbBaggageFee.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            lbBaggageFee.ForeColor = Color.DimGray;
            lbBaggageFee.Location = new Point(581, 248);
            lbBaggageFee.Name = "lbBaggageFee";
            lbBaggageFee.Size = new Size(106, 16);
            lbBaggageFee.TabIndex = 36;
            lbBaggageFee.Text = "PHP 00,000.00";
            lbBaggageFee.TextAlign = ContentAlignment.MiddleRight;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.BackColor = Color.Transparent;
            label11.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label11.ForeColor = Color.SteelBlue;
            label11.ImageAlign = ContentAlignment.MiddleLeft;
            label11.Location = new Point(407, 248);
            label11.Name = "label11";
            label11.Size = new Size(102, 16);
            label11.TabIndex = 35;
            label11.Text = "BAGGAGE FEE";
            label11.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // lbTravelTax
            // 
            lbTravelTax.AutoSize = true;
            lbTravelTax.BackColor = Color.Transparent;
            lbTravelTax.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            lbTravelTax.ForeColor = Color.DimGray;
            lbTravelTax.Location = new Point(581, 220);
            lbTravelTax.Name = "lbTravelTax";
            lbTravelTax.Size = new Size(106, 16);
            lbTravelTax.TabIndex = 34;
            lbTravelTax.Text = "PHP 00,000.00";
            lbTravelTax.TextAlign = ContentAlignment.MiddleRight;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = Color.Transparent;
            label7.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label7.ForeColor = Color.SteelBlue;
            label7.Location = new Point(407, 220);
            label7.Name = "label7";
            label7.Size = new Size(89, 16);
            label7.TabIndex = 33;
            label7.Text = "TRAVEL TAX";
            label7.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lbTravelInsurance
            // 
            lbTravelInsurance.AutoSize = true;
            lbTravelInsurance.BackColor = Color.Transparent;
            lbTravelInsurance.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            lbTravelInsurance.ForeColor = Color.DimGray;
            lbTravelInsurance.Location = new Point(581, 195);
            lbTravelInsurance.Name = "lbTravelInsurance";
            lbTravelInsurance.Size = new Size(106, 16);
            lbTravelInsurance.TabIndex = 32;
            lbTravelInsurance.Text = "PHP 00,000.00";
            lbTravelInsurance.TextAlign = ContentAlignment.MiddleRight;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Transparent;
            label5.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label5.ForeColor = Color.SteelBlue;
            label5.Location = new Point(407, 195);
            label5.Name = "label5";
            label5.Size = new Size(142, 16);
            label5.TabIndex = 31;
            label5.Text = "TRAVEL INSURANCE";
            label5.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // lbAdultFare
            // 
            lbAdultFare.AutoSize = true;
            lbAdultFare.BackColor = Color.Transparent;
            lbAdultFare.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            lbAdultFare.ForeColor = Color.DimGray;
            lbAdultFare.Location = new Point(581, 117);
            lbAdultFare.Name = "lbAdultFare";
            lbAdultFare.Size = new Size(106, 16);
            lbAdultFare.TabIndex = 30;
            lbAdultFare.Text = "PHP 00,000.00";
            lbAdultFare.TextAlign = ContentAlignment.MiddleRight;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label3.ForeColor = Color.SteelBlue;
            label3.Location = new Point(407, 117);
            label3.Name = "label3";
            label3.Size = new Size(52, 16);
            label3.TabIndex = 23;
            label3.Text = "ADULT";
            // 
            // returnPanel
            // 
            returnPanel.Controls.Add(flightReturn);
            returnPanel.Controls.Add(flightType2);
            returnPanel.Controls.Add(flightCode2);
            returnPanel.Controls.Add(arriveLoc2);
            returnPanel.Controls.Add(departLoc2);
            returnPanel.Controls.Add(pictureBox4);
            returnPanel.Controls.Add(arriveTime2);
            returnPanel.Controls.Add(departTime2);
            returnPanel.Location = new Point(20, 241);
            returnPanel.Name = "returnPanel";
            returnPanel.Size = new Size(367, 103);
            returnPanel.TabIndex = 22;
            returnPanel.Visible = false;
            // 
            // flightReturn
            // 
            flightReturn.AutoSize = true;
            flightReturn.BackColor = Color.Transparent;
            flightReturn.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            flightReturn.ForeColor = Color.DimGray;
            flightReturn.Location = new Point(271, 22);
            flightReturn.Name = "flightReturn";
            flightReturn.Size = new Size(71, 16);
            flightReturn.TabIndex = 29;
            flightReturn.Text = "0000/00/00";
            flightReturn.TextAlign = ContentAlignment.TopRight;
            // 
            // flightType2
            // 
            flightType2.AutoSize = true;
            flightType2.BackColor = Color.Transparent;
            flightType2.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            flightType2.ForeColor = Color.SteelBlue;
            flightType2.Location = new Point(142, 80);
            flightType2.Name = "flightType2";
            flightType2.Size = new Size(72, 16);
            flightType2.TabIndex = 28;
            flightType2.Text = "REGULAR";
            // 
            // flightCode2
            // 
            flightCode2.AutoSize = true;
            flightCode2.BackColor = Color.Transparent;
            flightCode2.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            flightCode2.ForeColor = Color.DimGray;
            flightCode2.Location = new Point(12, 22);
            flightCode2.Name = "flightCode2";
            flightCode2.Size = new Size(97, 16);
            flightCode2.TabIndex = 27;
            flightCode2.Text = "FLIGHT 4A 000";
            // 
            // arriveLoc2
            // 
            arriveLoc2.AutoSize = true;
            arriveLoc2.BackColor = Color.Transparent;
            arriveLoc2.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Regular, GraphicsUnit.Point);
            arriveLoc2.ForeColor = Color.DimGray;
            arriveLoc2.Location = new Point(274, 80);
            arriveLoc2.Name = "arriveLoc2";
            arriveLoc2.Size = new Size(68, 15);
            arriveLoc2.TabIndex = 26;
            arriveLoc2.Text = "Arrive - AAA";
            // 
            // departLoc2
            // 
            departLoc2.AutoSize = true;
            departLoc2.BackColor = Color.Transparent;
            departLoc2.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Regular, GraphicsUnit.Point);
            departLoc2.ForeColor = Color.DimGray;
            departLoc2.Location = new Point(18, 80);
            departLoc2.Name = "departLoc2";
            departLoc2.Size = new Size(75, 15);
            departLoc2.TabIndex = 25;
            departLoc2.Text = "Depart - AAA";
            // 
            // pictureBox4
            // 
            pictureBox4.BackColor = Color.Transparent;
            pictureBox4.Image = Properties.Resources.plane_blue;
            pictureBox4.Location = new Point(163, 47);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(30, 30);
            pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox4.TabIndex = 24;
            pictureBox4.TabStop = false;
            // 
            // arriveTime2
            // 
            arriveTime2.AutoSize = true;
            arriveTime2.BackColor = Color.Transparent;
            arriveTime2.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            arriveTime2.ForeColor = Color.DimGray;
            arriveTime2.Location = new Point(263, 47);
            arriveTime2.Name = "arriveTime2";
            arriveTime2.Size = new Size(86, 24);
            arriveTime2.TabIndex = 23;
            arriveTime2.Text = "0:00 AM";
            // 
            // departTime2
            // 
            departTime2.AutoSize = true;
            departTime2.BackColor = Color.Transparent;
            departTime2.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            departTime2.ForeColor = Color.DimGray;
            departTime2.Location = new Point(12, 47);
            departTime2.Name = "departTime2";
            departTime2.Size = new Size(86, 24);
            departTime2.TabIndex = 22;
            departTime2.Text = "0:00 AM";
            // 
            // flightDepart
            // 
            flightDepart.AutoSize = true;
            flightDepart.BackColor = Color.Transparent;
            flightDepart.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            flightDepart.ForeColor = Color.DimGray;
            flightDepart.Location = new Point(298, 117);
            flightDepart.Name = "flightDepart";
            flightDepart.Size = new Size(71, 16);
            flightDepart.TabIndex = 21;
            flightDepart.Text = "0000/00/00";
            flightDepart.TextAlign = ContentAlignment.TopRight;
            // 
            // flightType1
            // 
            flightType1.AutoSize = true;
            flightType1.BackColor = Color.Transparent;
            flightType1.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            flightType1.ForeColor = Color.SteelBlue;
            flightType1.Location = new Point(162, 175);
            flightType1.Name = "flightType1";
            flightType1.Size = new Size(72, 16);
            flightType1.TabIndex = 20;
            flightType1.Text = "REGULAR";
            // 
            // flightCode1
            // 
            flightCode1.AutoSize = true;
            flightCode1.BackColor = Color.Transparent;
            flightCode1.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            flightCode1.ForeColor = Color.DimGray;
            flightCode1.Location = new Point(32, 117);
            flightCode1.Name = "flightCode1";
            flightCode1.Size = new Size(97, 16);
            flightCode1.TabIndex = 19;
            flightCode1.Text = "FLIGHT 4A 000";
            // 
            // arriveLoc1
            // 
            arriveLoc1.AutoSize = true;
            arriveLoc1.BackColor = Color.Transparent;
            arriveLoc1.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Regular, GraphicsUnit.Point);
            arriveLoc1.ForeColor = Color.DimGray;
            arriveLoc1.Location = new Point(291, 175);
            arriveLoc1.Name = "arriveLoc1";
            arriveLoc1.Size = new Size(68, 15);
            arriveLoc1.TabIndex = 18;
            arriveLoc1.Text = "Arrive - AAA";
            // 
            // departLoc1
            // 
            departLoc1.AutoSize = true;
            departLoc1.BackColor = Color.Transparent;
            departLoc1.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Regular, GraphicsUnit.Point);
            departLoc1.ForeColor = Color.DimGray;
            departLoc1.Location = new Point(38, 175);
            departLoc1.Name = "departLoc1";
            departLoc1.Size = new Size(75, 15);
            departLoc1.TabIndex = 17;
            departLoc1.Text = "Depart - AAA";
            // 
            // pictureBox3
            // 
            pictureBox3.BackColor = Color.Transparent;
            pictureBox3.Image = Properties.Resources.plane_blue;
            pictureBox3.Location = new Point(183, 142);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(30, 30);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 16;
            pictureBox3.TabStop = false;
            // 
            // arriveTime1
            // 
            arriveTime1.AutoSize = true;
            arriveTime1.BackColor = Color.Transparent;
            arriveTime1.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            arriveTime1.ForeColor = Color.DimGray;
            arriveTime1.Location = new Point(283, 142);
            arriveTime1.Name = "arriveTime1";
            arriveTime1.Size = new Size(86, 24);
            arriveTime1.TabIndex = 15;
            arriveTime1.Text = "0:00 AM";
            // 
            // departTime1
            // 
            departTime1.AutoSize = true;
            departTime1.BackColor = Color.Transparent;
            departTime1.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            departTime1.ForeColor = Color.DimGray;
            departTime1.Location = new Point(32, 142);
            departTime1.Name = "departTime1";
            departTime1.Size = new Size(86, 24);
            departTime1.TabIndex = 14;
            departTime1.Text = "0:00 AM";
            // 
            // lbCheckOut
            // 
            lbCheckOut.AutoSize = true;
            lbCheckOut.BackColor = Color.Transparent;
            lbCheckOut.Font = new Font("Microsoft Sans Serif", 21.75F, FontStyle.Regular, GraphicsUnit.Point);
            lbCheckOut.ForeColor = Color.DimGray;
            lbCheckOut.Location = new Point(270, 28);
            lbCheckOut.Name = "lbCheckOut";
            lbCheckOut.Size = new Size(186, 33);
            lbCheckOut.TabIndex = 10;
            lbCheckOut.Text = "CHECK OUT";
            // 
            // panel2
            // 
            panel2.BackColor = Color.DarkGray;
            panel2.Controls.Add(panel3);
            panel2.Location = new Point(32, 69);
            panel2.Name = "panel2";
            panel2.Size = new Size(660, 2);
            panel2.TabIndex = 5;
            // 
            // panel3
            // 
            panel3.BackColor = Color.Gray;
            panel3.Location = new Point(32, 0);
            panel3.Name = "panel3";
            panel3.Size = new Size(5, 350);
            panel3.TabIndex = 2;
            // 
            // panel5
            // 
            panel5.BackColor = Color.DarkGray;
            panel5.Controls.Add(panel6);
            panel5.Location = new Point(720, 5);
            panel5.Name = "panel5";
            panel5.Size = new Size(3, 423);
            panel5.TabIndex = 4;
            // 
            // panel6
            // 
            panel6.BackColor = Color.Gray;
            panel6.Location = new Point(32, 0);
            panel6.Name = "panel6";
            panel6.Size = new Size(5, 350);
            panel6.TabIndex = 2;
            // 
            // tabControl1
            // 
            tabControl1.Font = new Font("Microsoft Sans Serif", 11.9999981F, FontStyle.Regular, GraphicsUnit.Point);
            tabControl1.Location = new Point(52, 28);
            tabControl1.Multiline = true;
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(765, 364);
            tabControl1.TabIndex = 0;
            // 
            // btnConfirm
            // 
            btnConfirm.BackColor = Color.Transparent;
            btnConfirm.BorderColor = Color.Transparent;
            btnConfirm.ButtonColor = Color.SteelBlue;
            btnConfirm.Cursor = Cursors.Hand;
            btnConfirm.FlatAppearance.BorderSize = 0;
            btnConfirm.FlatAppearance.MouseDownBackColor = Color.Transparent;
            btnConfirm.FlatAppearance.MouseOverBackColor = Color.Transparent;
            btnConfirm.FlatStyle = FlatStyle.Flat;
            btnConfirm.Font = new Font("Microsoft Sans Serif", 11.9999981F, FontStyle.Regular, GraphicsUnit.Point);
            btnConfirm.Location = new Point(840, 170);
            btnConfirm.Name = "btnConfirm";
            btnConfirm.OnHoverBorderColor = Color.Transparent;
            btnConfirm.OnHoverButtonColor = Color.CornflowerBlue;
            btnConfirm.OnHoverTextColor = Color.White;
            btnConfirm.Size = new Size(235, 68);
            btnConfirm.TabIndex = 8;
            btnConfirm.Text = "Confirm";
            btnConfirm.TextColor = Color.White;
            btnConfirm.UseVisualStyleBackColor = false;
            btnConfirm.Click += btnConfirm_Click;
            // 
            // eclipeControl2
            // 
            eclipeControl2.CornerRadius = 40;
            eclipeControl2.TargetControl = detailPanel;
            // 
            // DetailForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.bg_detailform;
            ClientSize = new Size(1300, 720);
            Controls.Add(detailPanel);
            Controls.Add(marginTop);
            Controls.Add(marginBottom);
            Controls.Add(marginRight);
            Controls.Add(marginLeft);
            Controls.Add(menuPanel);
            FormBorderStyle = FormBorderStyle.None;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "DetailForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "DetailForm";
            Load += DetailForm_Load;
            menuPanel.ResumeLayout(false);
            menuPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)minimize1).EndInit();
            ((System.ComponentModel.ISupportInitialize)exit1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)minimize).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)exit).EndInit();
            marginTop.ResumeLayout(false);
            marginTop.PerformLayout();
            detailPanel.ResumeLayout(false);
            checkOutPanel.ResumeLayout(false);
            checkOutPanel.PerformLayout();
            panel1.ResumeLayout(false);
            returnPanel.ResumeLayout(false);
            returnPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            panel2.ResumeLayout(false);
            panel5.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Panel menuPanel;
        private Button logOut1;
        private PictureBox pictureBox1;
        private PictureBox minimize;
        private PictureBox pictureBox2;
        private Label label2;
        private Button btnBook;
        private Button btnManage;
        private Button btnTravelInfo;
        private Button btnExplore;
        private Button btnAbout;
        private PictureBox exit;
        private EclipeControl eclipeControl1;
        private PictureBox minimize1;
        private PictureBox exit1;
        private Panel marginLeft;
        private Panel marginRight;
        private Panel marginBottom;
        private Panel marginTop;
        private Label label1;
        private Panel detailPanel;
        private EclipeControl eclipeControl2;
        private TabControl tabControl1;
        private ePOSOne.btnProduct.Button_WOC btnConfirm;
        private Panel checkOutPanel;
        private Label label7;
        private Label label5;
        private Label label3;
        private Panel returnPanel;
        private Label flightReturn;
        private Label flightType2;
        private Label flightCode2;
        private Label arriveLoc2;
        private Label departLoc2;
        private PictureBox pictureBox4;
        private Label arriveTime2;
        private Label departTime2;
        private Label flightDepart;
        private Label flightType1;
        private Label flightCode1;
        private Label arriveLoc1;
        private Label departLoc1;
        private PictureBox pictureBox3;
        private Label arriveTime1;
        private Label departTime1;
        private Label lbCheckOut;
        private Panel panel2;
        private Panel panel3;
        private Panel panel5;
        private Panel panel6;
        private Label label11;
        private Label label14;
        private Label label13;
        private ePOSOne.btnProduct.Button_WOC btnPay;
        private Panel panel1;
        private Panel panel4;
        private Label label16;
        private Label totalFare;
        private Label label4;
        private Label label8;
        private Label label6;
        public Label lbTravelTax;
        public Label lbTravelInsurance;
        public Label lbAdultFare;
        public Label lbBaggageFee;
        public Label lbSeniorDiscount;
        public Label lbAdditionalCharges;
        public Label lbSeniorFare;
        public Label lbChildFare;
        private CustButtons custButtons4;
        private Label label21;
        private Label label20;
        private Label label19;
        private Label label18;
        private Label label17;
        private Label label15;
        private Label label12;
        private CustButtons custButtons3;
        private CustButtons custButtons2;
        private CustButtons custButtons1;
        private CustButtons tbEmail;
    }
}