﻿namespace ByteAirline
{
    partial class Receipt
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Receipt));
            eclipeControl1 = new EclipeControl();
            pictureBox1 = new PictureBox();
            label100 = new Label();
            label99 = new Label();
            panel2 = new Panel();
            panel3 = new Panel();
            pictureBox2 = new PictureBox();
            label101 = new Label();
            label4 = new Label();
            label5 = new Label();
            tbBookDate = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            tbTransNum = new Label();
            panel1 = new Panel();
            panel4 = new Panel();
            label10 = new Label();
            panel5 = new Panel();
            panel6 = new Panel();
            panel7 = new Panel();
            panel8 = new Panel();
            label11 = new Label();
            label12 = new Label();
            label13 = new Label();
            label14 = new Label();
            label15 = new Label();
            tbDepartLoc = new Label();
            tbArriveLoc = new Label();
            tbFlightCode = new Label();
            tbArrivalDate = new Label();
            tbDepartDate = new Label();
            label16 = new Label();
            label17 = new Label();
            label18 = new Label();
            label19 = new Label();
            label20 = new Label();
            tbFlightType = new Label();
            label21 = new Label();
            label22 = new Label();
            label23 = new Label();
            label24 = new Label();
            label25 = new Label();
            label26 = new Label();
            tbTravelDestination = new Label();
            tbAdultFare = new Label();
            tbChildFare = new Label();
            tbSeniorFare = new Label();
            tbTravelInsurance = new Label();
            tbTravelTax = new Label();
            tbBaggageFee = new Label();
            tbTransactionFee = new Label();
            tbSeniorDiscount = new Label();
            tbTotal = new Label();
            label27 = new Label();
            label28 = new Label();
            label29 = new Label();
            tbAdultNum = new Label();
            tbChildNum = new Label();
            tbSeniorNum = new Label();
            btnPrint = new ePOSOne.btnProduct.Button_WOC();
            tbDepartTIme = new Label();
            tbArrivalTime = new Label();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            tbFlightTrip = new Label();
            roundTripPanel = new Panel();
            tbArrivalTime2 = new Label();
            tbDepartTime2 = new Label();
            tbArrivalDate2 = new Label();
            tbDepartDate2 = new Label();
            tbFlightCode2 = new Label();
            tbArriveLoc2 = new Label();
            tbDepartLoc2 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            panel1.SuspendLayout();
            panel5.SuspendLayout();
            panel7.SuspendLayout();
            roundTripPanel.SuspendLayout();
            SuspendLayout();
            // 
            // eclipeControl1
            // 
            eclipeControl1.CornerRadius = 20;
            eclipeControl1.TargetControl = this;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.logo__2_;
            pictureBox1.Location = new Point(51, 44);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(70, 70);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // label100
            // 
            label100.AutoSize = true;
            label100.Font = new Font("Microsoft Sans Serif", 20.25F, FontStyle.Bold, GraphicsUnit.Point);
            label100.ForeColor = Color.SteelBlue;
            label100.Location = new Point(127, 62);
            label100.Name = "label100";
            label100.Size = new Size(230, 31);
            label100.TabIndex = 8;
            label100.Text = "BYTE AIRLINES";
            // 
            // label99
            // 
            label99.AutoSize = true;
            label99.Font = new Font("Microsoft Sans Serif", 15.75F, FontStyle.Italic, GraphicsUnit.Point);
            label99.ForeColor = Color.SteelBlue;
            label99.Location = new Point(641, 68);
            label99.Name = "label99";
            label99.Size = new Size(85, 25);
            label99.TabIndex = 9;
            label99.Text = "Receipt";
            // 
            // panel2
            // 
            panel2.BackColor = Color.DarkGray;
            panel2.Controls.Add(panel3);
            panel2.Location = new Point(51, 127);
            panel2.Name = "panel2";
            panel2.Size = new Size(675, 2);
            panel2.TabIndex = 10;
            // 
            // panel3
            // 
            panel3.BackColor = Color.Gray;
            panel3.Location = new Point(32, 0);
            panel3.Name = "panel3";
            panel3.Size = new Size(5, 350);
            panel3.TabIndex = 2;
            // 
            // pictureBox2
            // 
            pictureBox2.Cursor = Cursors.Hand;
            pictureBox2.Image = Properties.Resources.exit;
            pictureBox2.Location = new Point(756, 22);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(20, 20);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 11;
            pictureBox2.TabStop = false;
            pictureBox2.Click += pictureBox2_Click;
            // 
            // label101
            // 
            label101.AutoSize = true;
            label101.Font = new Font("Microsoft Sans Serif", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            label101.ForeColor = Color.SteelBlue;
            label101.Location = new Point(51, 148);
            label101.Name = "label101";
            label101.Size = new Size(115, 18);
            label101.TabIndex = 12;
            label101.Text = "BYTE AIRLINES";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label4.ForeColor = Color.FromArgb(64, 64, 64);
            label4.Location = new Point(51, 166);
            label4.Name = "label4";
            label4.Size = new Size(111, 16);
            label4.TabIndex = 13;
            label4.Text = "Status: Confirmed";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label5.ForeColor = Color.FromArgb(64, 64, 64);
            label5.Location = new Point(51, 182);
            label5.Name = "label5";
            label5.Size = new Size(92, 16);
            label5.TabIndex = 14;
            label5.Text = "Booking Date:";
            // 
            // tbBookDate
            // 
            tbBookDate.AutoSize = true;
            tbBookDate.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            tbBookDate.ForeColor = Color.DimGray;
            tbBookDate.Location = new Point(149, 182);
            tbBookDate.Name = "tbBookDate";
            tbBookDate.Size = new Size(71, 16);
            tbBookDate.TabIndex = 15;
            tbBookDate.Text = "00-00-0000";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label6.ForeColor = Color.FromArgb(64, 64, 64);
            label6.Location = new Point(350, 166);
            label6.Name = "label6";
            label6.Size = new Size(78, 16);
            label6.TabIndex = 16;
            label6.Text = "63-234-5678";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label7.ForeColor = Color.FromArgb(64, 64, 64);
            label7.Location = new Point(350, 182);
            label7.Name = "label7";
            label7.Size = new Size(152, 16);
            label7.TabIndex = 17;
            label7.Text = "byteairlines@email.com";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label8.ForeColor = Color.FromArgb(64, 64, 64);
            label8.Location = new Point(574, 150);
            label8.Name = "label8";
            label8.Size = new Size(156, 16);
            label8.TabIndex = 18;
            label8.Text = "Transaction Number Ref.";
            // 
            // tbTransNum
            // 
            tbTransNum.AutoSize = true;
            tbTransNum.Font = new Font("Microsoft Sans Serif", 15.75F, FontStyle.Bold, GraphicsUnit.Point);
            tbTransNum.ForeColor = Color.SteelBlue;
            tbTransNum.Location = new Point(605, 173);
            tbTransNum.Name = "tbTransNum";
            tbTransNum.Size = new Size(94, 25);
            tbTransNum.TabIndex = 19;
            tbTransNum.Text = "BA0000";
            // 
            // panel1
            // 
            panel1.BackColor = Color.DarkGray;
            panel1.Controls.Add(panel4);
            panel1.Location = new Point(51, 220);
            panel1.Name = "panel1";
            panel1.Size = new Size(675, 2);
            panel1.TabIndex = 11;
            // 
            // panel4
            // 
            panel4.BackColor = Color.Gray;
            panel4.Location = new Point(32, 0);
            panel4.Name = "panel4";
            panel4.Size = new Size(5, 350);
            panel4.TabIndex = 2;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Microsoft Sans Serif", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            label10.ForeColor = Color.SteelBlue;
            label10.Location = new Point(51, 236);
            label10.Name = "label10";
            label10.Size = new Size(128, 18);
            label10.TabIndex = 20;
            label10.Text = "GUEST DETAILS:";
            // 
            // panel5
            // 
            panel5.BackColor = Color.DarkGray;
            panel5.Controls.Add(panel6);
            panel5.Location = new Point(51, 368);
            panel5.Name = "panel5";
            panel5.Size = new Size(675, 2);
            panel5.TabIndex = 12;
            // 
            // panel6
            // 
            panel6.BackColor = Color.Gray;
            panel6.Location = new Point(32, 0);
            panel6.Name = "panel6";
            panel6.Size = new Size(5, 350);
            panel6.TabIndex = 2;
            // 
            // panel7
            // 
            panel7.BackColor = Color.DarkGray;
            panel7.Controls.Add(panel8);
            panel7.Location = new Point(51, 534);
            panel7.Name = "panel7";
            panel7.Size = new Size(675, 2);
            panel7.TabIndex = 13;
            // 
            // panel8
            // 
            panel8.BackColor = Color.Gray;
            panel8.Location = new Point(32, 0);
            panel8.Name = "panel8";
            panel8.Size = new Size(5, 350);
            panel8.TabIndex = 2;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Microsoft Sans Serif", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            label11.ForeColor = Color.SteelBlue;
            label11.Location = new Point(51, 382);
            label11.Name = "label11";
            label11.Size = new Size(128, 18);
            label11.TabIndex = 21;
            label11.Text = "FLIGHT DETAILS:";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label12.ForeColor = Color.FromArgb(64, 64, 64);
            label12.Location = new Point(51, 406);
            label12.Name = "label12";
            label12.Size = new Size(55, 16);
            label12.TabIndex = 22;
            label12.Text = "ROUTE";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label13.ForeColor = Color.FromArgb(64, 64, 64);
            label13.Location = new Point(193, 406);
            label13.Name = "label13";
            label13.Size = new Size(64, 16);
            label13.TabIndex = 23;
            label13.Text = "FLIGHT #";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label14.ForeColor = Color.FromArgb(64, 64, 64);
            label14.Location = new Point(350, 406);
            label14.Name = "label14";
            label14.Size = new Size(92, 16);
            label14.TabIndex = 24;
            label14.Text = "DEPARTURE";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label15.ForeColor = Color.FromArgb(64, 64, 64);
            label15.Location = new Point(551, 406);
            label15.Name = "label15";
            label15.Size = new Size(64, 16);
            label15.TabIndex = 25;
            label15.Text = "ARRIVAL";
            // 
            // tbDepartLoc
            // 
            tbDepartLoc.AutoSize = true;
            tbDepartLoc.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            tbDepartLoc.ForeColor = Color.DimGray;
            tbDepartLoc.Location = new Point(51, 422);
            tbDepartLoc.Name = "tbDepartLoc";
            tbDepartLoc.Size = new Size(70, 16);
            tbDepartLoc.TabIndex = 27;
            tbDepartLoc.Text = "DepartLoc";
            // 
            // tbArriveLoc
            // 
            tbArriveLoc.AutoSize = true;
            tbArriveLoc.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            tbArriveLoc.ForeColor = Color.DimGray;
            tbArriveLoc.Location = new Point(51, 438);
            tbArriveLoc.Name = "tbArriveLoc";
            tbArriveLoc.Size = new Size(64, 16);
            tbArriveLoc.TabIndex = 29;
            tbArriveLoc.Text = "ArriveLoc";
            // 
            // tbFlightCode
            // 
            tbFlightCode.AutoSize = true;
            tbFlightCode.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            tbFlightCode.ForeColor = Color.DimGray;
            tbFlightCode.Location = new Point(193, 438);
            tbFlightCode.Name = "tbFlightCode";
            tbFlightCode.Size = new Size(47, 16);
            tbFlightCode.TabIndex = 30;
            tbFlightCode.Text = "4A 000";
            // 
            // tbArrivalDate
            // 
            tbArrivalDate.AutoSize = true;
            tbArrivalDate.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            tbArrivalDate.ForeColor = Color.DimGray;
            tbArrivalDate.Location = new Point(551, 438);
            tbArrivalDate.Name = "tbArrivalDate";
            tbArrivalDate.Size = new Size(71, 16);
            tbArrivalDate.TabIndex = 32;
            tbArrivalDate.Text = "00/00/0000";
            // 
            // tbDepartDate
            // 
            tbDepartDate.AutoSize = true;
            tbDepartDate.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            tbDepartDate.ForeColor = Color.DimGray;
            tbDepartDate.Location = new Point(350, 438);
            tbDepartDate.Name = "tbDepartDate";
            tbDepartDate.Size = new Size(71, 16);
            tbDepartDate.TabIndex = 33;
            tbDepartDate.Text = "00-00-0000";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Font = new Font("Microsoft Sans Serif", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            label16.ForeColor = Color.SteelBlue;
            label16.Location = new Point(51, 552);
            label16.Name = "label16";
            label16.Size = new Size(81, 18);
            label16.TabIndex = 34;
            label16.Text = "AMOUNT: ";
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label17.ForeColor = Color.FromArgb(64, 64, 64);
            label17.Location = new Point(51, 592);
            label17.Name = "label17";
            label17.Size = new Size(43, 16);
            label17.TabIndex = 35;
            label17.Text = "Adult: ";
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label18.ForeColor = Color.FromArgb(64, 64, 64);
            label18.Location = new Point(51, 608);
            label18.Name = "label18";
            label18.Size = new Size(40, 16);
            label18.TabIndex = 36;
            label18.Text = "Child:";
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label19.ForeColor = Color.FromArgb(64, 64, 64);
            label19.Location = new Point(51, 624);
            label19.Name = "label19";
            label19.Size = new Size(49, 16);
            label19.TabIndex = 37;
            label19.Text = "Senior:";
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label20.ForeColor = Color.FromArgb(64, 64, 64);
            label20.Location = new Point(51, 576);
            label20.Name = "label20";
            label20.Size = new Size(119, 16);
            label20.TabIndex = 38;
            label20.Text = "Travel Destination:";
            // 
            // tbFlightType
            // 
            tbFlightType.AutoSize = true;
            tbFlightType.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Italic, GraphicsUnit.Point);
            tbFlightType.ForeColor = Color.FromArgb(64, 64, 64);
            tbFlightType.Location = new Point(193, 384);
            tbFlightType.Name = "tbFlightType";
            tbFlightType.Size = new Size(50, 16);
            tbFlightType.TabIndex = 26;
            tbFlightType.Text = "CLASS";
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label21.ForeColor = Color.FromArgb(64, 64, 64);
            label21.Location = new Point(51, 640);
            label21.Name = "label21";
            label21.Size = new Size(110, 16);
            label21.TabIndex = 39;
            label21.Text = "Travel Insurance:";
            // 
            // label22
            // 
            label22.AutoSize = true;
            label22.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label22.ForeColor = Color.FromArgb(64, 64, 64);
            label22.Location = new Point(350, 576);
            label22.Name = "label22";
            label22.Size = new Size(75, 16);
            label22.TabIndex = 40;
            label22.Text = "Travel Tax:";
            // 
            // label23
            // 
            label23.AutoSize = true;
            label23.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label23.ForeColor = Color.FromArgb(64, 64, 64);
            label23.Location = new Point(350, 592);
            label23.Name = "label23";
            label23.Size = new Size(94, 16);
            label23.TabIndex = 41;
            label23.Text = "Baggage Fee:";
            // 
            // label24
            // 
            label24.AutoSize = true;
            label24.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label24.ForeColor = Color.FromArgb(64, 64, 64);
            label24.Location = new Point(350, 608);
            label24.Name = "label24";
            label24.Size = new Size(108, 16);
            label24.TabIndex = 42;
            label24.Text = "Transaction Fee:";
            // 
            // label25
            // 
            label25.AutoSize = true;
            label25.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label25.ForeColor = Color.FromArgb(64, 64, 64);
            label25.Location = new Point(350, 624);
            label25.Name = "label25";
            label25.Size = new Size(104, 16);
            label25.TabIndex = 43;
            label25.Text = "Senior Discount:";
            // 
            // label26
            // 
            label26.AutoSize = true;
            label26.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label26.ForeColor = Color.FromArgb(64, 64, 64);
            label26.Location = new Point(350, 640);
            label26.Name = "label26";
            label26.Size = new Size(54, 16);
            label26.TabIndex = 44;
            label26.Text = "TOTAL:";
            // 
            // tbTravelDestination
            // 
            tbTravelDestination.AutoSize = true;
            tbTravelDestination.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Italic, GraphicsUnit.Point);
            tbTravelDestination.ForeColor = Color.Gray;
            tbTravelDestination.Location = new Point(176, 576);
            tbTravelDestination.Name = "tbTravelDestination";
            tbTravelDestination.Size = new Size(93, 16);
            tbTravelDestination.TabIndex = 45;
            tbTravelDestination.Text = " PHP 00000.00";
            // 
            // tbAdultFare
            // 
            tbAdultFare.AutoSize = true;
            tbAdultFare.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            tbAdultFare.ForeColor = Color.DimGray;
            tbAdultFare.Location = new Point(176, 592);
            tbAdultFare.Name = "tbAdultFare";
            tbAdultFare.Size = new Size(93, 16);
            tbAdultFare.TabIndex = 46;
            tbAdultFare.Text = " PHP 00000.00";
            // 
            // tbChildFare
            // 
            tbChildFare.AutoSize = true;
            tbChildFare.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            tbChildFare.ForeColor = Color.DimGray;
            tbChildFare.Location = new Point(176, 608);
            tbChildFare.Name = "tbChildFare";
            tbChildFare.Size = new Size(93, 16);
            tbChildFare.TabIndex = 47;
            tbChildFare.Text = " PHP 00000.00";
            // 
            // tbSeniorFare
            // 
            tbSeniorFare.AutoSize = true;
            tbSeniorFare.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            tbSeniorFare.ForeColor = Color.DimGray;
            tbSeniorFare.Location = new Point(176, 624);
            tbSeniorFare.Name = "tbSeniorFare";
            tbSeniorFare.Size = new Size(93, 16);
            tbSeniorFare.TabIndex = 48;
            tbSeniorFare.Text = " PHP 00000.00";
            // 
            // tbTravelInsurance
            // 
            tbTravelInsurance.AutoSize = true;
            tbTravelInsurance.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            tbTravelInsurance.ForeColor = Color.DimGray;
            tbTravelInsurance.Location = new Point(176, 640);
            tbTravelInsurance.Name = "tbTravelInsurance";
            tbTravelInsurance.Size = new Size(93, 16);
            tbTravelInsurance.TabIndex = 49;
            tbTravelInsurance.Text = " PHP 00000.00";
            // 
            // tbTravelTax
            // 
            tbTravelTax.AutoSize = true;
            tbTravelTax.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            tbTravelTax.ForeColor = Color.DimGray;
            tbTravelTax.Location = new Point(482, 576);
            tbTravelTax.Name = "tbTravelTax";
            tbTravelTax.Size = new Size(93, 16);
            tbTravelTax.TabIndex = 50;
            tbTravelTax.Text = " PHP 00000.00";
            // 
            // tbBaggageFee
            // 
            tbBaggageFee.AutoSize = true;
            tbBaggageFee.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            tbBaggageFee.ForeColor = Color.DimGray;
            tbBaggageFee.Location = new Point(482, 592);
            tbBaggageFee.Name = "tbBaggageFee";
            tbBaggageFee.Size = new Size(93, 16);
            tbBaggageFee.TabIndex = 51;
            tbBaggageFee.Text = " PHP 00000.00";
            // 
            // tbTransactionFee
            // 
            tbTransactionFee.AutoSize = true;
            tbTransactionFee.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            tbTransactionFee.ForeColor = Color.DimGray;
            tbTransactionFee.Location = new Point(482, 608);
            tbTransactionFee.Name = "tbTransactionFee";
            tbTransactionFee.Size = new Size(93, 16);
            tbTransactionFee.TabIndex = 52;
            tbTransactionFee.Text = " PHP 00000.00";
            // 
            // tbSeniorDiscount
            // 
            tbSeniorDiscount.AutoSize = true;
            tbSeniorDiscount.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            tbSeniorDiscount.ForeColor = Color.DimGray;
            tbSeniorDiscount.Location = new Point(482, 624);
            tbSeniorDiscount.Name = "tbSeniorDiscount";
            tbSeniorDiscount.Size = new Size(93, 16);
            tbSeniorDiscount.TabIndex = 53;
            tbSeniorDiscount.Text = " PHP 00000.00";
            // 
            // tbTotal
            // 
            tbTotal.AutoSize = true;
            tbTotal.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            tbTotal.ForeColor = Color.FromArgb(64, 64, 64);
            tbTotal.Location = new Point(482, 640);
            tbTotal.Name = "tbTotal";
            tbTotal.Size = new Size(93, 16);
            tbTotal.TabIndex = 54;
            tbTotal.Text = " PHP 00000.00";
            // 
            // label27
            // 
            label27.AutoSize = true;
            label27.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label27.ForeColor = Color.DimGray;
            label27.Location = new Point(108, 592);
            label27.Name = "label27";
            label27.Size = new Size(13, 16);
            label27.TabIndex = 55;
            label27.Text = "x";
            // 
            // label28
            // 
            label28.AutoSize = true;
            label28.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label28.ForeColor = Color.DimGray;
            label28.Location = new Point(108, 608);
            label28.Name = "label28";
            label28.Size = new Size(13, 16);
            label28.TabIndex = 56;
            label28.Text = "x";
            // 
            // label29
            // 
            label29.AutoSize = true;
            label29.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label29.ForeColor = Color.DimGray;
            label29.Location = new Point(108, 624);
            label29.Name = "label29";
            label29.Size = new Size(13, 16);
            label29.TabIndex = 57;
            label29.Text = "x";
            // 
            // tbAdultNum
            // 
            tbAdultNum.AutoSize = true;
            tbAdultNum.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            tbAdultNum.ForeColor = Color.DimGray;
            tbAdultNum.Location = new Point(127, 592);
            tbAdultNum.Name = "tbAdultNum";
            tbAdultNum.Size = new Size(14, 16);
            tbAdultNum.TabIndex = 58;
            tbAdultNum.Text = "0";
            // 
            // tbChildNum
            // 
            tbChildNum.AutoSize = true;
            tbChildNum.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            tbChildNum.ForeColor = Color.DimGray;
            tbChildNum.Location = new Point(127, 608);
            tbChildNum.Name = "tbChildNum";
            tbChildNum.Size = new Size(14, 16);
            tbChildNum.TabIndex = 59;
            tbChildNum.Text = "0";
            // 
            // tbSeniorNum
            // 
            tbSeniorNum.AutoSize = true;
            tbSeniorNum.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            tbSeniorNum.ForeColor = Color.DimGray;
            tbSeniorNum.Location = new Point(127, 624);
            tbSeniorNum.Name = "tbSeniorNum";
            tbSeniorNum.Size = new Size(14, 16);
            tbSeniorNum.TabIndex = 60;
            tbSeniorNum.Text = "0";
            // 
            // btnPrint
            // 
            btnPrint.BackColor = Color.Transparent;
            btnPrint.BorderColor = Color.Transparent;
            btnPrint.ButtonColor = Color.SteelBlue;
            btnPrint.Cursor = Cursors.Hand;
            btnPrint.FlatAppearance.BorderSize = 0;
            btnPrint.FlatAppearance.MouseDownBackColor = Color.Transparent;
            btnPrint.FlatAppearance.MouseOverBackColor = Color.Transparent;
            btnPrint.FlatStyle = FlatStyle.Flat;
            btnPrint.Font = new Font("Microsoft Sans Serif", 11.9999981F, FontStyle.Regular, GraphicsUnit.Point);
            btnPrint.Location = new Point(296, 691);
            btnPrint.Name = "btnPrint";
            btnPrint.OnHoverBorderColor = Color.Transparent;
            btnPrint.OnHoverButtonColor = Color.CornflowerBlue;
            btnPrint.OnHoverTextColor = Color.White;
            btnPrint.Size = new Size(206, 49);
            btnPrint.TabIndex = 61;
            btnPrint.Text = "Save Receipt as PDF";
            btnPrint.TextColor = Color.White;
            btnPrint.UseVisualStyleBackColor = false;
            // 
            // tbDepartTIme
            // 
            tbDepartTIme.AutoSize = true;
            tbDepartTIme.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            tbDepartTIme.ForeColor = Color.DimGray;
            tbDepartTIme.Location = new Point(427, 438);
            tbDepartTIme.Name = "tbDepartTIme";
            tbDepartTIme.Size = new Size(61, 16);
            tbDepartTIme.TabIndex = 62;
            tbDepartTIme.Text = "00:00 AM";
            // 
            // tbArrivalTime
            // 
            tbArrivalTime.AutoSize = true;
            tbArrivalTime.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            tbArrivalTime.ForeColor = Color.DimGray;
            tbArrivalTime.Location = new Point(628, 438);
            tbArrivalTime.Name = "tbArrivalTime";
            tbArrivalTime.Size = new Size(61, 16);
            tbArrivalTime.TabIndex = 63;
            tbArrivalTime.Text = "00:00 AM";
            // 
            // label1
            // 
            label1.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Regular, GraphicsUnit.Point);
            label1.ForeColor = Color.FromArgb(64, 64, 64);
            label1.Location = new Point(51, 254);
            label1.Name = "label1";
            label1.Size = new Size(204, 102);
            label1.TabIndex = 64;
            // 
            // label2
            // 
            label2.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Regular, GraphicsUnit.Point);
            label2.ForeColor = Color.FromArgb(64, 64, 64);
            label2.Location = new Point(261, 254);
            label2.Name = "label2";
            label2.Size = new Size(204, 102);
            label2.TabIndex = 65;
            // 
            // label3
            // 
            label3.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Regular, GraphicsUnit.Point);
            label3.ForeColor = Color.FromArgb(64, 64, 64);
            label3.Location = new Point(471, 254);
            label3.Name = "label3";
            label3.Size = new Size(204, 102);
            label3.TabIndex = 66;
            // 
            // tbFlightTrip
            // 
            tbFlightTrip.AutoSize = true;
            tbFlightTrip.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Italic, GraphicsUnit.Point);
            tbFlightTrip.ForeColor = Color.FromArgb(64, 64, 64);
            tbFlightTrip.Location = new Point(350, 384);
            tbFlightTrip.Name = "tbFlightTrip";
            tbFlightTrip.Size = new Size(43, 16);
            tbFlightTrip.TabIndex = 67;
            tbFlightTrip.Text = "TYPE";
            // 
            // roundTripPanel
            // 
            roundTripPanel.Controls.Add(tbArrivalTime2);
            roundTripPanel.Controls.Add(tbDepartTime2);
            roundTripPanel.Controls.Add(tbArrivalDate2);
            roundTripPanel.Controls.Add(tbDepartDate2);
            roundTripPanel.Controls.Add(tbFlightCode2);
            roundTripPanel.Controls.Add(tbArriveLoc2);
            roundTripPanel.Controls.Add(tbDepartLoc2);
            roundTripPanel.Location = new Point(35, 457);
            roundTripPanel.Name = "roundTripPanel";
            roundTripPanel.Size = new Size(706, 71);
            roundTripPanel.TabIndex = 68;
            roundTripPanel.Visible = false;
            // 
            // tbArrivalTime2
            // 
            tbArrivalTime2.AutoSize = true;
            tbArrivalTime2.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            tbArrivalTime2.ForeColor = Color.DimGray;
            tbArrivalTime2.Location = new Point(593, 29);
            tbArrivalTime2.Name = "tbArrivalTime2";
            tbArrivalTime2.Size = new Size(61, 16);
            tbArrivalTime2.TabIndex = 70;
            tbArrivalTime2.Text = "00:00 AM";
            // 
            // tbDepartTime2
            // 
            tbDepartTime2.AutoSize = true;
            tbDepartTime2.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            tbDepartTime2.ForeColor = Color.DimGray;
            tbDepartTime2.Location = new Point(392, 29);
            tbDepartTime2.Name = "tbDepartTime2";
            tbDepartTime2.Size = new Size(61, 16);
            tbDepartTime2.TabIndex = 70;
            tbDepartTime2.Text = "00:00 AM";
            // 
            // tbArrivalDate2
            // 
            tbArrivalDate2.AutoSize = true;
            tbArrivalDate2.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            tbArrivalDate2.ForeColor = Color.DimGray;
            tbArrivalDate2.Location = new Point(516, 29);
            tbArrivalDate2.Name = "tbArrivalDate2";
            tbArrivalDate2.Size = new Size(71, 16);
            tbArrivalDate2.TabIndex = 69;
            tbArrivalDate2.Text = "00/00/0000";
            // 
            // tbDepartDate2
            // 
            tbDepartDate2.AutoSize = true;
            tbDepartDate2.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            tbDepartDate2.ForeColor = Color.DimGray;
            tbDepartDate2.Location = new Point(315, 29);
            tbDepartDate2.Name = "tbDepartDate2";
            tbDepartDate2.Size = new Size(71, 16);
            tbDepartDate2.TabIndex = 69;
            tbDepartDate2.Text = "00-00-0000";
            // 
            // tbFlightCode2
            // 
            tbFlightCode2.AutoSize = true;
            tbFlightCode2.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            tbFlightCode2.ForeColor = Color.DimGray;
            tbFlightCode2.Location = new Point(158, 29);
            tbFlightCode2.Name = "tbFlightCode2";
            tbFlightCode2.Size = new Size(47, 16);
            tbFlightCode2.TabIndex = 69;
            tbFlightCode2.Text = "4A 000";
            // 
            // tbArriveLoc2
            // 
            tbArriveLoc2.AutoSize = true;
            tbArriveLoc2.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            tbArriveLoc2.ForeColor = Color.DimGray;
            tbArriveLoc2.Location = new Point(16, 29);
            tbArriveLoc2.Name = "tbArriveLoc2";
            tbArriveLoc2.Size = new Size(64, 16);
            tbArriveLoc2.TabIndex = 69;
            tbArriveLoc2.Text = "ArriveLoc";
            // 
            // tbDepartLoc2
            // 
            tbDepartLoc2.AutoSize = true;
            tbDepartLoc2.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            tbDepartLoc2.ForeColor = Color.DimGray;
            tbDepartLoc2.Location = new Point(16, 13);
            tbDepartLoc2.Name = "tbDepartLoc2";
            tbDepartLoc2.Size = new Size(70, 16);
            tbDepartLoc2.TabIndex = 69;
            tbDepartLoc2.Text = "DepartLoc";
            // 
            // Receipt
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(800, 770);
            ControlBox = false;
            Controls.Add(roundTripPanel);
            Controls.Add(tbFlightTrip);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(tbArrivalTime);
            Controls.Add(tbDepartTIme);
            Controls.Add(btnPrint);
            Controls.Add(tbSeniorNum);
            Controls.Add(tbChildNum);
            Controls.Add(tbAdultNum);
            Controls.Add(label29);
            Controls.Add(label28);
            Controls.Add(label27);
            Controls.Add(tbTotal);
            Controls.Add(tbSeniorDiscount);
            Controls.Add(tbTransactionFee);
            Controls.Add(tbBaggageFee);
            Controls.Add(tbTravelTax);
            Controls.Add(tbTravelInsurance);
            Controls.Add(tbSeniorFare);
            Controls.Add(tbChildFare);
            Controls.Add(tbAdultFare);
            Controls.Add(tbTravelDestination);
            Controls.Add(label26);
            Controls.Add(label25);
            Controls.Add(label24);
            Controls.Add(label23);
            Controls.Add(label22);
            Controls.Add(label21);
            Controls.Add(label20);
            Controls.Add(label19);
            Controls.Add(label18);
            Controls.Add(label17);
            Controls.Add(label16);
            Controls.Add(tbDepartDate);
            Controls.Add(tbArrivalDate);
            Controls.Add(tbFlightCode);
            Controls.Add(tbArriveLoc);
            Controls.Add(tbDepartLoc);
            Controls.Add(tbFlightType);
            Controls.Add(label15);
            Controls.Add(label14);
            Controls.Add(label13);
            Controls.Add(label12);
            Controls.Add(label11);
            Controls.Add(panel7);
            Controls.Add(panel5);
            Controls.Add(label10);
            Controls.Add(panel1);
            Controls.Add(tbTransNum);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(tbBookDate);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label101);
            Controls.Add(pictureBox2);
            Controls.Add(panel2);
            Controls.Add(label99);
            Controls.Add(label100);
            Controls.Add(pictureBox1);
            Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point);
            FormBorderStyle = FormBorderStyle.None;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Receipt";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Receipt";
            Load += Receipt_Load;
            MouseDown += Receipt_MouseDown;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            panel1.ResumeLayout(false);
            panel5.ResumeLayout(false);
            panel7.ResumeLayout(false);
            roundTripPanel.ResumeLayout(false);
            roundTripPanel.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private EclipeControl eclipeControl1;
        private PictureBox pictureBox1;
        private Label label99;
        private Label label100;
        private Label tbBookDate;
        private Label label5;
        private Label label4;
        private Label label101;
        private PictureBox pictureBox2;
        private Panel panel2;
        private Panel panel3;
        private Label tbArriveLoc;
        private Label tbDepartLoc;
        private Label label15;
        private Label label14;
        private Label label13;
        private Label label12;
        private Label label11;
        private Panel panel7;
        private Panel panel8;
        private Panel panel5;
        private Panel panel6;
        private Label label10;
        private Panel panel1;
        private Panel panel4;
        private Label tbTransNum;
        private Label label8;
        private Label label7;
        private Label label6;
        private Label tbFlightCode;
        private Label tbArrivalDate;
        private Label label19;
        private Label label18;
        private Label label17;
        private Label label16;
        private Label tbDepartDate;
        private Label label21;
        private Label label20;
        private Label tbFlightType;
        private Label label22;
        private Label label24;
        private Label label23;
        private Label label25;
        private Label tbSeniorNum;
        private Label tbChildNum;
        private Label tbAdultNum;
        private Label label29;
        private Label label28;
        private Label label27;
        private Label tbTotal;
        private Label tbSeniorDiscount;
        private Label tbTransactionFee;
        private Label tbBaggageFee;
        private Label tbTravelTax;
        private Label tbTravelInsurance;
        private Label tbSeniorFare;
        private Label tbChildFare;
        private Label tbAdultFare;
        private Label tbTravelDestination;
        private Label label26;
        private ePOSOne.btnProduct.Button_WOC btnPrint;
        private Label tbDepartTIme;
        private Label tbArrivalTime;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label tbFlightTrip;
        private Panel roundTripPanel;
        private Label tbArrivalTime2;
        private Label tbDepartTime2;
        private Label tbArrivalDate2;
        private Label tbDepartDate2;
        private Label tbFlightCode2;
        private Label tbArriveLoc2;
        private Label tbDepartLoc2;
    }
}